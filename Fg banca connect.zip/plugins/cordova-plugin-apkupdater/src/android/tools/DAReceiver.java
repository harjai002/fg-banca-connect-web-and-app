package de.kolbasa.apkupdater.tools;

public class DAReceiver extends android.app.admin.DeviceAdminReceiver {
    //
}
