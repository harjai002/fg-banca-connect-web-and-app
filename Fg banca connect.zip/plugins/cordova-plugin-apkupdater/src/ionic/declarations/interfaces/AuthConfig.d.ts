declare module 'cordova-plugin-apkupdater' {

    interface AuthConfig {

        user: string;

        password: string;

    }

}
