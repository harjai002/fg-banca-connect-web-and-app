package de.kolbasa.apkupdater.exceptions;

public class PlatformNotSupportedException extends Exception {
    public PlatformNotSupportedException(String message) {
        super(message);
    }
}