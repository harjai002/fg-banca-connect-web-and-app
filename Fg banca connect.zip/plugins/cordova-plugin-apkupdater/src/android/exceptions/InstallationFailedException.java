package de.kolbasa.apkupdater.exceptions;

public class InstallationFailedException extends Exception {
    public InstallationFailedException(String message) {
        super(message);
    }
}