(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _auth_login_login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth/login/login.component */ 8146);
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard/dashboard.component */ 7528);
/* harmony import */ var _dsrActivity_dsrActivity_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dsrActivity/dsrActivity.component */ 4210);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home/home.component */ 5067);
/* harmony import */ var _network_err_network_err_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./network-err/network-err.component */ 5527);
/* harmony import */ var _report_report_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./report/report.component */ 8562);
/* harmony import */ var _services_guards_auth_guard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/guards/auth.guard */ 3980);
/* harmony import */ var _teamdemo_teamdemo_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./teamdemo/teamdemo.component */ 9930);
/* harmony import */ var _teams_activity_teams_activity_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./teams-activity/teams-activity.component */ 2359);
/* harmony import */ var _teams_dashboard_teams_dashboard_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./teams-dashboard/teams-dashboard.component */ 5857);













const routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    { path: 'login', component: _auth_login_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent },
    { path: 'home', component: _home_home_component__WEBPACK_IMPORTED_MODULE_3__.HomeComponent, canActivate: [_services_guards_auth_guard__WEBPACK_IMPORTED_MODULE_6__.AuthGuard] },
    { path: 'dsrActivity', component: _dsrActivity_dsrActivity_component__WEBPACK_IMPORTED_MODULE_2__.DsrActivityComponent },
    { path: 'dashboard', component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_1__.DashboardComponent },
    { path: 'networkerr', component: _network_err_network_err_component__WEBPACK_IMPORTED_MODULE_4__.NetworkErrComponent },
    { path: 'teamsActivity', component: _teams_activity_teams_activity_component__WEBPACK_IMPORTED_MODULE_8__.TeamsActivityComponent },
    { path: 'teamsDemo:id', component: _teamdemo_teamdemo_component__WEBPACK_IMPORTED_MODULE_7__.TeamdemoComponent },
    { path: 'teamDashboard:id?', component: _teams_dashboard_teams_dashboard_component__WEBPACK_IMPORTED_MODULE_9__.TeamsDashboardComponent },
    { path: 'report', component: _report_report_component__WEBPACK_IMPORTED_MODULE_5__.ReportComponent },
    { path: '**', redirectTo: 'home' },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_12__.RouterModule.forRoot(routes, {
                useHash: true,
                preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_12__.PreloadAllModules
            })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_12__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 9259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/shared-data.service */ 1679);
/* harmony import */ var _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/splash-screen/ngx */ 696);
/* harmony import */ var _awesome_cordova_plugins_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/status-bar/ngx */ 9162);
/* harmony import */ var _services_network_check_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/network-check.service */ 4886);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 4582);
/* harmony import */ var _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/auth/authentication.service */ 6406);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./services/common.service */ 5620);
/* harmony import */ var src_app_services_components_loder_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/components/loder.service */ 6552);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 1832);
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/service-worker */ 4933);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 3491);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @awesome-cordova-plugins/in-app-browser/ngx */ 7122);




















let AppComponent = class AppComponent {
    constructor(menuCtrl, router, toastController, platform, splashScreen, statusBar, sharedDataService, alertController, networkCheckService, appVersion, authanticationSer, commonService, loderService, androidPermissions, swUpdate, // for Pwa web update,
    applicationRef, inAppBrowser) {
        this.menuCtrl = menuCtrl;
        this.router = router;
        this.toastController = toastController;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.sharedDataService = sharedDataService;
        this.alertController = alertController;
        this.networkCheckService = networkCheckService;
        this.appVersion = appVersion;
        this.authanticationSer = authanticationSer;
        this.commonService = commonService;
        this.loderService = loderService;
        this.androidPermissions = androidPermissions;
        this.swUpdate = swUpdate;
        this.applicationRef = applicationRef;
        this.inAppBrowser = inAppBrowser;
        this.progress = 0;
        this.appPages = [
        // { title: 'Home', url: 'home', icon: 'home' },
        ];
        this.newVersionAvailable = false;
        this.myStyles = { 'color': 'white', 'margin': '0rem 3rem 0rem 3rem', 'font-size': '2rem' };
        this.options = {
            clearcache: 'yes',
            clearsessioncache: 'yes',
            zoom: 'yes',
            hardwareback: 'yes',
            mediaPlaybackRequiresUserAction: 'no',
            shouldPauseOnSuspend: 'no',
            closebuttoncaption: 'Close',
            disallowoverscroll: 'no',
            toolbar: 'yes',
            enableViewportScale: 'no',
            allowInlineMediaPlayback: 'no',
            presentationstyle: 'pagesheet',
            fullscreen: 'yes', //Windows only    
        };
        this.loderService.loaderStatus.subscribe(res => {
            this.loaderStatus = res;
        });
        // *************    PWA  Update start here  *************
        swUpdate.available.subscribe(event => {
            swUpdate.activateUpdate().then(() => {
                window.location.reload();
                console.log('there is an Update! Reloading now.');
            });
        });
        if (!this.swUpdate.isEnabled) {
            console.log('Not going to update');
        }
        // *************    PWA  Update start here  *************
        this.initializeApp();
    }
    ngOnInit() {
        this.getSubjectData();
        if (sessionStorage.authData) {
            const get = this.authanticationSer.getSession('authData');
            let d = JSON.parse(atob(get));
            if (d) {
                this.userName = d.EmpName;
                this.userEmail = d.Email;
                this.userFlag = d.flag;
                this.router.navigate(['/home']);
            }
            else {
                this.router.navigateByUrl('/login');
            }
        }
    }
    initializeApp() {
        this.platform.ready().then(() => {
            // for check Permissions
            this.checkPermissions();
            // Check internet connection 
            this.networkCheckService.ngOnInit();
            this.statusBar.styleDefault();
            this.splashScreen.show();
            this.statusBar.overlaysWebView(false);
            this.statusBar.backgroundColorByHexString("#c21b17");
            this.platform.backButton.subscribeWithPriority(0, () => {
                console.log('back', this.router.url);
                if (this.router.url === '/home' || this.router.url === '/login') {
                    this.appExitAlertConfirm();
                    // navigator['app'].exitApp();
                }
                else {
                    this.routerOutlet.pop();
                }
            });
            if (this.platform.is('android')) {
                // console.log("manoj");
                this.appVersion.getVersionNumber().then(response => {
                    this.appVersionNumber = response;
                    var version;
                    this.commonService.get('getDSRAppVersion').subscribe((res) => {
                        if (res.ResponseFlag == 1) {
                            version = JSON.parse(res.ResponseMessage).Table;
                            if (this.appVersionNumber != version[0].Version) {
                                // this.appUpdateConfirm();
                            }
                            else {
                                console.log("version is match");
                            }
                        }
                        else {
                            console.log("version not found");
                        }
                    }), (err) => {
                        console.log("error", err);
                    };
                }).catch(error => {
                    alert(error);
                });
            }
        });
    }
    getSubjectData() {
        this.sharedDataService.data.subscribe(res => {
            this.userName = res.EmpName;
            this.userFlag = res.flag;
            this.userEmail = res.Email;
            // console.log("subject data resive", res);
        });
    }
    close() {
        this.menuCtrl.close();
    }
    goToHome(item) {
        console.log(item);
        this.router.navigateByUrl(item.url);
    }
    commonLogOutData() {
        this.authanticationSer.removeSession('authData');
        this.authanticationSer.removeSession('Token');
        this.menuCtrl.enable(false);
        this.loderService.dismiss();
        this.router.navigateByUrl('/login');
    }
    logout() {
        this.menuCtrl.close();
        this.commonService.post('expireToken', { '': '' }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.commonLogOutData();
                if (this.platform.is('ios')) {
                    this.openWithInAppBrowser();
                }
                else {
                    console.log("openWithInAppBrowser will not work on android and ios platform");
                }
            }
            else {
                this.commonLogOutData();
            }
        });
    }
    openWithInAppBrowser() {
        let target = "_self";
        this.inAppBrowser.create('https://online.futuregenerali.in/TeamTrack/Web/#', target, this.options);
    }
    appExitAlertConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'App Exit Confirm!',
                message: 'Are you sure you want to exit the app?',
                mode: 'ios',
                buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'danger',
                        handler: (blah) => { }
                    }, {
                        text: 'Exit App',
                        handler: () => {
                            this.logout();
                            navigator['app'].exitApp();
                        }
                    }]
            });
            yield alert.present();
        });
    }
    appUpdateConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'New version available! ',
                message: 'Please update new version ',
                mode: 'ios',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Update',
                        handler: () => {
                            // this.authanticationSer.removeSession('authData');
                            // window.location.href = "/";
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    checkPermissions() {
        this.androidPermissions.requestPermissions([
            this.androidPermissions.PERMISSION.CAMERA,
            this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE,
            this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE
        ]);
    }
    //********************************** */
    updateClient() {
        if (!this.swUpdate.isEnabled) {
            this.newVersionAvailable = false;
            // this.snackBar.open("Service worker is not enabled !");
            return;
        }
        this.swUpdate.available.subscribe((event) => {
            console.log('current', event.current, 'available', event.available);
            this.swUpdate.activateUpdate().then(() => document.location.reload());
        });
        this.swUpdate.activated.subscribe((event) => {
            console.log('previous', event.previous, 'current', event.current);
        });
    }
    checkUpdate() {
        this.applicationRef.isStable.subscribe((isStable) => {
            if (isStable) {
                const timeInterval = (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.interval)(8 * 60 * 60 * 1000);
                //const timeInterval = interval(60000);
                timeInterval.subscribe(() => {
                    this.swUpdate.checkForUpdate().then(() => console.log('checked'));
                });
            }
        });
    }
    isNewVersionAvailable() {
        if (src_environments_environment__WEBPACK_IMPORTED_MODULE_11__.environment.production) {
            if (!this.swUpdate.isEnabled) {
                // this.snackBar.open("Service worker is not enabled !");
                return;
            }
            this.swUpdate.available.subscribe((event) => {
                this.newVersionAvailable = true;
            });
        }
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_16__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.Platform },
    { type: _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__.SplashScreen },
    { type: _awesome_cordova_plugins_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__.StatusBar },
    { type: _services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.AlertController },
    { type: _services_network_check_service__WEBPACK_IMPORTED_MODULE_5__.NetworkCheckService },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_6__.AppVersion },
    { type: _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_7__.AuthenticationService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_8__.CommonService },
    { type: src_app_services_components_loder_service__WEBPACK_IMPORTED_MODULE_9__.LoderService },
    { type: _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_10__.AndroidPermissions },
    { type: _angular_service_worker__WEBPACK_IMPORTED_MODULE_17__.SwUpdate },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_18__.ApplicationRef },
    { type: _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_12__.InAppBrowser }
];
AppComponent.propDecorators = {
    routerOutlet: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_18__.ViewChild, args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonRouterOutlet,] }]
};
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_13__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @angular/platform-browser */ 318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/data.service */ 2468);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/auth.service */ 7556);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/common.service */ 5620);
/* harmony import */ var _auth_login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth/login/login.component */ 8146);
/* harmony import */ var _network_err_network_err_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./network-err/network-err.component */ 5527);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home/home.component */ 5067);
/* harmony import */ var _services_pipes_filterdata_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./services/pipes/filterdata.pipe */ 3401);
/* harmony import */ var _dsrActivity_dsrActivity_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./dsrActivity/dsrActivity.component */ 4210);
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./dashboard/dashboard.component */ 7528);
/* harmony import */ var _teams_activity_teams_activity_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./teams-activity/teams-activity.component */ 2359);
/* harmony import */ var _report_report_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./report/report.component */ 8562);
/* harmony import */ var _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @awesome-cordova-plugins/splash-screen/ngx */ 696);
/* harmony import */ var _awesome_cordova_plugins_status_bar_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @awesome-cordova-plugins/status-bar/ngx */ 9162);
/* harmony import */ var _services_network_check_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/network-check.service */ 4886);
/* harmony import */ var _awesome_cordova_plugins_network_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @awesome-cordova-plugins/network/ngx */ 6946);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 4582);
/* harmony import */ var _teamdemo_teamdemo_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./teamdemo/teamdemo.component */ 9930);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ionic-selectable */ 5073);
/* harmony import */ var _services_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./services/components/dropdown/dropdown.component */ 1362);
/* harmony import */ var _teams_dashboard_teams_dashboard_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./teams-dashboard/teams-dashboard.component */ 5857);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic-native/file/ngx */ 2358);
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ 1059);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 1832);
/* harmony import */ var _services_interceptor_token_interceptor_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./services/interceptor/token-interceptor.service */ 1442);
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ngx-cookie */ 7988);
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/service-worker */ 4933);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../environments/environment */ 2340);
/* harmony import */ var _services_custom_popup_custom_popup_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./services/custom-popup/custom-popup.component */ 8240);
/* harmony import */ var _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @awesome-cordova-plugins/in-app-browser/ngx */ 7122);






































let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_29__.NgModule)({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent,
            _auth_login_login_component__WEBPACK_IMPORTED_MODULE_5__.LoginComponent,
            _home_home_component__WEBPACK_IMPORTED_MODULE_7__.HomeComponent,
            _services_pipes_filterdata_pipe__WEBPACK_IMPORTED_MODULE_8__.FilterdataPipe,
            _dsrActivity_dsrActivity_component__WEBPACK_IMPORTED_MODULE_9__.DsrActivityComponent,
            _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_10__.DashboardComponent,
            _teams_activity_teams_activity_component__WEBPACK_IMPORTED_MODULE_11__.TeamsActivityComponent,
            _report_report_component__WEBPACK_IMPORTED_MODULE_12__.ReportComponent,
            _network_err_network_err_component__WEBPACK_IMPORTED_MODULE_6__.NetworkErrComponent,
            _teamdemo_teamdemo_component__WEBPACK_IMPORTED_MODULE_18__.TeamdemoComponent,
            _services_components_dropdown_dropdown_component__WEBPACK_IMPORTED_MODULE_19__.DropdownComponent,
            _teams_dashboard_teams_dashboard_component__WEBPACK_IMPORTED_MODULE_20__.TeamsDashboardComponent,
            _services_custom_popup_custom_popup_component__WEBPACK_IMPORTED_MODULE_26__.CustomPopupComponent
        ],
        imports: [ionic_selectable__WEBPACK_IMPORTED_MODULE_30__.IonicSelectableModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_31__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_31__.ReactiveFormsModule,
            ngx_cookie__WEBPACK_IMPORTED_MODULE_32__.CookieModule.withOptions(),
            _angular_common_http__WEBPACK_IMPORTED_MODULE_33__.HttpClientModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_34__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_35__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_36__.ServiceWorkerModule.register('ngsw-worker.js', {
                enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_25__.environment.production,
                // Register the ServiceWorker as soon as the application is stable
                // or after 30 seconds (whichever comes first).
                // registrationStrategy: 'registerWhenStable:30000'
                registrationStrategy: 'registerImmediately'
            })],
        providers: [
            _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_17__.AppVersion,
            _services_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService,
            _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService,
            _services_common_service__WEBPACK_IMPORTED_MODULE_4__.CommonService,
            _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_13__.SplashScreen,
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_21__.File,
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_22__.FileTransfer,
            _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_23__.AndroidPermissions,
            _awesome_cordova_plugins_status_bar_ngx__WEBPACK_IMPORTED_MODULE_14__.StatusBar,
            _services_network_check_service__WEBPACK_IMPORTED_MODULE_15__.NetworkCheckService,
            _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_27__.InAppBrowser,
            _awesome_cordova_plugins_network_ngx__WEBPACK_IMPORTED_MODULE_16__.Network, { provide: _angular_router__WEBPACK_IMPORTED_MODULE_37__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_35__.IonicRouteStrategy },
            { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_33__.HTTP_INTERCEPTORS, useClass: _services_interceptor_token_interceptor_service__WEBPACK_IMPORTED_MODULE_24__.TokenInterceptorService, multi: true }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_29__.CUSTOM_ELEMENTS_SCHEMA]
    })
], AppModule);



/***/ }),

/***/ 8146:
/*!***********************************************!*\
  !*** ./src/app/auth/login/login.component.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.component.html?ngResource */ 5639);
/* harmony import */ var _login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.scss?ngResource */ 3488);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/components/toast.service */ 8923);
/* harmony import */ var _services_logindata_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/logindata.service */ 5590);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/auth.service */ 7556);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_shared_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/shared-data.service */ 1679);
/* harmony import */ var src_app_services_components_loder_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/components/loder.service */ 6552);
/* harmony import */ var src_app_services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/auth/authentication.service */ 6406);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 4582);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/common.service */ 5620);
/* harmony import */ var ngx_cookie__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ngx-cookie */ 7988);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file/ngx */ 2358);
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ 1059);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 1832);
/* harmony import */ var cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! cordova-plugin-apkupdater */ 5277);

















// for file download apk 




let LoginComponent = class LoginComponent {
    constructor(formBuilder, toastService, router, logindataService, authService, menuCtrl, sharedDataService, loderService, commonService, authanticationSer, platform, appVersion, alertController, cookieService, 
    // for download apk file
    file, fileTransfer, androidPermissions, _zone) {
        this.formBuilder = formBuilder;
        this.toastService = toastService;
        this.router = router;
        this.logindataService = logindataService;
        this.authService = authService;
        this.menuCtrl = menuCtrl;
        this.sharedDataService = sharedDataService;
        this.loderService = loderService;
        this.commonService = commonService;
        this.authanticationSer = authanticationSer;
        this.platform = platform;
        this.appVersion = appVersion;
        this.alertController = alertController;
        this.cookieService = cookieService;
        this.file = file;
        this.fileTransfer = fileTransfer;
        this.androidPermissions = androidPermissions;
        this._zone = _zone;
        this.buttonDisabled = true;
        this.showPassword = false;
        this.passwordtoggleicon = 'eye-outline';
        this.localData = [];
        // public validimage: string =;
        this.validimageusername = 'assets/icon/error.png';
        this.validimagepwd = 'assets/icon/error.png';
        this.progressBar = false;
        this.loginBtn = true;
        this.deviceReady();
        this.loginForm = this.formBuilder.group({
            userName: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required]),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required),
        });
    }
    ngOnInit() {
        // this. getUserData();
        //console.log('deive', this.device.model);
        this.loginForm.get('userName').setValue('');
        this.loginForm.get('password').setValue('');
        this.togglepassword();
        this.menuCtrl.enable(false);
    }
    getCookie() {
        var cookieName = 'HelloWorld';
        var cookieValue = 'HelloWorld';
        var myDate = new Date();
        myDate.setMonth(myDate.getMonth() + 12);
        document.cookie = cookieName + "=" + cookieValue + ";expires=" + myDate
            + ";domain=.example.com;path=/";
    }
    login() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        // this.loderService.showLoading(loadingParams);
        this.loderService.loaderStatus.next(true);
        let formData = this.loginForm.value;
        if (this.loginForm.valid) {
            let data = { userName: btoa(formData.userName), password: btoa(formData.password) };
            this.authService.login(data).subscribe(res => {
                this.loderService.loaderStatus.next(false);
                // this.loderService.dismiss();
                if (res.ResponseFlag == 1) {
                    let data = JSON.parse(res.ResponseMessage).Table[0];
                    console.log("res", JSON.parse(res.ResponseMessage).Table);
                    const stringifyObj = JSON.stringify(data);
                    const b64Str = btoa(stringifyObj);
                    this.authanticationSer.setSession('Token', data.Token);
                    this.authanticationSer.setSession('authData', b64Str);
                    this.router.navigate(['/home']);
                    this.menuCtrl.enable(true);
                    this.sharedDataService.sendData(data);
                    this.toastService.toast("Login successful");
                    // this.loginForm.reset();         
                }
                else {
                    this.toastService.toast("Login Failed , Please Check User Name & Password");
                }
            }, (err) => {
                console.log(err);
            });
        }
    }
    togglepassword() {
        if (this.passwordtoggleicon == 'eye-outline') {
            this.passwordtoggleicon = 'eye-off-outline';
            this.showPassword = false;
        }
        else {
            this.passwordtoggleicon = 'eye-outline';
            this.showPassword = true;
        }
    }
    deviceReady() {
        this.platform.ready().then(() => {
            if (this.platform.is('android')) {
                this.appVersion.getVersionNumber().then(response => {
                    this.appVersionNumber = response;
                    var version;
                    this.commonService.get('getDSRAppVersion').subscribe((res) => {
                        if (res.ResponseFlag == 1) {
                            version = JSON.parse(res.ResponseMessage).Table;
                            // console.log("api version", version);
                            if (this.appVersionNumber != version[0].Version) {
                                this.appUpdateConfirm();
                            }
                            else {
                                console.log("version is match");
                            }
                        }
                        else {
                            console.log("version not found");
                        }
                    }), (err) => {
                        console.log("error", err);
                    };
                }).catch(error => {
                    alert(error);
                });
            }
        });
    }
    downloadApp() {
        this.checkPermissions();
        const fileTransfer = this.fileTransfer.create();
        fileTransfer.onProgress((progressEvent) => {
            this._zone.run(() => {
                if (progressEvent.lengthComputable) {
                    let lp = progressEvent.loaded / progressEvent.total * 100;
                    this.progress = Math.round(lp * 100) / 100;
                }
            });
            // console.log("progress:" + this.progress);
        });
        var url = "https://tinyurl.com/INSTABv2";
        fileTransfer.download(url, this.file.externalDataDirectory + "sample.apk").then((data) => {
            // ApkUpdater.install( success, failure);
            console.log('Download complete: '); //handle success Manoj_ 
            this.loginBtn = true;
        }, (err) => {
            alert("Download error " + JSON.stringify(err));
        });
    }
    checkPermissions() {
        this.androidPermissions.requestPermissions([
            this.androidPermissions.PERMISSION.CAMERA,
            this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE,
            this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE
        ]);
    }
    appUpdateConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'New version available! ',
                message: 'Please update new version ',
                mode: 'ios',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Update',
                        handler: () => {
                            // this.authanticationSer.removeSession('authData');
                            // window.location.href = "/";
                            this.loginBtn = false;
                            this.progressBar = true;
                            // this.downloadApp();
                            this.update();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    update() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
            const installedVersion = (yield cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_13__["default"].getInstalledVersion());
            console.log("versions", installedVersion);
            yield cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_13__["default"].download('https://online.futuregenerali.in/DSR/FgBancaConnectMain.zip', {
                onDownloadProgress: (e) => {
                    this._zone.run(() => {
                        var _a;
                        this.progress = (_a = e === null || e === void 0 ? void 0 : e.progress) !== null && _a !== void 0 ? _a : 0;
                    });
                    console.log(e.progress, this.progress);
                },
                onUnzipProgress: console.log
            }, () => (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, function* () {
                yield cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_13__["default"].install(console.log, console.error);
            }), (error) => {
                console.error(error);
            });
        });
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormBuilder },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_2__.ToastService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_16__.Router },
    { type: _services_logindata_service__WEBPACK_IMPORTED_MODULE_3__.LogindataService },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.MenuController },
    { type: src_app_services_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService },
    { type: src_app_services_components_loder_service__WEBPACK_IMPORTED_MODULE_6__.LoderService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_9__.CommonService },
    { type: src_app_services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_7__.AuthenticationService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.Platform },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_8__.AppVersion },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.AlertController },
    { type: ngx_cookie__WEBPACK_IMPORTED_MODULE_18__.CookieService },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_10__.File },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_11__.FileTransfer },
    { type: _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_12__.AndroidPermissions },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_19__.NgZone }
];
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.Component)({
        selector: 'app-login',
        template: _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginComponent);



/***/ }),

/***/ 7528:
/*!**************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardComponent": () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component.html?ngResource */ 1029);
/* harmony import */ var _dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.component.scss?ngResource */ 6908);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth/authentication.service */ 6406);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/common.service */ 5620);
/* harmony import */ var _services_components_loder_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/components/loder.service */ 6552);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/components/toast.service */ 8923);
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/data.service */ 2468);











let DashboardComponent = class DashboardComponent {
    constructor(dataService, loderService, toastService, commonService, fb, toastController, authanticationSer) {
        this.dataService = dataService;
        this.loderService = loderService;
        this.toastService = toastService;
        this.commonService = commonService;
        this.fb = fb;
        this.toastController = toastController;
        this.authanticationSer = authanticationSer;
        this.titleMsg = 'Dashboard';
        this.teamsData = [];
        this.filterData = [];
        this.submitted = false;
        this.openFilter = false;
        this.sum = 0;
        this.typeOfActivityData = [];
        this.spiner = true;
    }
    ngOnInit() {
        this.geAurhtData();
        this.getTeamsLeaders();
        // this.getMonthData();
        // this.getYesturadyData();
        this.managerForm = this.fb.group({
            zone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            manager: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
        });
    }
    getData() {
        this.teamsData = this.dataService.LeaderData;
        // console.log("data", this.teamsData);
    }
    getTeamsLeaders() {
        this.yesturdayDate = new Date();
        this.month = new Date();
        this.yesturdayDate.setDate(this.yesturdayDate.getDate() - 1);
        this.month.setMonth(this.month.getMonth());
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        // userName: this.userEmpCode 
        this.commonService.post('getDSRleaders', { userName: this.userEmpCode }).subscribe((res) => {
            this.loderService.dismiss();
            if (res.ResponseFlag == 1) {
                this.teamsData = JSON.parse(res.ResponseMessage).Table;
                // console.log("Team Leaders", this.teamsData);
            }
            else {
                // this.toastService.toast("No record Found");
                //this.loderService.dismiss();
            }
        });
    }
    getCounts(id) {
        this.getYesturadyData(id);
        this.getMonthData(id);
    }
    filterOpen() {
        this.openFilter = !this.openFilter;
        this.getZones();
    }
    geAurhtData() {
        if (sessionStorage.authData) {
            const get = this.authanticationSer.getSession('authData');
            this.userData = JSON.parse(atob(get));
            this.userEmpCode = this.userData.EmpCode;
        }
    }
    getYesturadyData(id) {
        this.spiner = false;
        this.sum = 0;
        this.typeOfActivityData = [
            { type: "Bank Branch visit", count: 0, mnthCount: 0 },
            { type: "Bank Zonal office", count: 0, mnthCount: 0 },
            { type: "Bank Regional office", count: 0, mnthCount: 0 },
            { type: "Customer service", count: 0, mnthCount: 0 },
            { type: "Promotional activity", count: 0, mnthCount: 0 },
            { type: "Joint call with supevisor", count: 0, mnthCount: 0 },
            { type: "Review/Office Meeting", count: 0, mnthCount: 0 },
            { type: "Corporate salary", count: 0, mnthCount: 0 },
            { type: "Policy Issuance/Other Back office work", count: 0, mnthCount: 0 },
        ];
        // let loadingParams = { msg: 'Loading Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true }
        // this.loderService.showLoading(loadingParams);
        // console.log("userid", id);
        this.commonService.post('getDSRlastday', { userName: id }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.spiner = true;
                // this.loderService.dismiss();
                let data = JSON.parse(res.ResponseMessage).Table;
                // console.log("yesturady data", data);
                for (var i = 0; i < data.length; i++) {
                    this.typeOfActivityData.forEach(element => {
                        if (element.type == data[i].type_Of_Activity) {
                            element.count = data[i].count;
                            // sum+=data[i].count;
                            this.sum += data[i].count;
                            // console.log(element);
                        }
                        else {
                            // console.log("Data Not Found");
                        }
                    });
                }
                this.yesturdayCount = this.sum;
                // console.log(this.typeOfActivityData, "sum", this.yesturdayCount);
                // console.log("sum", this.yesturdayCount);
            }
            else {
                // this.loderService.dismiss();
            }
        });
    }
    getMonthData(id) {
        this.spiner = true;
        this.monthCount = 0;
        this.typeOfActivityData = [
            { type: "Bank Branch visit", count: 0, mnthCount: 0 },
            { type: "Bank Zonal office", count: 0, mnthCount: 0 },
            { type: "Bank Regional office", count: 0, mnthCount: 0 },
            { type: "Customer service", count: 0, mnthCount: 0 },
            { type: "Promotional activity", count: 0, mnthCount: 0 },
            { type: "Joint call with supevisor", count: 0, mnthCount: 0 },
            { type: "Review/Office Meeting", count: 0, mnthCount: 0 },
            { type: "Corporate salary", count: 0, mnthCount: 0 },
            { type: "Policy Issuance/Other Back office work", count: 0, mnthCount: 0 },
        ];
        // let loadingParams = { msg: 'Loading Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true }
        // this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRlastMonth', { userName: id }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.spiner = true;
                // this.loderService.dismiss();
                let data = JSON.parse(res.ResponseMessage).Table;
                console.log("month data", data);
                let sum = 0;
                for (var i = 0; i < data.length; i++) {
                    this.typeOfActivityData.forEach(element => {
                        if (element.type == data[i].type_Of_Activity) {
                            element.mnthCount = data[i].count;
                            this.monthCount += data[i].count;
                            console.log(element);
                        }
                        else {
                            // console.log("Data Not Found");
                        }
                    });
                }
                // this.monthCount=sum;
                // console.log(this.typeOfActivityData);
            }
            else {
                // this.loderService.dismiss();
            }
        });
    }
    getZones() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRZone', { userName: this.userEmpCode }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.loderService.dismiss();
                this.zoneData = JSON.parse(res.ResponseMessage).Table;
                // console.log("Zone data ", this.zoneData);
            }
            else {
                this.loderService.dismiss();
                this.toastService.toast("Zone Not Found");
            }
        });
    }
    chngeZone(e) {
        this.submitted = true;
        let zone = e.target.value;
        if (zone.length != 0) {
            let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
            this.loderService.showLoading(loadingParams);
            // userName: this.userEmpCode,
            this.commonService.post('getLeaderDtlsWithZone', { userName: this.userEmpCode, zones: zone }).subscribe((res) => {
                if (res.ResponseFlag == 1) {
                    this.loderService.dismiss();
                    this.teamsData = JSON.parse(res.ResponseMessage).Table;
                    if (this.teamsData.length == 0) {
                        this.toastService.toast("No Records Found !");
                    }
                    // console.log("Managers ", this.teamsData);
                }
                else {
                    this.loderService.dismiss();
                    this.toastService.toast("No Records Found!");
                }
            }, (err) => {
                // console("+err.status);
            });
        }
        else {
            this.geAurhtData();
            this.getTeamsLeaders();
        }
    }
    chngeManagers(e) {
        this.submitted = true;
        let manager = e.target.value;
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        this.commonService.post('getLeaderDtlsWithZone', { zone: [], manager: manager }).subscribe((res) => {
            this.loderService.dismiss();
            if (res.ResponseFlag == 1) {
                let data = JSON.parse(res.ResponseMessage).Table;
                for (let i = 0; i < data.length; i++) {
                    if (data[i].subTypeOfActivity.length > 10) {
                        data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                        // console.log("sub data", data[i].subTypeOfActivity);
                    }
                    else {
                        data[i].subTypeOfActivity = [];
                    }
                }
                if (data.length != 0) {
                    this.filterData = data;
                    // console.log("dsr data", data);
                }
                else {
                    this.filterData = [];
                    this.loderService.dismiss();
                }
            }
            else {
                this.loderService.dismiss();
                this.toastService.toast("Data Not Found");
            }
        }, (err) => {
            // console.log(err, "error");
        });
    }
    clearManagerFilter() {
        this.managerForm.reset();
        this.geAurhtData();
        this.getTeamsLeaders();
    }
};
DashboardComponent.ctorParameters = () => [
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_6__.DataService },
    { type: _services_components_loder_service__WEBPACK_IMPORTED_MODULE_4__.LoderService },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController },
    { type: _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__.AuthenticationService }
];
DashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-dashboard',
        template: _dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DashboardComponent);



/***/ }),

/***/ 4210:
/*!******************************************************!*\
  !*** ./src/app/dsrActivity/dsrActivity.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DsrActivityComponent": () => (/* binding */ DsrActivityComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _dsrActivity_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dsrActivity.component.html?ngResource */ 6396);
/* harmony import */ var _dsrActivity_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dsrActivity.component.scss?ngResource */ 3306);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ 196);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/data.service */ 2468);
/* harmony import */ var _services_excelexport_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/excelexport.service */ 8938);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/components/toast.service */ 8923);
/* harmony import */ var _services_components_loder_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/components//loder.service */ 6552);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/auth/authentication.service */ 6406);














class Banks {
}
class BankBranchName {
}
let DsrActivityComponent = class DsrActivityComponent {
    constructor(fb, dataService, popoverController, toastService, excelexportService, loderService, commonService, route, authanticationSer, router) {
        this.fb = fb;
        this.dataService = dataService;
        this.popoverController = popoverController;
        this.toastService = toastService;
        this.excelexportService = excelexportService;
        this.loderService = loderService;
        this.commonService = commonService;
        this.route = route;
        this.authanticationSer = authanticationSer;
        this.router = router;
        this.titleMsg = "DSR Activity";
        this.submitted = false;
        this.dsrDetails = true;
        this.dsrActivityAdd = false;
        this.searchBar = false;
        this.emptyRecord = true;
        this.openFilter = false;
        this.filterSearch = '';
        this.filterData = [];
        this.segmentValue = "zone";
        this.end_Time_picker = true;
        this.PremiumFooter = true;
    }
    ngOnInit() {
        this.getUserName();
        this.getBanks();
        this.getDSRActivityData();
        this.getTotalPremium();
        this.minMaxDate();
        this.drsFrom = this.fb.group({
            executive: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            team_Leader: [''],
            auth_role: [''],
            userName: [''],
            zone: [''],
            date_Of_Visit: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            start_Time: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            end_Time: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            duration: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            type_Of_Activity: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            subTypeOfActivity: this.fb.array([]),
            bank_Name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            branch_Code: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            bank_Branch_Name: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            // mode_Of_Transport: [''],
            // travel_From: [''],
            // travel_To: [''],
            // kilometers_Travelled: [''],
            // to_Whom_Meet: ['',Validators.compose([Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9  !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~€£¥₩])(?=.*?[A-Z 0-9]).{8,}$"), Validators.required])],
            to_Whom_Meet: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
            to_Whom_Meet_Number: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$"), _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.maxLength(10)]],
            remark_Comments: ['']
        });
        this.filterForm = this.fb.group({
            bank: [''],
            zone: [''],
            startDate: [''],
            activity: [''],
            endDate: ['']
        });
        this.managerForm = this.fb.group({
            zone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
            manager: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
        });
    }
    dateClanderChange(e) {
        this.clanderDate = e.target.value;
        console.log("date change ", this.clanderDate);
    }
    bankLoad() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        setTimeout(() => {
            this.loderService.dismiss();
        }, 1000);
    }
    getBanks() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        // this.loderService.showLoading(loadingParams);
        this.commonService.get('getDSRBanks').subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.banks = JSON.parse(res.ResponseMessage).Table;
                // this.loderService.dismiss();
            }
            else {
                // this.loderService.dismiss();
                console.log("Banks not found");
            }
        }), (err) => {
            // this.loderService.dismiss();
            console.log("error", err);
        };
    }
    bankNameChange(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.drsFrom.get('bank_Branch_Name').setValue('');
            this.drsFrom.get('branch_Code').setValue('');
            let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
            //this.loderService.showLoading(loadingParams);
            yield this.commonService.post('getDSRBankBranchDtls', event.value).subscribe((res) => {
                if (res.ResponseFlag == 1) {
                    this.loderService.dismiss();
                    this.branchNames = JSON.parse(res.ResponseMessage).Table;
                    // console.log("branch name", this.branchNames);
                    this.checkSpaicelChar(event);
                }
                else {
                    this.loderService.dismiss();
                    console.log("bank branch name not found");
                }
            }), (err) => {
                this.loderService.dismiss();
                console.log("error", err);
            };
        });
    }
    bankBranchClick() {
        let loderTime = 0;
        if (this.branchNames.length <= 200) {
            console.log("1");
            loderTime = 1000;
        }
        else if (this.branchNames.length > 200 && this.branchNames.length < 400) {
            loderTime = 2000;
        }
        else if (this.branchNames.length > 401 && this.branchNames.length < 600) {
            loderTime = 3000;
        }
        else if (this.branchNames.length > 601 && this.branchNames.length < 900) {
            loderTime = 4000;
        }
        else if (this.branchNames.length > 901 && this.branchNames.length < 3000) {
            loderTime = 5000;
        }
        else {
            loderTime = 3000;
        }
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        //this.loderService.showLoading(loadingParams);
        setTimeout(() => {
            this.loderService.dismiss();
        }, loderTime);
    }
    bankBranchNameChange(event) {
        this.commonService.post('getDSRBankBranchCode', event.value).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.bankBranchCode = JSON.parse(res.ResponseMessage).Table[0].bank_Branch_Code;
                this.checkSpaicelChar(event);
            }
            else {
                console.log("bank branch code not found");
            }
        }), (err) => {
            console.log("error", err);
        };
    }
    getZone() {
        this.commonService.post('DSRLogin', { userName: this.userEmpCode }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                let zone = JSON.parse(res.ResponseMessage).Table[0];
                this.drsFrom.get('zone').setValue(zone);
                // console.log("zone data", zone);
            }
            else {
                this.toastService.toast("Zone Not Found");
            }
        });
    }
    chngeZone(e) {
        this.submitted = true;
        let zone = e.target.value;
        if (zone.length != 0) {
            let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
            //this.loderService.showLoading(loadingParams);
            this.commonService.post('getLeaderDtlsWithZone', { userName: this.userEmpCode, zones: zone }).subscribe((res) => {
                if (res.ResponseFlag == 1) {
                    this.loderService.dismiss();
                    this.managerData = JSON.parse(res.ResponseMessage).Table;
                    if (this.managerData.length == 0) {
                        this.toastService.toast("Manager Not Found.!!");
                    }
                    // console.log("Managers ", this.managerData);
                }
                else {
                    this.loderService.dismiss();
                    this.toastService.toast("Manager Not Found");
                }
            });
        }
    }
    chngeManagers(e) {
        this.submitted = true;
        let manager = e.target.value;
        if (manager.length != 0) {
            let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
            //this.loderService.showLoading(loadingParams);
            this.commonService.post('ZoneManagerfilters', { zone: [], manager: manager }).subscribe((res) => {
                if (res.ResponseFlag == 1) {
                    let data = JSON.parse(res.ResponseMessage).Table;
                    for (let i = 0; i < data.length; i++) {
                        if (data[i].subTypeOfActivity.length > 10) {
                            data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                            // console.log("sub data", data[i].subTypeOfActivity);
                        }
                        else {
                            data[i].subTypeOfActivity = [];
                        }
                    }
                    this.filterData = data;
                    // console.log("dsr data", data);
                    this.loderService.dismiss();
                }
                else {
                    this.loderService.dismiss();
                    this.toastService.toast("Data Not Found");
                }
            }, (err) => {
                console.log(err, "error");
            });
        }
    }
    getUserName() {
        this.route.queryParamMap.subscribe((params) => {
            if (params.params.item) {
                let item = JSON.parse(params.params.item);
                this.userEmpCode = item;
                // this.userFlag = item.flag;
                // console.log("url data", item);
                // this.getDSRActivityData();
            }
            else {
                const get = this.authanticationSer.getSession('authData');
                this.userData = JSON.parse(atob(get));
                // this.userData = this.authanticationSer.getSession('authData');
                this.userEmpCode = this.userData.EmpCode;
                this.userFlag = this.userData.flag;
                this.userZone = this.userData.zone;
                // console.log("else user id", this.userName);
            }
        });
    }
    applyFilters() {
        let formData = this.filterForm.value;
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        //this.loderService.showLoading(loadingParams);
        let bank = [this.filterForm.value.bank];
        let bb = [];
        var d = bank[0];
        if ((d === null || d === void 0 ? void 0 : d.length) > 0) {
            d.forEach(e => {
                bb.push(e.bank_Name);
            });
        }
        let frmData = {
            userId: this.userEmpCode,
            zone: formData.zone ? formData.zone : [],
            bank: formData.bank ? bb : [],
            activity: formData.activity ? formData.activity : [],
            startDate: formData.startDate ? formData.startDate : "",
            endDate: formData.endDate ? formData.endDate : ""
        };
        this.commonService.post('dSRFilter', frmData).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                let data = JSON.parse(res.ResponseMessage).Table;
                for (let i = 0; i < data.length; i++) {
                    if (data[i].subTypeOfActivity.length > 10) {
                        data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                        // console.log("sub data", data[i].subTypeOfActivity);
                    }
                    else {
                        data[i].subTypeOfActivity = [];
                    }
                }
                this.loderService.dismiss();
                this.filterData = data;
                // console.log("api filter data", data);
            }
            else {
                console.log("No Record Found ");
                this.loderService.dismiss();
                this.toastService.toast("No Record Found ");
            }
        }, (err) => {
            console.log(err, "error");
        });
    }
    doRefresh(event) {
        setTimeout(() => {
            this.ngOnInit();
            event.target.complete();
        }, 4000);
    }
    getDSRActivityData() {
        // console.log("id from url", this.userEmpCode);
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        // this.loderService.showLoading(loadingParams);
        this.loderService.loaderStatus.next(true);
        this.commonService.post('getDSRdtls', { userName: this.userEmpCode }).subscribe((res) => {
            // this.loderService.dismiss();
            this.loderService.loaderStatus.next(false);
            if (res.ResponseFlag == 1) {
                let data = JSON.parse(res.ResponseMessage).Table;
                for (let i = 0; i < data.length; i++) {
                    if (data[i].subTypeOfActivity.length > 10) {
                        data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                        // console.log("sub data", data[i].subTypeOfActivity);
                    }
                    else {
                        data[i].subTypeOfActivity = [];
                    }
                }
                this.filterData = data;
                // console.log("dsr data", this.filterData);
            }
            else {
                // this.loderService.dismiss();
                this.loderService.loaderStatus.next(false);
            }
        }, (err) => {
            console.log(err, "error");
            // this.loderService.dismiss();
            this.loderService.loaderStatus.next(false);
        });
    }
    subTypeOfActivity() {
        return this.drsFrom.get("subTypeOfActivity");
    }
    newSubTypeOfActivity() {
        return this.fb.group({
            subTypeOfActivity: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
            subStartTime: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
            subEndTime: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
            subDuration: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
            premium_Collected: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]],
        });
    }
    addSubTypeOfActivity() {
        this.subTypeOfActivity().push(this.newSubTypeOfActivity());
    }
    removeSubTypeActivity(i) {
        this.subTypeOfActivity().removeAt(i);
    }
    startTimeChange(e) {
        // console.log("start time", e.target.value);
        this.startTime = e.target.value;
        this.end_Time_picker = false;
        if (this.endTime >= this.startTime) {
            var ms = moment__WEBPACK_IMPORTED_MODULE_2__(this.endTime, "HH:mm").diff(moment__WEBPACK_IMPORTED_MODULE_2__(this.startTime, "HH:mm"));
            var d = moment__WEBPACK_IMPORTED_MODULE_2__.duration(ms);
            this.Duration = Math.floor(d.asHours()) + moment__WEBPACK_IMPORTED_MODULE_2__.utc(ms).format(":mm");
            // console.log("change duration", this.Duration);
        }
        else {
            if (this.endTime <= this.startTime) {
                this.toastService.toast("End time should be greater than start time");
                // console.log("time not match");
            }
        }
        // console.log("chesk start time and end time", this.startTime, this.endTime);
    }
    endTimeChange(e) {
        this.endTime = e.target.value;
        if (this.endTime >= this.startTime) {
            var ms = moment__WEBPACK_IMPORTED_MODULE_2__(this.endTime, "HH:mm").diff(moment__WEBPACK_IMPORTED_MODULE_2__(this.startTime, "HH:mm"));
            var d = moment__WEBPACK_IMPORTED_MODULE_2__.duration(ms);
            this.Duration = Math.floor(d.asHours()) + moment__WEBPACK_IMPORTED_MODULE_2__.utc(ms).format(":mm");
            // console.log("correct", this.Duration);
        }
        else {
            this.toastService.toast("End time should be greater than start time, , Select another time");
            // console.log("wrong");
        }
    }
    substartTimeChange(e) {
        // console.log("start time", e.target.value);
        this.startTime = e.target.value;
        this.end_Time_picker = false;
        if (this.endTime >= this.startTime) {
            var ms = moment__WEBPACK_IMPORTED_MODULE_2__(this.endTime, "HH:mm").diff(moment__WEBPACK_IMPORTED_MODULE_2__(this.startTime, "HH:mm"));
            var d = moment__WEBPACK_IMPORTED_MODULE_2__.duration(ms);
            this.Duration = Math.floor(d.asHours()) + moment__WEBPACK_IMPORTED_MODULE_2__.utc(ms).format(":mm");
            // console.log("change duration", this.Duration);
        }
        else {
            if (this.endTime <= this.startTime) {
                this.toastService.toast("End time should be greater than start time");
                // console.log("time not match");
            }
        }
        // console.log("chesk start time and end time", this.startTime, this.endTime);
    }
    subendTimeChange(e, activity) {
        this.endTime = e.target.value;
        if (this.endTime >= this.startTime) {
            var ms = moment__WEBPACK_IMPORTED_MODULE_2__(this.endTime, "HH:mm").diff(moment__WEBPACK_IMPORTED_MODULE_2__(this.startTime, "HH:mm"));
            var d = moment__WEBPACK_IMPORTED_MODULE_2__.duration(ms);
            let duration = Math.floor(d.asHours()) + moment__WEBPACK_IMPORTED_MODULE_2__.utc(ms).format(":mm");
            activity.controls['subDuration'].setValue(duration);
            // console.log("correct", this.Duration);
        }
        else {
            this.toastService.toast("End time should be greater than start time, , Select another time");
            // console.log("wrong");
        }
    }
    searchData() {
        var result = this.filterData.filter(a => {
            var data = a.date;
            return data;
        });
        if (result.length > 0) {
            this.filterData = result;
            // console.log("data is comeing", this.filterData)
        }
        else {
            this.filterData = this.filterData;
        }
    }
    AddDsrActivity() {
        // this.userData = this.authanticationSer.getSession('authData');
        const get = this.authanticationSer.getSession('authData');
        this.userData = JSON.parse(atob(get));
        this.userFlag = this.userData.flag;
        this.authTl = this.userData.ReportingManager1Empcode;
        this.ExecutiveName = this.userData.EmpName;
        this.userEmpCode = this.userData.EmpCode;
        this.userZone = this.userData.zone;
        // console.log("authData", this.userData);
        this.drsFrom.get('executive').setValue(this.ExecutiveName);
        this.drsFrom.get('team_Leader').setValue(this.authTl);
        this.drsFrom.get('auth_role').setValue(this.userFlag);
        this.drsFrom.get('userName').setValue(this.userEmpCode);
        this.drsFrom.get('zone').setValue(this.userZone);
        this.PremiumFooter = false;
        this.dsrActivityAdd = true;
        this.dsrDetails = !this.dsrDetails;
        this.openFilter = false;
        this.searchBar = false;
        this.emptyRecord = !this.emptyRecord;
    }
    closeAddActivity() {
        this.dsrDetails = true;
        this.dsrActivityAdd = false;
        this.PremiumFooter = this.PremiumFooter == true ? false : true;
    }
    onSubmit() {
        var _a, _b;
        if (this.drsFrom.invalid) {
            this.toastService.toast("Please check mandatory fields and can not use special character & symbols");
        }
        this.submitted = true;
        let obj = this.drsFrom.value;
        obj.bank_Name = (_a = obj.bank_Name) === null || _a === void 0 ? void 0 : _a.bank_Name;
        obj.bank_Branch_Name = (_b = obj.bank_Branch_Name) === null || _b === void 0 ? void 0 : _b.bank_Branch_Name;
        console.log("add data", obj);
        if (this.drsFrom.valid) {
            this.commonService.post('addDSRdtls', obj).subscribe(res => {
                this.getTotalPremium();
                this.toastService.toast("DSR activity data has been saved successfully !");
                this.drsFrom.reset();
                this.dsrActivityAdd = false;
                this.dsrDetails = true;
                this.openFilter = false;
                this.PremiumFooter = this.PremiumFooter == true ? false : true;
                this.getDSRActivityData();
            });
        }
    }
    getTotalPremium() {
        // { "userName": this.userEmpCode }
        this.commonService.post('getTotalPremium', { '': '' }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.totalPremium = JSON.parse(res.ResponseMessage).Table[0].TotalPremium;
                // this.totalPremium = JSON.parse(res.ResponseMessage).Table[0];
            }
            else {
                // console.log("Total Premium not found");
            }
        }), (err) => {
            // console.log("error", err);
        };
    }
    filterSubmit() {
        this.submitted = true;
        var data = this.filterForm.value;
        var startDate = data.startDate;
        var endDate = data.endDate;
        var result = this.filterData.filter(a => {
            var date = a.date_Of_Visit;
            return (date >= startDate && date <= endDate);
        });
        if (result.length > 0) {
            this.filterData = result;
        }
        else {
            this.filterData = this.filterData;
        }
    }
    minMaxDate() {
        var date = new Date();
        var datestrings = (date.getFullYear()) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + date.getDate()).slice(-2);
        this.maxDate = datestrings;
        var tempDate = new Date(date.setDate(date.getDate() - 1));
        var minDateString = (tempDate.getFullYear()) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + tempDate.getDate()).slice(-2);
        this.minDate = minDateString;
    }
    clearFilterForm() {
        this.filterForm.reset();
        this.getDSRActivityData();
        this.getBanks();
        this.getZones();
    }
    clearManagerFilter() {
        this.managerForm.reset();
        this.getUserName();
        this.getDSRActivityData();
        this.getZones();
    }
    filterClose() {
        this.openFilter = false;
        this.PremiumFooter = this.PremiumFooter == true ? false : true;
    }
    filterOpen() {
        this.searchBar = false;
        this.openFilter = !this.openFilter;
        this.PremiumFooter = this.PremiumFooter == true ? false : false;
        this.dsrDetails = true;
        this.dsrActivityAdd = false;
        if (this.userFlag <= 1) {
            this.segmentValue = "zone";
            // console.log("zone here");
        }
        else {
            this.segmentValue = "manager";
            // console.log("manager here");
        }
        this.getZones();
    }
    getZones() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        // this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRZone', { userName: this.userEmpCode }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                // this.loderService.dismiss();
                this.zoneData = JSON.parse(res.ResponseMessage).Table;
            }
            else {
                // this.loderService.dismiss();
                this.toastService.toast("Zone Not Found");
            }
        });
    }
    excelExport(tblId) {
        let d = this.excelexportService.exportExcel(tblId, 'DSR-Activity');
        // console.log("xl", d);
    }
    segmentChanged(e) {
        this.segmentValue = e.target.value;
    }
    searchIcon() {
        this.dsrActivityAdd = false;
        this.dsrDetails = true;
        this.searchBar = !this.searchBar;
        this.openFilter = false;
        this.PremiumFooter = false;
    }
    checkSpaicelChar(event) {
        var format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
        if (format.test(event.target.value) == true) {
            let controlName = event.srcElement.attributes.formcontrolname.nodeValue;
            this.drsFrom.get(`${controlName}`).setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]);
            this.toastService.toast('can not use special character & symbols');
            return true;
        }
        else {
            return false;
        }
    }
    backButton() {
        history.back();
    }
};
DsrActivityComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder },
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__.DataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.PopoverController },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _services_excelexport_service__WEBPACK_IMPORTED_MODULE_4__.ExcelexportService },
    { type: _services_components_loder_service__WEBPACK_IMPORTED_MODULE_6__.LoderService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_7__.CommonService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute },
    { type: _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_8__.AuthenticationService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router }
];
DsrActivityComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-dsrActivity',
        template: _dsrActivity_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_dsrActivity_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DsrActivityComponent);



/***/ }),

/***/ 5067:
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.component.html?ngResource */ 4715);
/* harmony import */ var _home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.component.scss?ngResource */ 961);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth/authentication.service */ 6406);
/* harmony import */ var _services_shared_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/shared-data.service */ 1679);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/file/ngx */ 2358);
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ 1059);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 1832);
/* harmony import */ var cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! cordova-plugin-apkupdater */ 5277);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/app-version/ngx */ 4582);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../services/common.service */ 5620);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 2816);






// for file download apk 









let HomeComponent = class HomeComponent {
    constructor(sharedDataService, authanticationSer, platform, commonService, router, 
    // for download apk file
    file, fileTransfer, androidPermissions, _zone, appVersion, alertController) {
        this.sharedDataService = sharedDataService;
        this.authanticationSer = authanticationSer;
        this.platform = platform;
        this.commonService = commonService;
        this.router = router;
        this.file = file;
        this.fileTransfer = fileTransfer;
        this.androidPermissions = androidPermissions;
        this._zone = _zone;
        this.appVersion = appVersion;
        this.alertController = alertController;
        this.titleMsg = "Home Page";
        this.slideOpts = {
            initialSlide: 1,
            speed: 400,
            loop: true,
            autoplay: {
                delay: 4000,
                reverseDirection: false
            }
        };
        this.progressBar = false;
        this.showError = false;
        this.deviceReady();
        // setInterval(() => {
        //   this.progress += 0.01;
        //   // Reset the progress bar when it reaches 100%
        //   // to continuously show the demo
        //   if (this.progress > 1) {
        //     setTimeout(() => {
        //       this.progress = 0;
        //     }, 1000);
        //   }
        // }, 50);
    }
    ngOnInit() {
        this.getData();
    }
    onMenuOpen() {
        this.getData();
    }
    getData() {
        this.sharedDataService.data.subscribe(res => {
            this.userFlag = res.flag;
        });
        const get = this.authanticationSer.getSession('authData');
        this.userData = JSON.parse(atob(get));
        // console.log("get",this.userData);
        // this.userData = this.authanticationSer.getSession('authData');
        this.userEmpCode = this.userData.Empcode;
        this.userFlag = this.userData.flag;
        this.sharedDataService.sendData(this.userData);
    }
    //  auto download latest app version
    deviceReady() {
        this.platform.ready().then(() => {
            if (this.platform.is('android') || this.platform.is('ios')) {
                this.appVersion.getVersionNumber().then(response => {
                    this.appVersionNumber = response;
                    var version;
                    this.commonService.get('getDSRAppVersion').subscribe((res) => {
                        if (res.ResponseFlag == 1) {
                            version = JSON.parse(res.ResponseMessage).Table;
                            // console.log("api version", version);
                            if (this.appVersionNumber != version[0].Version) {
                                if (this.platform.is('ios')) {
                                    console.log("ios version i avilable");
                                }
                                else {
                                    this.appUpdateConfirm();
                                }
                            }
                            else {
                                // console.log("version is match");
                            }
                        }
                        else {
                            // console.log("version not found");
                        }
                    }), (err) => {
                        console.log("error", err);
                    };
                }).catch(error => {
                    alert(error);
                });
            }
        });
    }
    downloadApp() {
        this.checkPermissions();
        const fileTransfer = this.fileTransfer.create();
        fileTransfer.onProgress((progressEvent) => {
            this._zone.run(() => {
                if (progressEvent.lengthComputable) {
                    let lp = progressEvent.loaded / progressEvent.total * 100;
                    this.progress = Math.round(lp * 100) / 100;
                }
            });
            // console.log("progress:" + this.progress);
        });
        var url = "https://tinyurl.com/INSTABv2";
        fileTransfer.download(url, this.file.externalDataDirectory + "sample.apk").then((data) => {
            // ApkUpdater.install( success, failure);
            console.log('Download complete: '); //handle success Manoj_ 
            // this.loginBtn = true;
        }, (err) => {
            alert("Download error " + JSON.stringify(err));
        });
    }
    checkPermissions() {
        this.androidPermissions.requestPermissions([
            this.androidPermissions.PERMISSION.CAMERA,
            this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE,
            this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE
        ]);
    }
    appUpdateConfirm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'New version available! ',
                message: 'Please update new version ',
                mode: 'ios',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Update',
                        handler: () => {
                            // this.authanticationSer.removeSession('authData');
                            // window.location.href = "/";
                            // this.loginBtn = false;
                            this.progressBar = true;
                            // this.downloadApp();
                            this.update();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    update() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const installedVersion = (yield cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_7__["default"].getInstalledVersion());
            console.log("versions", installedVersion);
            yield cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_7__["default"].download('https://online.futuregenerali.in/DSR/FgBancaConnectMain.zip', {
                // https://online.futuregenerali.in/DSR/FgBancaConnectMain.zip
                onDownloadProgress: (e) => {
                    this._zone.run(() => {
                        var _a;
                        this.progress = (_a = e === null || e === void 0 ? void 0 : e.progress) !== null && _a !== void 0 ? _a : 0;
                    });
                    console.log(e.progress, this.progress);
                },
                onUnzipProgress: console.log
            }, () => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
                yield cordova_plugin_apkupdater__WEBPACK_IMPORTED_MODULE_7__["default"].install(console.log, console.error);
            }), (error) => {
                console.error(error);
            });
        });
    }
};
HomeComponent.ctorParameters = () => [
    { type: _services_shared_data_service__WEBPACK_IMPORTED_MODULE_3__.SharedDataService },
    { type: _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__.AuthenticationService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_9__.CommonService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.Router },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_4__.File },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_5__.FileTransfer },
    { type: _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_6__.AndroidPermissions },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_13__.NgZone },
    { type: _awesome_cordova_plugins_app_version_ngx__WEBPACK_IMPORTED_MODULE_8__.AppVersion },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.AlertController }
];
HomeComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-home',
        template: _home_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomeComponent);



/***/ }),

/***/ 5527:
/*!******************************************************!*\
  !*** ./src/app/network-err/network-err.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NetworkErrComponent": () => (/* binding */ NetworkErrComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _network_err_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./network-err.component.html?ngResource */ 3045);
/* harmony import */ var _network_err_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./network-err.component.scss?ngResource */ 6174);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_components_loder_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/components/loder.service */ 6552);
/* harmony import */ var _services_network_check_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/network-check.service */ 4886);







let NetworkErrComponent = class NetworkErrComponent {
    constructor(menuCtrl, loderService, NetworkCheckService) {
        this.menuCtrl = menuCtrl;
        this.loderService = loderService;
        this.NetworkCheckService = NetworkCheckService;
    }
    ngOnInit() {
        this.loderService.dismiss();
        this.menuCtrl.enable(false);
    }
    exitApp() {
        this.NetworkCheckService.ngOnInit();
        // navigator['app'].exitApp();
    }
};
NetworkErrComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController },
    { type: _services_components_loder_service__WEBPACK_IMPORTED_MODULE_2__.LoderService },
    { type: _services_network_check_service__WEBPACK_IMPORTED_MODULE_3__.NetworkCheckService }
];
NetworkErrComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-network-err',
        template: _network_err_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_network_err_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NetworkErrComponent);



/***/ }),

/***/ 8562:
/*!********************************************!*\
  !*** ./src/app/report/report.component.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportComponent": () => (/* binding */ ReportComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _report_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./report.component.html?ngResource */ 9779);
/* harmony import */ var _report_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./report.component.scss?ngResource */ 9320);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth/authentication.service */ 6406);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/common.service */ 5620);
/* harmony import */ var _services_components_loder_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/components/loder.service */ 6552);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/components/toast.service */ 8923);
/* harmony import */ var _services_excelexport_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/excelexport.service */ 8938);










class Banks {
}
let ReportComponent = class ReportComponent {
    constructor(fb, loderService, commonService, toastService, excelexportService, authanticationSer) {
        this.fb = fb;
        this.loderService = loderService;
        this.commonService = commonService;
        this.toastService = toastService;
        this.excelexportService = excelexportService;
        this.authanticationSer = authanticationSer;
        this.titleMsg = 'Reports';
        this.openFilter = true;
        this.segmentValue = "manager";
        this.searchBar = false;
        this.showmangerDrop = false;
        this.dsrDetails = true;
        this.filterData = [];
        this.submitted = false;
    }
    ngOnInit() {
        this.getUserName();
        this.getBanks();
        this.getZones();
        // this.getDSRActivityData();
        this.filterForm = this.fb.group({
            bank: [''],
            zone: [''],
            startDate: [''],
            activity: [''],
            endDate: ['']
        });
        this.managerForm = this.fb.group({
            zone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            manager: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
        });
    }
    filterOpen() {
        this.openFilter = !this.openFilter;
        this.segmentValue = "manager";
        this.getBanks();
        this.getZones();
    }
    closeFilter() {
        this.openFilter = false;
    }
    getDSRActivityData() {
        // console.log("id from url", this.userEmpCode);
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRdtls', { userName: this.userEmpCode }).subscribe((res) => {
            this.loderService.dismiss();
            if (res.ResponseFlag == 1) {
                let data = JSON.parse(res.ResponseMessage).Table;
                for (let i = 0; i < data.length; i++) {
                    if (data[i].subTypeOfActivity.length > 10) {
                        data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                        // console.log("sub data", data[i].subTypeOfActivity);
                    }
                    else {
                        data[i].subTypeOfActivity = [];
                    }
                }
                this.filterData = data;
                // console.log("dsr data", this.filterData);
            }
        }, (err) => {
            console.log(err, "error");
        });
    }
    applyFilters() {
        let formData = this.filterForm.value;
        // console.log("filter formData", formData);
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        let bank = [this.filterForm.value.bank];
        let bb = [];
        var d = bank[0];
        if ((d === null || d === void 0 ? void 0 : d.length) > 0) {
            d.forEach(e => {
                bb.push(e.bank_Name);
            });
        }
        let frmData = {
            userId: this.userEmpCode,
            zone: formData.zone ? formData.zone : [],
            bank: formData.bank ? bb : [],
            activity: formData.activity ? formData.activity : [],
            startDate: formData.startDate ? formData.startDate : "",
            endDate: formData.endDate ? formData.endDate : ""
        };
        this.commonService.post('dSRFilter', frmData).subscribe((res) => {
            this.loderService.dismiss();
            if (res.ResponseFlag == 1) {
                let data = JSON.parse(res.ResponseMessage).Table;
                for (let i = 0; i < data.length; i++) {
                    if (data[i].subTypeOfActivity.length > 10) {
                        data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                        // console.log("sub data", data[i].subTypeOfActivity);
                    }
                    else {
                        data[i].subTypeOfActivity = [];
                    }
                }
                this.filterData = data;
                // console.log("api filter data", data);
            }
            else {
                console.log("No Record Found ");
                this.toastService.toast("No Record Found ");
            }
        }, (err) => {
            console.log(err, "error");
            this.loderService.dismiss();
        });
    }
    segmentChanged(e) {
        this.segmentValue = e.target.value;
    }
    chngeZone(e) {
        this.submitted = true;
        this.zoneChange = e.target.value;
        // console.log("zone", this.zoneChange)
        if (this.zoneChange.length != 0) {
            let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
            this.loderService.showLoading(loadingParams);
            this.commonService.post('getLeaderDtlsWithZone', { userName: this.userEmpCode, zones: this.zoneChange }).subscribe((res) => {
                this.loderService.dismiss();
                if (res.ResponseFlag == 1) {
                    this.managerData = JSON.parse(res.ResponseMessage).Table;
                    this.showmangerDrop = false;
                    if (this.managerData.length == 0) {
                        this.managerData = null;
                        this.showmangerDrop = true;
                        this.toastService.toast("Manager Not Found !");
                    }
                    // console.log("Managers ", this.managerData);
                }
                else {
                    this.toastService.toast("Manager Not Found !");
                }
            });
        }
    }
    getZones() {
        this.commonService.post('getDSRZone', { userName: this.userEmpCode }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.zoneData = JSON.parse(res.ResponseMessage).Table;
            }
            else {
                this.toastService.toast("Zone Not Found");
            }
        });
    }
    chngeManagers(e) {
        this.submitted = true;
        let manager = e.target.value;
        if (manager.length != 0) {
            let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
            this.loderService.showLoading(loadingParams);
            this.commonService.post('ZoneManagerfilters', { zone: this.zoneChange, manager: manager }).subscribe((res) => {
                this.loderService.dismiss();
                if (res.ResponseFlag == 1) {
                    let data = JSON.parse(res.ResponseMessage).Table;
                    for (let i = 0; i < data.length; i++) {
                        if (data[i].subTypeOfActivity.length > 10) {
                            data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                            // console.log("sub data", data[i].subTypeOfActivity);
                        }
                        else {
                            data[i].subTypeOfActivity = [];
                            this.toastService.toast("Data Not Found");
                        }
                    }
                    this.filterData = data;
                    // console.log("dsr data", data);
                }
                else {
                    this.toastService.toast("Data Not Found");
                }
            }, (err) => {
                console.log(err, "error");
            });
        }
    }
    getBanks() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        this.commonService.get('getDSRBanks').subscribe((res) => {
            this.loderService.dismiss();
            if (res.ResponseFlag == 1) {
                this.banks = JSON.parse(res.ResponseMessage).Table;
                // console.log("Banks found",this.banks);
            }
            else {
                console.log("Banks not found");
            }
        }), (err) => {
            console.log("error", err);
        };
    }
    getUserName() {
        // this.userData = this.authanticationSer.getSession('authData');
        const get = this.authanticationSer.getSession('authData');
        this.userData = JSON.parse(atob(get));
        this.userEmpCode = this.userData.EmpCode;
        this.userFlag = this.userData.flag;
    }
    clearFilterForm() {
        this.filterForm.reset();
        // this.getDSRActivityData();
        this.filterData.length = [0];
    }
    excelExport(tblId) {
        let d = this.excelexportService.exportExcel(tblId, 'DSR-Activity');
    }
    searchIcon() {
        this.searchBar = !this.searchBar;
    }
    clearManagerFilter() {
        this.managerForm.reset();
        this.getUserName();
        this.filterData.length = [0];
        // this.getDSRActivityData();
    }
};
ReportComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _services_components_loder_service__WEBPACK_IMPORTED_MODULE_4__.LoderService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _services_excelexport_service__WEBPACK_IMPORTED_MODULE_6__.ExcelexportService },
    { type: _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__.AuthenticationService }
];
ReportComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-report',
        template: _report_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_report_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ReportComponent);



/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let AuthService = class AuthService {
    constructor(http) {
        this.http = http;
        this.api = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.baseUrl;
    }
    login(obj) {
        // return this.http.post(this.api + '/MobileApp/DSRLogin',obj);
        return this.http.post(this.api + '/Login/Authenticate', obj);
    }
    getReportingManager(obj) {
        return this.http.post(this.api + '/Common/getEmp', obj);
    }
    getToken() {
        if (sessionStorage.Token) {
            return sessionStorage.getItem("Token").replace(/['"]/g, '');
        }
        else {
        }
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 6406:
/*!*********************************************************!*\
  !*** ./src/app/services/auth/authentication.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthenticationService": () => (/* binding */ AuthenticationService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 2816);



let AuthenticationService = class AuthenticationService {
    constructor(router) {
        this.router = router;
    }
    // session storage start here 
    setSession(key, data) {
        sessionStorage.setItem(key, JSON.stringify(data));
    }
    getSession(key) {
        if (sessionStorage.authData) {
            // const get=sessionStorage.getItem('authData');
            // const objStr = atob(get)
            // console.log("decode data", objStr)
            // const obj = JSON.parse( atob(get));
            // console.log("parse data",obj)
            return JSON.parse(sessionStorage.getItem(key));
        }
        else {
            this.router.navigate(['/home']);
            console.log("Auth Data Not Found");
        }
    }
    removeSession(key) {
        sessionStorage.removeItem(key);
    }
    clearSession() {
        sessionStorage.clear();
    }
    // local storage start here 
    setLocal(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }
    getLocal(key) {
        localStorage.getItem(key);
    }
    removeLocal(key) {
        localStorage.removeItem(key);
    }
    clearLocal() {
        localStorage.clear();
    }
};
AuthenticationService.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_0__.Router }
];
AuthenticationService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], AuthenticationService);



/***/ }),

/***/ 5620:
/*!********************************************!*\
  !*** ./src/app/services/common.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommonService": () => (/* binding */ CommonService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../environments/environment */ 2340);




let CommonService = class CommonService {
    constructor(http) {
        this.http = http;
        this.headers = { 'content-type': 'application/json' };
        if (window.location.hostname == 'localhost') {
            this.api = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.baseUrl;
        }
        else {
            this.api = location.protocol + "//" + location.hostname + "/TeamTrack/api";
            // this.api = location.protocol + "//" + location.hostname + "/DSR/";
        }
    }
    get(method) {
        return this.http.get(this.api + `/MobileApp/${method}`, { 'headers': this.headers });
    }
    post(method, obj) {
        return this.http.post(this.api + `/MobileApp/${method}`, obj, { 'headers': this.headers });
    }
    // getLeadersData(obj:any): Observable<any> {
    //   return this.http.post(this.api + '/MobileApp/getDSRleaders', obj);
    // }
    // getAll(obj:any): Observable<any> {
    //   return this.http.post(this.api + '/MobileApp/getDSRdtls', obj);
    // }
    // getPremium(obj:any): Observable<any> {
    //   return this.http.post(this.api + '/MobileApp/getTotalPremium', obj,{'headers':this.headers});
    // }
    // createDsrActivity(obj:any): Observable<any> {
    //   return this.http.post(this.api + '/MobileApp/addDSRdtls', obj);
    // }
    // getTeamsActivity(obj:any): Observable<any> {
    //   return this.http.post(this.api + '/MobileApp/getDSRIndivisualCounts', obj);
    // }
    // getZone(obj:any): Observable<any> {
    //   return this.http.post(this.api + '/MobileApp/getDSRZone', obj);
    // }
    getDsrWithZone(obj) {
        const header = { 'content-type': 'application/json' };
        return this.http.post(this.api + '/MobileApp/getDSRWithZone', obj, { 'headers': header });
    }
    // getYesturdayData(obj:any): Observable<any> {
    //   const header ={'content-type':'application/json'}
    //   return this.http.post(this.api + '/MobileApp/getDSRlastday', obj ,{'headers':header});
    // }
    // getMonthData(obj:any): Observable<any> {
    //   const header ={'content-type':'application/json'}
    //   return this.http.post(this.api + '/MobileApp/getDSRlastMonth', obj ,{'headers':header});
    // }
    getReportData(obj) {
        const header = { 'content-type': 'application/json' };
        return this.http.post(this.api + '/MobileApp/getDSRDtls', obj, { 'headers': header });
    }
};
CommonService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
CommonService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], CommonService);



/***/ }),

/***/ 1362:
/*!********************************************************************!*\
  !*** ./src/app/services/components/dropdown/dropdown.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DropdownComponent": () => (/* binding */ DropdownComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _dropdown_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dropdown.component.html?ngResource */ 7032);
/* harmony import */ var _dropdown_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dropdown.component.scss?ngResource */ 6383);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 3819);





let DropdownComponent = class DropdownComponent {
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
        this.data = [
            { name: 'manoj', id: 1 },
            { name: 'amit', id: 2 },
            { name: 'sumit', id: 3 },
            { name: 'joni', id: 4 },
            { name: 'rahul', id: 5 },
        ];
    }
    ngOnInit() {
    }
    cancel() {
        return this.modalCtrl.dismiss(null, 'cancel');
    }
    confirm() {
        return this.modalCtrl.dismiss(this.name, 'confirm');
    }
    onTermsChanged(event) {
        const ev = event;
        this.name = ev.detail.value;
        console.log(ev);
        return this.modalCtrl.dismiss(this.name, 'confirm');
    }
};
DropdownComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController }
];
DropdownComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-dropdown',
        template: _dropdown_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_dropdown_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DropdownComponent);



/***/ }),

/***/ 6552:
/*!******************************************************!*\
  !*** ./src/app/services/components/loder.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoderService": () => (/* binding */ LoderService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);




let LoderService = class LoderService {
    constructor(loadingCtrl) {
        this.loadingCtrl = loadingCtrl;
        this.loaderStatus = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(false);
    }
    showLoading(params = {}) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                message: params.msg ? params.msg : 'Please Wait...',
                spinner: params.spinner ? params.spinner : 'circles',
                mode: params.mode ? params.mode : 'ios',
                cssClass: params.class ? params.class : 'custom-loading',
                backdropDismiss: params.backdropDismiss ? params.backdropDismiss : false,
            });
            loading.present();
        });
    }
    dismiss() {
        this.dismissed();
        // this.loadingCtrl.dismiss().then(a => console.log('dismissed'));
    }
    // async dismissed() {
    //   return await this.loadingCtrl.dismiss().then(() => console.log('loader dismissed'));
    // }
    dismissed() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            let topLoader = yield this.loadingCtrl.getTop();
            while (topLoader) {
                if (!(yield topLoader.dismiss())) {
                    throw new Error('Loader is dismiss');
                }
                topLoader = yield this.loadingCtrl.getTop();
            }
        });
    }
};
LoderService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.LoadingController }
];
LoderService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], LoderService);



/***/ }),

/***/ 8923:
/*!******************************************************!*\
  !*** ./src/app/services/components/toast.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToastService": () => (/* binding */ ToastService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 3819);



let ToastService = class ToastService {
    constructor(toastController) {
        this.toastController = toastController;
    }
    toast(msg) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msg,
                duration: 3000,
                cssClass: "toast_style",
                mode: 'ios'
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ToastController }
];
ToastService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ToastService);



/***/ }),

/***/ 8240:
/*!*****************************************************************!*\
  !*** ./src/app/services/custom-popup/custom-popup.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomPopupComponent": () => (/* binding */ CustomPopupComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _custom_popup_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./custom-popup.component.html?ngResource */ 7393);
/* harmony import */ var _custom_popup_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./custom-popup.component.scss?ngResource */ 6635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




let CustomPopupComponent = class CustomPopupComponent {
    constructor() {
        this.popuptype = "";
        this.eapprovalNo = "";
        this.winNo = "";
        this.parentFun = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.closePopup = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.dismissPopup = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    ngOnInit() {
    }
    update() {
        this.parentFun.emit();
    }
    dismiss() {
        this.dismissPopup.emit();
    }
    close() {
        this.closePopup.emit();
    }
};
CustomPopupComponent.ctorParameters = () => [];
CustomPopupComponent.propDecorators = {
    popuptype: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    eapprovalNo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    winNo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    parentFun: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output, args: ["parentFun",] }],
    closePopup: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output, args: ["closePopup",] }],
    dismissPopup: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output, args: ["dismissPopup",] }]
};
CustomPopupComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-custom-popup',
        template: _custom_popup_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_custom_popup_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomPopupComponent);



/***/ }),

/***/ 2468:
/*!******************************************!*\
  !*** ./src/app/services/data.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let DataService = class DataService {
    constructor() {
        this.filterData = [
            { id: 1, date: "2022-01-02", name: "ram" },
            { id: 12, date: "2022-01-02", name: "ram3" },
            { id: 2, date: "2022-01-03", name: "ram4" },
            { id: 3, date: "2022-01-04", name: "shyam" },
            { id: 4, date: "2022-01-05", name: "mohit" },
            { id: 5, date: "2022-01-06", name: "sohit" },
            { id: 11, date: "2022-01-06", name: "sohit2" },
            { id: 6, date: "2022-01-07", name: "sumit" },
            { id: 7, date: "2022-01-08", name: "amit" },
            { id: 8, date: "2022-01-01", name: "rahul" },
            { id: 9, date: "2022-01-09", name: "bhola" },
            { id: 10, date: "2022-01-10", name: "aman" },
        ];
        this.LeaderData = [
            { id: 1, name: "ram", entry: 50, leader: "Anil Kumar" },
            { id: 2, name: "mohan", entry: 20, leader: "Anil Kumar" },
            { id: 3, name: "sohan", entry: 10, leader: "Anil Kumar" },
            { id: 4, name: "amit", entry: 50, leader: "Anil Kumar" },
            { id: 5, name: "ankit", entry: 30, leader: "Anil Kumar" },
            { id: 6, name: "raju", entry: 500, leader: "Anil Kumar" },
            { id: 7, name: "raja", entry: 50, leader: "Anil Kumar" },
            { id: 8, name: "manoj", entry: 60, leader: "Anil Kumar" },
            { id: 9, name: "soumya", entry: 70, leader: "Anil Kumar" },
        ];
    }
};
DataService.ctorParameters = () => [];
DataService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], DataService);



/***/ }),

/***/ 8938:
/*!*************************************************!*\
  !*** ./src/app/services/excelexport.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExcelexportService": () => (/* binding */ ExcelexportService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! xlsx */ 4126);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 196);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/file/ngx */ 2358);
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ 1059);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 1832);




// for file download apk 



let ExcelexportService = class ExcelexportService {
    constructor(file, fileTransfer, androidPermissions, _zone) {
        this.file = file;
        this.fileTransfer = fileTransfer;
        this.androidPermissions = androidPermissions;
        this._zone = _zone;
    }
    exportExcel(tableId, fileName) {
        /* pass here the table id */
        let element = document.getElementById(tableId);
        const ws = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.table_to_sheet(element);
        /* generate workbook and add the worksheet */
        const wb = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.book_new();
        const d = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.book_append_sheet(wb, ws, 'Sheet1');
        console.log("ws", wb);
        /* save to file */
        var date = new Date();
        var format = moment__WEBPACK_IMPORTED_MODULE_0__(date).format('DD-MM-YYYY');
        var url = xlsx__WEBPACK_IMPORTED_MODULE_4__.writeFile(wb, format + "-" + fileName + '.xlsx');
        // this.downloadApp(url);
        console.log("url", url);
    }
    downloadApp(url) {
        this.checkPermissions();
        const fileTransfer = this.fileTransfer.create();
        fileTransfer.onProgress((progressEvent) => {
            this._zone.run(() => {
                if (progressEvent.lengthComputable) {
                    let lp = progressEvent.loaded / progressEvent.total * 100;
                    this.progress = Math.round(lp * 100) / 100;
                }
            });
            // console.log("progress:" + this.progress);
        });
        // this.url = "https://tinyurl.com/INSTABv2";
        // var path = this.file.externalRootDirectory + '/Download/';
        var path = this.file.applicationDirectory;
        fileTransfer.download(url, path + "sample.xlsx").then((data) => {
            // ApkUpdater.install( success, failure);
            console.log('Download complete.'); //handle success Manoj_ 
        }, (err) => {
            alert("Download error " + JSON.stringify(err));
        });
    }
    checkPermissions() {
        this.androidPermissions.requestPermissions([
            this.androidPermissions.PERMISSION.CAMERA,
            this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE,
            this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE
        ]);
    }
};
ExcelexportService.ctorParameters = () => [
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_1__.File },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_2__.FileTransfer },
    { type: _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_3__.AndroidPermissions },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.NgZone }
];
ExcelexportService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], ExcelexportService);



/***/ }),

/***/ 3980:
/*!***********************************************!*\
  !*** ./src/app/services/guards/auth.guard.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGuard": () => (/* binding */ AuthGuard)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _auth_authentication_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../auth/authentication.service */ 6406);




let AuthGuard = class AuthGuard {
    constructor(router, authanticationSer) {
        this.router = router;
        this.authanticationSer = authanticationSer;
    }
    canActivate(route, state) {
        // if(sessionStorage.getItem('authData')){
        //   return true;
        // }
        // else{
        //   this.router.navigateByUrl('/');
        // }
        let d = this.authanticationSer.getSession('authData');
        if (d) {
            return true;
        }
        else {
            this.router.navigateByUrl('/login');
        }
    }
};
AuthGuard.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router },
    { type: _auth_authentication_service__WEBPACK_IMPORTED_MODULE_0__.AuthenticationService }
];
AuthGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ 1442:
/*!*******************************************************************!*\
  !*** ./src/app/services/interceptor/token-interceptor.service.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TokenInterceptorService": () => (/* binding */ TokenInterceptorService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../auth.service */ 7556);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var src_app_services_components_loder_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/components/loder.service */ 6552);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/components/toast.service */ 8923);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);









let TokenInterceptorService = class TokenInterceptorService {
    constructor(injector, router, loderService, toastService, menuCtrl) {
        this.injector = injector;
        this.router = router;
        this.loderService = loderService;
        this.toastService = toastService;
        this.menuCtrl = menuCtrl;
    }
    intercept(req, next) {
        let authService = this.injector.get(_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService);
        let tokenizedReq = req.clone({
            setHeaders: {
                Authorization: `${authService.getToken()}`,
            }
        });
        // return next.handle(tokenizedReq);
        return next.handle(tokenizedReq).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)((err, caught) => {
            if (sessionStorage.authData) {
                if (err.status === 401) {
                    this.toastService.toast("Session expired or invalid");
                    sessionStorage.removeItem("Token");
                    sessionStorage.removeItem("authData");
                    this.loderService.dismiss();
                    this.router.navigate(['/login'], {});
                    this.loderService.dismiss();
                    this.menuCtrl.enable(false);
                }
            }
            return new rxjs__WEBPACK_IMPORTED_MODULE_4__.Observable();
        }));
    }
};
TokenInterceptorService.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Injector },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: src_app_services_components_loder_service__WEBPACK_IMPORTED_MODULE_1__.LoderService },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_2__.ToastService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController }
];
TokenInterceptorService = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], TokenInterceptorService);



/***/ }),

/***/ 5590:
/*!***********************************************!*\
  !*** ./src/app/services/logindata.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LogindataService": () => (/* binding */ LogindataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let LogindataService = class LogindataService {
    constructor() {
        this.loginData = [
            { id: 1, name: "Manoj", userName: "manoj", password: "manoj", tl: "anil", auth: 3 },
            { id: 2, name: "soumya", userName: "soumya", password: "soumya", tl: "anil", auth: 3 },
            { id: 3, name: "Raja", userName: "raja", password: "raja", tl: "anand", auth: 3 },
            { id: 4, name: "Jalpesh", userName: "jalpesh", password: "jalpesh", tl: "anand", auth: 3 },
            { id: 5, name: "Anil", userName: "anil", password: "anil", tl: "manu", auth: 2 },
            { id: 6, name: "Anand", userName: "anand", password: "anand", tl: "girish", auth: 2 },
            { id: 7, name: "Manuraj", userName: "manuraj", password: "manuraj", auth: 1 },
            { id: 8, name: "Manuraj", userName: "girish", password: "girish", auth: 1 },
            { id: 9, name: "vikram", userName: "head", password: "head", auth: 5 }
        ];
    }
};
LogindataService.ctorParameters = () => [];
LogindataService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], LogindataService);



/***/ }),

/***/ 4886:
/*!***************************************************!*\
  !*** ./src/app/services/network-check.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NetworkCheckService": () => (/* binding */ NetworkCheckService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _awesome_cordova_plugins_network_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @awesome-cordova-plugins/network/ngx */ 6946);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 3819);





let NetworkCheckService = class NetworkCheckService {
    constructor(network, platform, menuCtrl, toastController, router) {
        this.network = network;
        this.platform = platform;
        this.menuCtrl = menuCtrl;
        this.toastController = toastController;
        this.router = router;
    }
    ngOnInit() {
        this.network.onDisconnect().subscribe(() => {
            console.log("we are offline");
            localStorage.removeItem('checkNetwork');
            this.toast(`Please Check Your Internet Connection`);
            this.router.navigateByUrl('/networkerr');
        });
        this.network.onConnect().subscribe(() => {
            if (localStorage.checkNetwork) {
                this.menuCtrl.enable(true);
                console.log("we are online");
                this.toast(`already network in local storage  ${this.network.type}  📶`);
                this.router.navigateByUrl('/home');
            }
            else {
                localStorage.setItem('checkNetwork', JSON.stringify(this.network.type));
                setTimeout(() => {
                    this.menuCtrl.enable(true);
                    this.toast(`We are back online with  ${this.network.type}  📶`);
                    this.router.navigateByUrl('/home');
                }, 2000);
            }
        });
    }
    toast(msg) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.toastController.create({
                header: 'Internet Connection',
                message: msg,
                buttons: ['OK'],
                position: 'bottom',
                duration: 1000,
                animated: true,
                mode: 'ios'
            });
            yield alert.present();
        });
    }
};
NetworkCheckService.ctorParameters = () => [
    { type: _awesome_cordova_plugins_network_ngx__WEBPACK_IMPORTED_MODULE_0__.Network },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ToastController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
NetworkCheckService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], NetworkCheckService);



/***/ }),

/***/ 3401:
/*!***************************************************!*\
  !*** ./src/app/services/pipes/filterdata.pipe.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterdataPipe": () => (/* binding */ FilterdataPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let FilterdataPipe = class FilterdataPipe {
    // old code 
    // transform(value:any, searchText: any): any {
    //   if(value.length===0){
    //     return value;
    //   }
    //   else{
    //     return value.filter(function(search){
    //       return search.type_Of_Activity.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
    //     })
    //   }
    //   // search.type_Of_Activity.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.bank_Name.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.to_Whom_Meet.toLowerCase().indexOf(searchText.toLowerCase()) > -1  || search.bank_Branch_Name.toLowerCase().indexOf(searchText.toLowerCase()) > -1  || search.executive.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
    // }
    transform(value, searchText) {
        if (searchText === undefined)
            return value;
        return value.filter(function (search) {
            return search.type_Of_Activity.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.bank_Name.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.to_Whom_Meet.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.bank_Branch_Name.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.executive.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.zone.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.branch_Code.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.to_Whom_Meet_Number.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.userName.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search.team_Leader.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
        });
    }
};
FilterdataPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'filterdata'
    })
], FilterdataPipe);



/***/ }),

/***/ 1679:
/*!*************************************************!*\
  !*** ./src/app/services/shared-data.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedDataService": () => (/* binding */ SharedDataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);



let SharedDataService = class SharedDataService {
    constructor() {
        this.dataSource = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('Initial Value');
        this.data = this.dataSource.asObservable();
    }
    sendData(data) {
        this.dataSource.next(data);
    }
};
SharedDataService.ctorParameters = () => [];
SharedDataService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], SharedDataService);



/***/ }),

/***/ 9930:
/*!************************************************!*\
  !*** ./src/app/teamdemo/teamdemo.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamdemoComponent": () => (/* binding */ TeamdemoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _teamdemo_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./teamdemo.component.html?ngResource */ 7833);
/* harmony import */ var _teamdemo_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./teamdemo.component.scss?ngResource */ 8698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/data.service */ 2468);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/common.service */ 5620);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/components/toast.service */ 8923);
/* harmony import */ var _services_components_loder_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/components/loder.service */ 6552);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/auth/authentication.service */ 6406);










let TeamdemoComponent = class TeamdemoComponent {
    constructor(dataService, commonService, toastService, loderService, router, route, authanticationSer) {
        this.dataService = dataService;
        this.commonService = commonService;
        this.toastService = toastService;
        this.loderService = loderService;
        this.router = router;
        this.route = route;
        this.authanticationSer = authanticationSer;
        this.titleMsg = 'Teams Activity';
        this.teamsData = [];
        this.emptyRecord = true;
        this.openFilter = false;
        this.pageArray = [];
    }
    ngOnInit() {
        this.geAurhtData();
        this.getTeamsLeaders();
    }
    getTeamsLeaders() {
        if (this.authData) {
            let data = { id: this.authData.EmpCode, flag: this.authData.flag, page: false };
            this.getTeamsLeadersApi(data);
        }
        else {
            this.geAurhtData();
            let data = { id: this.userEmpCode, flag: this.userFlag, page: false };
            this.getTeamsLeadersApi(data);
        }
    }
    getTeamsLeadersApi(item) {
        if (item.page != true) {
            if (item.flag != 1) {
                this.pageArray.push(item);
            }
            if (item.flag > 1) {
                // console.log("leaders id", item.id);
                let loadingParams = { spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
                this.loderService.showLoading(loadingParams);
                this.commonService.post('getDSRleaders', { userName: item.id }).subscribe((res) => {
                    this.loderService.dismiss();
                    if (res.ResponseFlag == 1) {
                        // console.log("leaders data", JSON.parse(res.ResponseMessage));
                        this.teamsData = JSON.parse(res.ResponseMessage).Table;
                        // console.log("teams data",this.teamsData);
                    }
                    else {
                        this.toastService.toast("No record Found");
                    }
                });
            }
            else {
                const stringifyObj = JSON.stringify(item);
                const b64Str = btoa(stringifyObj);
                // console.log(b64Str);
                this.router.navigate(['/teamDashboard:id?'], { queryParams: { item: b64Str } });
            }
        }
        else {
            if (item.flag > 1) {
                let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
                this.loderService.showLoading(loadingParams);
                this.commonService.post('getDSRleaders', { userName: item.id }).subscribe((res) => {
                    this.loderService.dismiss();
                    if (res.ResponseFlag == 1) {
                        // console.log("leaders data", JSON.parse(res.ResponseMessage));
                        this.teamsData = JSON.parse(res.ResponseMessage).Table;
                    }
                    else {
                        this.toastService.toast("No record Found");
                    }
                });
            }
            else {
                this.router.navigate(['/teamDashboard:id?'], { queryParams: { item: JSON.stringify(item) } });
            }
        }
    }
    geAurhtData() {
        // this.authData = this.authanticationSer.getSession('authData');
        const get = this.authanticationSer.getSession('authData');
        this.authData = JSON.parse(atob(get));
        this.userEmpCode = this.authData.EmpCode;
        this.userFlag = this.authData.flag;
        // }
    }
    filterOpen() {
        this.openFilter = !this.openFilter;
    }
    backButton() {
        if (this.pageArray.length == 1) {
            this.router.navigateByUrl("/home");
        }
        else {
            let backData = this.pageArray.splice(-1);
            if (!backData.id) {
                backData = this.pageArray[this.pageArray.length - 1];
            }
            let data = { id: backData.id, flag: backData.flag, page: true };
            this.getTeamsLeadersApi(data);
        }
    }
};
TeamdemoComponent.ctorParameters = () => [
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_4__.ToastService },
    { type: _services_components_loder_service__WEBPACK_IMPORTED_MODULE_5__.LoderService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_6__.AuthenticationService }
];
TeamdemoComponent.propDecorators = {
    popover: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['popover',] }]
};
TeamdemoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-teamdemo',
        template: _teamdemo_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_teamdemo_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TeamdemoComponent);



/***/ }),

/***/ 2359:
/*!************************************************************!*\
  !*** ./src/app/teams-activity/teams-activity.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamsActivityComponent": () => (/* binding */ TeamsActivityComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _teams_activity_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./teams-activity.component.html?ngResource */ 8083);
/* harmony import */ var _teams_activity_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./teams-activity.component.scss?ngResource */ 818);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/data.service */ 2468);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/common.service */ 5620);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/components/toast.service */ 8923);
/* harmony import */ var _services_components_loder_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/components/loder.service */ 6552);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);









let TeamsActivityComponent = class TeamsActivityComponent {
    constructor(dataService, commonService, toastService, loderService, router) {
        this.dataService = dataService;
        this.commonService = commonService;
        this.toastService = toastService;
        this.loderService = loderService;
        this.router = router;
        this.titleMsg = 'Teams Activity';
        this.teamsData = [];
        this.teamsData2 = [];
        this.emptyRecord = true;
        this.openFilter = false;
        this.isOpen = false;
        this.collapsedBreadcrumbs = [];
    }
    ngOnInit() {
        // this.getData();
        // this.getRecordByUser();
        this.geAurhtData();
        this.getTeamsLeaders();
    }
    getTeamsActivity() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRIndivisualCounts', { userName: this.userName }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                console.log("teams data", JSON.parse(res.ResponseMessage));
                this.loderService.dismiss();
                this.teamsData = JSON.parse(res.ResponseMessage).Table;
            }
            else {
                this.toastService.toast("No record Found");
                this.loderService.dismiss();
            }
        });
    }
    getTeamsLeaders() {
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRleaders', { userName: this.userName }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                // console.log("leaders data", JSON.parse(res.ResponseMessage));
                this.loderService.dismiss();
                this.teamsData = JSON.parse(res.ResponseMessage).Table;
            }
            else {
                this.toastService.toast("No record Found");
                this.loderService.dismiss();
            }
        });
    }
    goToTeamActivityDetail(item) {
        if (item.flag == 2) {
            // console.log("if item", item);
            this.router.navigate(['/dsrActivity:id?'], { queryParams: { item: JSON.stringify(item) } });
        }
        else {
            // console.log("else item", item);
            this.router.navigate(['/role/role1:id'], { queryParams: { item: JSON.stringify(item) } });
        }
    }
    filterOpen() {
        this.openFilter = !this.openFilter;
    }
    geAurhtData() {
        if (localStorage.authData) {
            this.authData = JSON.parse(localStorage.getItem("authData"));
            this.userName = this.authData.EmpCode;
            this.userFlag = this.authData.flag;
        }
    }
    presentPopover(e) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            this.collapsedBreadcrumbs = e.detail.collapsedBreadcrumbs;
            this.popover.event = e;
            this.isOpen = true;
        });
    }
};
TeamsActivityComponent.ctorParameters = () => [
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_4__.ToastService },
    { type: _services_components_loder_service__WEBPACK_IMPORTED_MODULE_5__.LoderService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router }
];
TeamsActivityComponent.propDecorators = {
    popover: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['popover',] }]
};
TeamsActivityComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-teams-activity',
        template: _teams_activity_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_teams_activity_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TeamsActivityComponent);



/***/ }),

/***/ 5857:
/*!**************************************************************!*\
  !*** ./src/app/teams-dashboard/teams-dashboard.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamsDashboardComponent": () => (/* binding */ TeamsDashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _teams_dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./teams-dashboard.component.html?ngResource */ 9016);
/* harmony import */ var _teams_dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./teams-dashboard.component.scss?ngResource */ 3111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth/authentication.service */ 6406);
/* harmony import */ var _services_common_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/common.service */ 5620);
/* harmony import */ var _services_components_loder_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/components/loder.service */ 6552);
/* harmony import */ var _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/components/toast.service */ 8923);
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/data.service */ 2468);













let TeamsDashboardComponent = class TeamsDashboardComponent {
    constructor(dataService, loderService, toastService, commonService, fb, toastController, authanticationSer, route, router) {
        this.dataService = dataService;
        this.loderService = loderService;
        this.toastService = toastService;
        this.commonService = commonService;
        this.fb = fb;
        this.toastController = toastController;
        this.authanticationSer = authanticationSer;
        this.route = route;
        this.router = router;
        this.titleMsg = 'Team Activity Dashboard';
        this.teamsData = [];
        this.filterData = [];
        this.submitted = false;
        this.openFilter = false;
        this.sum = 0;
        this.typeOfActivityData = [];
    }
    ngOnInit() {
        this.geAurhtData();
        this.getTeamsLeaders();
        this.getCounts();
        // this.getMonthData();
        // this.getYesturadyData();
        this.managerForm = this.fb.group({
            zone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
            manager: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
        });
    }
    geAurhtData() {
        this.route.queryParamMap.subscribe((params) => {
            if (params.params.item) {
                let item = params.params.item;
                let decodeItem = JSON.parse(atob(item));
                this.userEmpCode = decodeItem.id;
                this.totalPremium = decodeItem.sum;
                this.dsrCount = decodeItem.Count;
            }
            else {
                if (sessionStorage.authData) {
                    const get = this.authanticationSer.getSession('authData');
                    this.userData = JSON.parse(atob(get));
                    this.userEmpCode = this.userData.EmpCode;
                    this.userFlag = this.userData.flag;
                    this.userZone = this.userData.zone;
                }
                else {
                    this.router.navigateByUrl("/login");
                }
            }
        });
    }
    getData() {
        this.teamsData = this.dataService.LeaderData;
    }
    getTeamsLeaders() {
        this.yesturdayDate = new Date();
        this.month = new Date();
        this.yesturdayDate.setDate(this.yesturdayDate.getDate() - 1);
        this.month.setMonth(this.month.getMonth());
        let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true };
        this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRleaders', { userName: this.userEmpCode }).subscribe((res) => {
            this.loderService.dismiss();
            if (res.ResponseFlag == 1) {
                this.teamsData = JSON.parse(res.ResponseMessage).Table;
                // console.log("ddddd", this.teamsData);
            }
            else {
                // this.toastService.toast("No record Found");
            }
        });
    }
    getCounts() {
        this.getYesturadyData();
        this.getMonthData();
    }
    filterOpen() {
        this.openFilter = !this.openFilter;
        this.getZones();
    }
    getYesturadyData() {
        this.sum = 0;
        this.typeOfActivityData = [
            { type: "Bank Branch visit", count: 0, mnthCount: 0 },
            { type: "Bank Zonal office", count: 0, mnthCount: 0 },
            { type: "Bank Regional office", count: 0, mnthCount: 0 },
            { type: "Customer service", count: 0, mnthCount: 0 },
            { type: "Promotional activity", count: 0, mnthCount: 0 },
            { type: "Joint call with supevisor", count: 0, mnthCount: 0 },
            { type: "Review/Office Meeting", count: 0, mnthCount: 0 },
            { type: "Corporate salary", count: 0, mnthCount: 0 },
            { type: "Policy Issuance/Other Back office work", count: 0, mnthCount: 0 },
        ];
        // let loadingParams = { msg: 'Loading Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true }
        // this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRlastday', { userName: this.userEmpCode }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                // this.loderService.dismiss();
                let data = JSON.parse(res.ResponseMessage).Table;
                // console.log("yesturady data", data);
                for (var i = 0; i < data.length; i++) {
                    this.typeOfActivityData.forEach(element => {
                        if (element.type == data[i].type_Of_Activity) {
                            element.count = data[i].count;
                            // sum+=data[i].count;
                            this.sum += data[i].count;
                            // console.log(element);
                        }
                        else {
                            console.log("Data Not Found");
                        }
                    });
                }
                this.yesturdayCount = this.sum;
                // console.log(this.typeOfActivityData, "sum", this.yesturdayCount);
                // console.log("sum", this.yesturdayCount);
            }
            else {
                // this.loderService.dismiss();
            }
        });
    }
    getMonthData() {
        this.monthCount = 0;
        this.typeOfActivityData = [
            { type: "Bank Branch visit", count: 0, mnthCount: 0 },
            { type: "Bank Zonal office", count: 0, mnthCount: 0 },
            { type: "Bank Regional office", count: 0, mnthCount: 0 },
            { type: "Customer service", count: 0, mnthCount: 0 },
            { type: "Promotional activity", count: 0, mnthCount: 0 },
            { type: "Joint call with supevisor", count: 0, mnthCount: 0 },
            { type: "Review/Office Meeting", count: 0, mnthCount: 0 },
            { type: "Corporate salary", count: 0, mnthCount: 0 },
            { type: "Policy Issuance/Other Back office work", count: 0, mnthCount: 0 },
        ];
        // let loadingParams = { msg: 'Loading Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true }
        // this.loderService.showLoading(loadingParams);
        this.commonService.post('getDSRlastMonth', { userName: this.userEmpCode }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                // this.loderService.dismiss();
                let data = JSON.parse(res.ResponseMessage).Table;
                // console.log("month data", data);
                let sum = 0;
                for (var i = 0; i < data.length; i++) {
                    this.typeOfActivityData.forEach(element => {
                        if (element.type == data[i].type_Of_Activity) {
                            element.mnthCount = data[i].count;
                            this.monthCount += data[i].count;
                            // console.log(element);
                        }
                        else {
                            // console.log("Data Not Found");
                        }
                    });
                }
                // this.monthCount=sum;
                // console.log(this.typeOfActivityData);
            }
            else {
                // this.loderService.dismiss();
            }
        });
    }
    getZones() {
        this.commonService.post('getDSRZone', { userName: this.userEmpCode }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                this.zoneData = JSON.parse(res.ResponseMessage).Table;
                // console.log("Zone data ", this.zoneData);
            }
            else {
                this.toastService.toast("Zone Not Found");
            }
        });
    }
    chngeZone(e) {
        this.submitted = true;
        let zone = e.target.value;
        if (zone.length != 0) {
            this.commonService.post('getLeaderDtlsWithZone', { userName: this.userEmpCode, zones: zone }).subscribe((res) => {
                if (res.ResponseFlag == 1) {
                    this.teamsData = JSON.parse(res.ResponseMessage).Table;
                    if (this.teamsData.length == 0) {
                        this.toastService.toast("No Records Found.!");
                    }
                    // console.log("Managers ", this.teamsData);
                }
                else {
                    this.toastService.toast("No Records Found.!");
                }
            });
        }
        else {
            this.geAurhtData();
            this.getTeamsLeaders();
        }
    }
    chngeManagers(e) {
        this.submitted = true;
        let manager = e.target.value;
        // let loadingParams = { msg: 'Please Wait...', spinner: 'lines-sharp-small', mode: 'ios', class: 'custom-loading', backdropDismiss: true }
        // this.loderService.showLoading(loadingParams);
        this.commonService.post('getLeaderDtlsWithZone', { zone: [], manager: manager }).subscribe((res) => {
            if (res.ResponseFlag == 1) {
                let data = JSON.parse(res.ResponseMessage).Table;
                for (let i = 0; i < data.length; i++) {
                    if (data[i].subTypeOfActivity.length > 10) {
                        data[i].subTypeOfActivity = JSON.parse(data[i].subTypeOfActivity);
                        // console.log("sub data", data[i].subTypeOfActivity);
                    }
                    else {
                        data[i].subTypeOfActivity = [];
                    }
                }
                if (data.length != 0) {
                    this.filterData = data;
                    // console.log("dsr data", data);
                }
                else {
                    this.filterData = [];
                }
            }
            else {
                this.toastService.toast("Data Not Found");
            }
        }, (err) => {
            console.log(err, "error");
        });
    }
    clearManagerFilter() {
        this.managerForm.reset();
        this.geAurhtData();
        this.getTeamsLeaders();
    }
};
TeamsDashboardComponent.ctorParameters = () => [
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_6__.DataService },
    { type: _services_components_loder_service__WEBPACK_IMPORTED_MODULE_4__.LoderService },
    { type: _services_components_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _services_common_service__WEBPACK_IMPORTED_MODULE_3__.CommonService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController },
    { type: _services_auth_authentication_service__WEBPACK_IMPORTED_MODULE_2__.AuthenticationService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router }
];
TeamsDashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-teams-dashboard',
        template: _teams_dashboard_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_teams_dashboard_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TeamsDashboardComponent);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    // baseUrl: 'https://online.futuregenerali.in/DSR/api'  // Live Url
    baseUrl: 'https://online.futuregenerali.in/TeamTrack/api' // Local url
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 8150);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		79,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		5593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		3225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		6655,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		4856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		8308,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		4690,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4090,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6214,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		9447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		7950,
		"default-node_modules_ionic_core_dist_esm_data-caf38df0_js-node_modules_ionic_core_dist_esm_th-d3ab8e",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		9689,
		"default-node_modules_ionic_core_dist_esm_data-caf38df0_js-node_modules_ionic_core_dist_esm_th-d3ab8e",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		8840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		9667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		3288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		5473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		3634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		2855,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		8737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		9632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		4446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		2275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		8050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		8994,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3592,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		2666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5534,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		4902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		1938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		8179,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		9989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		8902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		8395,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		6357,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		8268,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		2875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 6700:
/*!***************************************************!*\
  !*** ./node_modules/moment/locale/ sync ^\.\/.*$ ***!
  \***************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./af": 8685,
	"./af.js": 8685,
	"./ar": 254,
	"./ar-dz": 4312,
	"./ar-dz.js": 4312,
	"./ar-kw": 2614,
	"./ar-kw.js": 2614,
	"./ar-ly": 8630,
	"./ar-ly.js": 8630,
	"./ar-ma": 8674,
	"./ar-ma.js": 8674,
	"./ar-sa": 9032,
	"./ar-sa.js": 9032,
	"./ar-tn": 4730,
	"./ar-tn.js": 4730,
	"./ar.js": 254,
	"./az": 3052,
	"./az.js": 3052,
	"./be": 150,
	"./be.js": 150,
	"./bg": 3069,
	"./bg.js": 3069,
	"./bm": 3466,
	"./bm.js": 3466,
	"./bn": 8516,
	"./bn-bd": 557,
	"./bn-bd.js": 557,
	"./bn.js": 8516,
	"./bo": 6273,
	"./bo.js": 6273,
	"./br": 9588,
	"./br.js": 9588,
	"./bs": 9815,
	"./bs.js": 9815,
	"./ca": 3331,
	"./ca.js": 3331,
	"./cs": 1320,
	"./cs.js": 1320,
	"./cv": 2219,
	"./cv.js": 2219,
	"./cy": 8266,
	"./cy.js": 8266,
	"./da": 6427,
	"./da.js": 6427,
	"./de": 7435,
	"./de-at": 2871,
	"./de-at.js": 2871,
	"./de-ch": 2994,
	"./de-ch.js": 2994,
	"./de.js": 7435,
	"./dv": 2357,
	"./dv.js": 2357,
	"./el": 5649,
	"./el.js": 5649,
	"./en-au": 9961,
	"./en-au.js": 9961,
	"./en-ca": 9878,
	"./en-ca.js": 9878,
	"./en-gb": 3924,
	"./en-gb.js": 3924,
	"./en-ie": 864,
	"./en-ie.js": 864,
	"./en-il": 1579,
	"./en-il.js": 1579,
	"./en-in": 940,
	"./en-in.js": 940,
	"./en-nz": 6181,
	"./en-nz.js": 6181,
	"./en-sg": 4301,
	"./en-sg.js": 4301,
	"./eo": 5291,
	"./eo.js": 5291,
	"./es": 4529,
	"./es-do": 3764,
	"./es-do.js": 3764,
	"./es-mx": 2584,
	"./es-mx.js": 2584,
	"./es-us": 3425,
	"./es-us.js": 3425,
	"./es.js": 4529,
	"./et": 5203,
	"./et.js": 5203,
	"./eu": 678,
	"./eu.js": 678,
	"./fa": 3483,
	"./fa.js": 3483,
	"./fi": 6262,
	"./fi.js": 6262,
	"./fil": 2521,
	"./fil.js": 2521,
	"./fo": 4555,
	"./fo.js": 4555,
	"./fr": 3131,
	"./fr-ca": 8239,
	"./fr-ca.js": 8239,
	"./fr-ch": 1702,
	"./fr-ch.js": 1702,
	"./fr.js": 3131,
	"./fy": 267,
	"./fy.js": 267,
	"./ga": 3821,
	"./ga.js": 3821,
	"./gd": 1753,
	"./gd.js": 1753,
	"./gl": 4074,
	"./gl.js": 4074,
	"./gom-deva": 2762,
	"./gom-deva.js": 2762,
	"./gom-latn": 5969,
	"./gom-latn.js": 5969,
	"./gu": 2809,
	"./gu.js": 2809,
	"./he": 5402,
	"./he.js": 5402,
	"./hi": 315,
	"./hi.js": 315,
	"./hr": 410,
	"./hr.js": 410,
	"./hu": 8288,
	"./hu.js": 8288,
	"./hy-am": 8999,
	"./hy-am.js": 8999,
	"./id": 1334,
	"./id.js": 1334,
	"./is": 6959,
	"./is.js": 6959,
	"./it": 4864,
	"./it-ch": 1124,
	"./it-ch.js": 1124,
	"./it.js": 4864,
	"./ja": 6141,
	"./ja.js": 6141,
	"./jv": 9187,
	"./jv.js": 9187,
	"./ka": 2136,
	"./ka.js": 2136,
	"./kk": 4332,
	"./kk.js": 4332,
	"./km": 8607,
	"./km.js": 8607,
	"./kn": 4305,
	"./kn.js": 4305,
	"./ko": 234,
	"./ko.js": 234,
	"./ku": 6003,
	"./ku.js": 6003,
	"./ky": 5061,
	"./ky.js": 5061,
	"./lb": 2786,
	"./lb.js": 2786,
	"./lo": 6183,
	"./lo.js": 6183,
	"./lt": 29,
	"./lt.js": 29,
	"./lv": 4169,
	"./lv.js": 4169,
	"./me": 8577,
	"./me.js": 8577,
	"./mi": 8177,
	"./mi.js": 8177,
	"./mk": 337,
	"./mk.js": 337,
	"./ml": 5260,
	"./ml.js": 5260,
	"./mn": 2325,
	"./mn.js": 2325,
	"./mr": 4695,
	"./mr.js": 4695,
	"./ms": 5334,
	"./ms-my": 7151,
	"./ms-my.js": 7151,
	"./ms.js": 5334,
	"./mt": 3570,
	"./mt.js": 3570,
	"./my": 7963,
	"./my.js": 7963,
	"./nb": 8028,
	"./nb.js": 8028,
	"./ne": 6638,
	"./ne.js": 6638,
	"./nl": 302,
	"./nl-be": 6782,
	"./nl-be.js": 6782,
	"./nl.js": 302,
	"./nn": 3501,
	"./nn.js": 3501,
	"./oc-lnc": 563,
	"./oc-lnc.js": 563,
	"./pa-in": 869,
	"./pa-in.js": 869,
	"./pl": 5302,
	"./pl.js": 5302,
	"./pt": 9687,
	"./pt-br": 4884,
	"./pt-br.js": 4884,
	"./pt.js": 9687,
	"./ro": 9107,
	"./ro.js": 9107,
	"./ru": 7008,
	"./ru.js": 7008,
	"./sd": 355,
	"./sd.js": 355,
	"./se": 3427,
	"./se.js": 3427,
	"./si": 1848,
	"./si.js": 1848,
	"./sk": 4590,
	"./sk.js": 4590,
	"./sl": 184,
	"./sl.js": 184,
	"./sq": 6361,
	"./sq.js": 6361,
	"./sr": 8965,
	"./sr-cyrl": 1287,
	"./sr-cyrl.js": 1287,
	"./sr.js": 8965,
	"./ss": 5456,
	"./ss.js": 5456,
	"./sv": 451,
	"./sv.js": 451,
	"./sw": 7558,
	"./sw.js": 7558,
	"./ta": 2702,
	"./ta.js": 2702,
	"./te": 3693,
	"./te.js": 3693,
	"./tet": 1243,
	"./tet.js": 1243,
	"./tg": 2500,
	"./tg.js": 2500,
	"./th": 5768,
	"./th.js": 5768,
	"./tk": 7761,
	"./tk.js": 7761,
	"./tl-ph": 5780,
	"./tl-ph.js": 5780,
	"./tlh": 9590,
	"./tlh.js": 9590,
	"./tr": 3807,
	"./tr.js": 3807,
	"./tzl": 3857,
	"./tzl.js": 3857,
	"./tzm": 654,
	"./tzm-latn": 8806,
	"./tzm-latn.js": 8806,
	"./tzm.js": 654,
	"./ug-cn": 845,
	"./ug-cn.js": 845,
	"./uk": 9232,
	"./uk.js": 9232,
	"./ur": 7052,
	"./ur.js": 7052,
	"./uz": 7967,
	"./uz-latn": 2233,
	"./uz-latn.js": 2233,
	"./uz.js": 7967,
	"./vi": 8615,
	"./vi.js": 8615,
	"./x-pseudo": 2320,
	"./x-pseudo.js": 2320,
	"./yo": 1313,
	"./yo.js": 1313,
	"./zh-cn": 4490,
	"./zh-cn.js": 4490,
	"./zh-hk": 5910,
	"./zh-hk.js": 5910,
	"./zh-mo": 8262,
	"./zh-mo.js": 8262,
	"./zh-tw": 4223,
	"./zh-tw.js": 4223
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 6700;

/***/ }),

/***/ 9259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 18px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 12px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\n.username {\n  font-size: 1.2rem;\n  color: var(--white-clr);\n  margin-left: 8%;\n}\n\n.icon-style {\n  color: white;\n  font-size: 1rem;\n}\n\n.menu-close-icon {\n  margin: -1rem 0px -1rem -30px;\n  background: transparent;\n}\n\n.menu-list {\n  height: 100%;\n}\n\n.menu-list .label {\n  color: white;\n  padding: 2px 10px 2px 13px;\n}\n\n.menu-list .menuWrapper .label {\n  border-bottom: 1px solid #f32712;\n}\n\n.menu-list .menuWrapper:last-child .label {\n  border-bottom: 1px solid #ff6758;\n}\n\n.menu-list .menuWrapper .active {\n  background-color: #f31f1f;\n}\n\n.menu-title {\n  color: white;\n  padding: 0px 110px 1px 0;\n}\n\n.age-is-ten {\n  background: #2b9348;\n}\n\n.my-custom-class {\n  --background: var(--main-bg-color) !important;\n}\n\nbutton {\n  outline: none;\n  box-shadow: none;\n}\n\n.header-md::after {\n  background: none;\n}\n\nion-item {\n  --border-color: transparent;\n}\n\nion-menu ion-content {\n  --background: var(--main-bg-color) !important;\n}\n\nion-menu ion-list {\n  background: var(--main-bg-color) !important;\n}\n\nion-menu ion-list ion-item {\n  --background: var(--main-bg-color) !important;\n}\n\n.footer {\n  --background: var(--main-bg-color) !important;\n}\n\n.progress-outer {\n  width: 96%;\n  margin: 10px 2%;\n  padding: 3px;\n  text-align: center;\n  background-color: #f4f4f4;\n  border: 1px solid #dcdcdc;\n  color: #fff;\n  border-radius: 20px;\n}\n\n.progress-inner {\n  min-width: 15%;\n  white-space: nowrap;\n  overflow: hidden;\n  padding: 5px;\n  border-radius: 20px;\n  background-color: #16A1A4;\n}\n\n.loader {\n  display: flex;\n  align-items: center;\n  height: 100%;\n  width: 100%;\n  background: rgba(0, 0, 0, 0.29);\n  display: inline-block;\n  z-index: 99;\n  text-align: center;\n  position: absolute;\n}\n\n.loader-element {\n  margin: 0;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.loader p {\n  padding: 0;\n  margin: 0;\n  color: white;\n  font-weight: bold;\n  letter-spacing: 1px;\n}\n\n.spinner {\n  color: white;\n  padding: 12px;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFxpb25pYyUyMFByb1xcZmclMjBiYW5jYSUyMGNvbm5lY3RcXHNyY1xcYXBwXFxhcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwyRUFBQTtBQ0NGOztBREVBO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7QUNDRjs7QURHQTtFQUNFLG1CQUFBO0FDQUY7O0FER0E7O0VBRUUsa0JBQUE7QUNBRjs7QURPQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDSkY7O0FET0E7RUFDRSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNKRjs7QURPQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0pGOztBRE9BO0VBQ0Usc0RBQUE7QUNKRjs7QURPQTtFQUNFLCtCQUFBO0FDSkY7O0FET0E7RUFDRSxjQUFBO0FDSkY7O0FET0E7RUFDRSxnQkFBQTtBQ0pGOztBRE9BO0VBQ0Usc0JBQUE7QUNKRjs7QURPQTtFQUNFLG1CQUFBO0FDSkY7O0FET0E7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FDSkY7O0FET0E7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNKRjs7QURPQTtFQUNFLCtCQUFBO0FDSkY7O0FET0E7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQ0pGOztBRE9BO0VBQ0Usa0JBQUE7QUNKRjs7QURPQTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FDSkY7O0FET0E7RUFDRSxrQkFBQTtBQ0pGOztBRE9BO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsb0NBQUE7QUNMRjs7QURRQTtFQUNFLGlDQUFBO0FDTEY7O0FEUUE7RUFDRSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtBQ0xGOztBRGlCQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDZEY7O0FEaUJBO0VBQ0UsNkJBQUE7RUFDQSx1QkFBQTtBQ2RGOztBRGtCQTtFQUNFLFlBQUE7QUNmRjs7QURpQkU7RUFDRSxZQUFBO0VBQ0EsMEJBQUE7QUNmSjs7QURtQkk7RUFDRSxnQ0FBQTtBQ2pCTjs7QURxQk07RUFDRSxnQ0FBQTtBQ25CUjs7QUR1Qkk7RUFDRSx5QkFBQTtBQ3JCTjs7QUQwQkE7RUFDRSxZQUFBO0VBQ0Esd0JBQUE7QUN2QkY7O0FEMEJBO0VBQ0UsbUJBQUE7QUN2QkY7O0FEMEJBO0VBQ0UsNkNBQUE7QUN2QkY7O0FEMEJBO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0FDdkJGOztBRDBCQTtFQUNFLGdCQUFBO0FDdkJGOztBRDBCQTtFQUNFLDJCQUFBO0FDdkJGOztBRDBCQTtFQUNFLDZDQUFBO0FDdkJGOztBRDBCQTtFQUNFLDJDQUFBO0FDdkJGOztBRDBCQTtFQUNFLDZDQUFBO0FDdkJGOztBRDBCQTtFQUNFLDZDQUFBO0FDdkJGOztBRDJCQTtFQUNFLFVBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQ3hCRjs7QUQyQkE7RUFDRSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FDeEJGOztBRDZCQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsK0JBQUE7RUFDQSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDMUJGOztBRDZCQTtFQUNFLFNBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUMxQkY7O0FENkJBO0VBQ0UsVUFBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQzFCRjs7QUQ2QkE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUMxQkYiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pdGVtLWJhY2tncm91bmQsIHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yLCAjZmZmKSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1jb250ZW50IHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDhweDtcbiAgLS1wYWRkaW5nLXRvcDogMjBweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxuXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuXG4vLyBpb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcbi8vICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG4vLyB9XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBtaW4taGVpZ2h0OiAyMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDE4cHg7XG4gIGNvbG9yOiAjNzU3NTc1O1xuICBtaW4taGVpZ2h0OiAyNnB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IpLCAwLjE0KTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XG4gIGNvbG9yOiAjNjE2ZTdlO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24tbGFiZWwge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWNvbnRlbnQge1xuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3Qge1xuICBwYWRkaW5nOiAyMHB4IDAgMCAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAtLXBhZGRpbmctZW5kOiAxNnB4O1xuICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6ICM3Mzg0OWE7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW5vdGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTJweDtcblxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbmlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4udXNlcm5hbWUge1xuICBmb250LXNpemU6IDEuMnJlbTtcbiAgY29sb3I6IHZhcigtLXdoaXRlLWNscik7XG4gIG1hcmdpbi1sZWZ0OiA4JTtcbn1cblxuXG5cblxuXG5cblxuXG5cblxuLmljb24tc3R5bGUge1xuICBjb2xvcjogI2ZmZmY7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbn1cblxuLm1lbnUtY2xvc2UtaWNvbiB7XG4gIG1hcmdpbjogLTFyZW0gMHB4IC0xcmVtIC0zMHB4O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuXG4ubWVudS1saXN0IHtcbiAgaGVpZ2h0OiAxMDAlO1xuXG4gIC5sYWJlbCB7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHBhZGRpbmc6IDJweCAxMHB4IDJweCAxM3B4O1xuICB9XG5cbiAgLm1lbnVXcmFwcGVyIHtcbiAgICAubGFiZWwge1xuICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmMzI3MTI7XG4gICAgfVxuXG4gICAgJjpsYXN0LWNoaWxkIHtcbiAgICAgIC5sYWJlbCB7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZmY2NzU4O1xuICAgICAgfVxuICAgIH1cblxuICAgIC5hY3RpdmUge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2YzMWYxZjtcbiAgICB9XG4gIH1cbn1cblxuLm1lbnUtdGl0bGUge1xuICBjb2xvcjogI2ZmZmY7XG4gIHBhZGRpbmc6IDBweCAxMTBweCAxcHggMDtcbn1cblxuLmFnZS1pcy10ZW4ge1xuICBiYWNrZ3JvdW5kOiAjMmI5MzQ4O1xufVxuXG4ubXktY3VzdG9tLWNsYXNzIHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1tYWluLWJnLWNvbG9yKSAhaW1wb3J0YW50O1xufVxuXG5idXR0b24ge1xuICBvdXRsaW5lOiBub25lO1xuICBib3gtc2hhZG93OiBub25lO1xufVxuXG4uaGVhZGVyLW1kOjphZnRlciB7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG5pb24tbWVudSBpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0tbWFpbi1iZy1jb2xvcikgIWltcG9ydGFudDtcbn1cblxuaW9uLW1lbnUgaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1tYWluLWJnLWNvbG9yKSAhaW1wb3J0YW50O1xufVxuXG5pb24tbWVudSBpb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0tbWFpbi1iZy1jb2xvcikgIWltcG9ydGFudDtcbn1cblxuLmZvb3RlciB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0tbWFpbi1iZy1jb2xvcikgIWltcG9ydGFudDtcbn1cblxuXG4ucHJvZ3Jlc3Mtb3V0ZXIge1xuICB3aWR0aDogOTYlO1xuICBtYXJnaW46IDEwcHggMiU7XG4gIHBhZGRpbmc6IDNweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjRmNGY0O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZGNkY2RjO1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbn1cblxuLnByb2dyZXNzLWlubmVyIHtcbiAgbWluLXdpZHRoOiAxNSU7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHBhZGRpbmc6IDVweDtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE2QTFBNDtcbn1cblxuXG5cbi5sb2FkZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiByZ2IoMCAwIDAgLyAyOSUpO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHotaW5kZXg6IDk5O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cblxuLmxvYWRlci1lbGVtZW50IHtcbiAgbWFyZ2luOiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xufVxuXG4ubG9hZGVyIHAge1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDA7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG59XG5cbi5zcGlubmVyIHtcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAxMnB4O1xuICBmb250LXNpemU6IDE0cHg7XG59IiwiaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pdGVtLWJhY2tncm91bmQsIHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yLCAjZmZmKSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1jb250ZW50IHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDhweDtcbiAgLS1wYWRkaW5nLXRvcDogMjBweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMThweDtcbiAgY29sb3I6ICM3NTc1NzU7XG4gIG1pbi1oZWlnaHQ6IDI2cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAtLXBhZGRpbmctZW5kOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgY29sb3I6ICM2MTZlN2U7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tbWluLWhlaWdodDogNTBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBjb2xvcjogIzczODQ5YTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbm90ZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbmlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4udXNlcm5hbWUge1xuICBmb250LXNpemU6IDEuMnJlbTtcbiAgY29sb3I6IHZhcigtLXdoaXRlLWNscik7XG4gIG1hcmdpbi1sZWZ0OiA4JTtcbn1cblxuLmljb24tc3R5bGUge1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbn1cblxuLm1lbnUtY2xvc2UtaWNvbiB7XG4gIG1hcmdpbjogLTFyZW0gMHB4IC0xcmVtIC0zMHB4O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuLm1lbnUtbGlzdCB7XG4gIGhlaWdodDogMTAwJTtcbn1cbi5tZW51LWxpc3QgLmxhYmVsIHtcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAycHggMTBweCAycHggMTNweDtcbn1cbi5tZW51LWxpc3QgLm1lbnVXcmFwcGVyIC5sYWJlbCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZjMyNzEyO1xufVxuLm1lbnUtbGlzdCAubWVudVdyYXBwZXI6bGFzdC1jaGlsZCAubGFiZWwge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2ZmNjc1ODtcbn1cbi5tZW51LWxpc3QgLm1lbnVXcmFwcGVyIC5hY3RpdmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjMxZjFmO1xufVxuXG4ubWVudS10aXRsZSB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMHB4IDExMHB4IDFweCAwO1xufVxuXG4uYWdlLWlzLXRlbiB7XG4gIGJhY2tncm91bmQ6ICMyYjkzNDg7XG59XG5cbi5teS1jdXN0b20tY2xhc3Mge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLW1haW4tYmctY29sb3IpICFpbXBvcnRhbnQ7XG59XG5cbmJ1dHRvbiB7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG5cbi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbmlvbi1tZW51IGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1tYWluLWJnLWNvbG9yKSAhaW1wb3J0YW50O1xufVxuXG5pb24tbWVudSBpb24tbGlzdCB7XG4gIGJhY2tncm91bmQ6IHZhcigtLW1haW4tYmctY29sb3IpICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1tZW51IGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1tYWluLWJnLWNvbG9yKSAhaW1wb3J0YW50O1xufVxuXG4uZm9vdGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1tYWluLWJnLWNvbG9yKSAhaW1wb3J0YW50O1xufVxuXG4ucHJvZ3Jlc3Mtb3V0ZXIge1xuICB3aWR0aDogOTYlO1xuICBtYXJnaW46IDEwcHggMiU7XG4gIHBhZGRpbmc6IDNweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjRmNGY0O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZGNkY2RjO1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbn1cblxuLnByb2dyZXNzLWlubmVyIHtcbiAgbWluLXdpZHRoOiAxNSU7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHBhZGRpbmc6IDVweDtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE2QTFBNDtcbn1cblxuLmxvYWRlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4yOSk7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgei1pbmRleDogOTk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xufVxuXG4ubG9hZGVyLWVsZW1lbnQge1xuICBtYXJnaW46IDA7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG5cbi5sb2FkZXIgcCB7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbjogMDtcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbGV0dGVyLXNwYWNpbmc6IDFweDtcbn1cblxuLnNwaW5uZXIge1xuICBjb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDEycHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn0iXX0= */";

/***/ }),

/***/ 3488:
/*!************************************************************!*\
  !*** ./src/app/auth/login/login.component.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".mar-0 {\n  margin: 0;\n}\n\n.pad-0 {\n  padding: 0;\n}\n\n.logo-block {\n  background-color: var(--main-bg-color);\n  border-bottom-left-radius: 30%;\n  border-bottom-right-radius: 30%;\n  height: 170px;\n  position: relative;\n  box-shadow: 0px 10px #ff4658, 0px 20px #ff7c89;\n}\n\n.logo {\n  height: 30%;\n  margin-top: 5%;\n}\n\n.logo-img {\n  width: 85%;\n  margin-top: -5%;\n}\n\n.center {\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\n.form-card {\n  border-radius: 5%;\n  border-top: 5px solid var(--main-bg-color);\n}\n\n.pointer {\n  cursor: pointer;\n}\n\n.form-card {\n  background-color: rgb(255, 255, 255);\n}\n\n.login-title {\n  font-weight: bold;\n}\n\n.clr-black {\n  color: var(--black-clr);\n}\n\n.input-icon {\n  font-size: 1.5rem;\n  margin-top: 21px;\n  margin-right: 4px;\n}\n\n.icon-col {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.form-lbl {\n  font-weight: bold;\n}\n\n.login-btn {\n  --color: #ffffff ;\n}\n\n.forget-lbl {\n  float: right;\n  margin-top: 4%;\n}\n\n.signup {\n  text-align: center;\n}\n\n.eyebtn {\n  z-index: 999;\n  position: absolute;\n  right: 0;\n}\n\nion-input {\n  font-size: 1.1rem;\n  color: var(--black-clr);\n  font-weight: bold;\n}\n\n.align-check {\n  height: 1.6rem;\n  width: 1.6rem;\n  z-index: 99;\n  position: absolute;\n  right: 0;\n  margin: -2.3rem 0.4rem 0rem 0rem;\n}\n\nion-item {\n  --background:var(--white-clr);\n}\n\n.transImg {\n  position: absolute;\n  top: 13%;\n  width: 200px;\n  right: 26%;\n  opacity: 0.05;\n}\n\n.inputs {\n  border-bottom: 1px solid #e5e5e5;\n  opacity: 1;\n  color: #445b78;\n  font-family: inherit;\n  font-size: 15px;\n  width: 100%;\n  text-align: left;\n}\n\n.progress-outer {\n  width: 96%;\n  margin: 10px 2%;\n  padding: 3px;\n  text-align: center;\n  background-color: #f4f4f4;\n  color: #fff;\n  border-radius: 10px;\n}\n\n.progress-inner {\n  min-width: 15%;\n  white-space: nowrap;\n  overflow: hidden;\n  padding: 2px;\n  border-radius: 10px;\n  background-color: var(--main-bg-color);\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcaW9uaWMlMjBQcm9cXGZnJTIwYmFuY2ElMjBjb25uZWN0XFxzcmNcXGFwcFxcYXV0aFxcbG9naW5cXGxvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQU8sU0FBQTtBQ0VQOztBRERBO0VBQU8sVUFBQTtBQ0tQOztBREpBO0VBQ0Usc0NBQUE7RUFDQSw4QkFBQTtFQUNBLCtCQUFBO0VBRUEsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsOENBQUE7QUNNRjs7QURIQTtFQUFNLFdBQUE7RUFBVyxjQUFBO0FDUWpCOztBRFBBO0VBQVUsVUFBQTtFQUFXLGVBQUE7QUNZckI7O0FEWEE7RUFBVSxjQUFBO0VBQWlCLGlCQUFBO0VBQW9CLGtCQUFBO0FDaUIvQzs7QURoQkE7RUFBVyxpQkFBQTtFQUFpQiwwQ0FBQTtBQ3FCNUI7O0FEcEJBO0VBQVMsZUFBQTtBQ3dCVDs7QUR2QkE7RUFBVyxvQ0FBQTtBQzJCWDs7QUQxQkE7RUFBYSxpQkFBQTtBQzhCYjs7QUQ3QkE7RUFBVyx1QkFBQTtBQ2lDWDs7QURoQ0E7RUFBWSxpQkFBQTtFQUFtQixnQkFBQTtFQUFpQixpQkFBQTtBQ3NDaEQ7O0FEckNBO0VBQVUsYUFBQTtFQUFlLHVCQUFBO0VBQXlCLG1CQUFBO0FDMkNsRDs7QUQxQ0E7RUFBVSxpQkFBQTtBQzhDVjs7QUQ3Q0E7RUFBWSxpQkFBQTtBQ2lEWjs7QUQ5Q0E7RUFBWSxZQUFBO0VBQWUsY0FBQTtBQ21EM0I7O0FEbERBO0VBQVEsa0JBQUE7QUNzRFI7O0FEckRBO0VBQVEsWUFBQTtFQUFlLGtCQUFBO0VBQXFCLFFBQUE7QUMyRDVDOztBRDFEQTtFQUFVLGlCQUFBO0VBQW1CLHVCQUFBO0VBQTBCLGlCQUFBO0FDZ0V2RDs7QUQvREE7RUFDRSxjQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxnQ0FBQTtBQ2tFRjs7QURoRUE7RUFBUyw2QkFBQTtBQ29FVDs7QURsRUE7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7QUNxRUY7O0FEL0RBO0VBQ0UsZ0NBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQ2tFRjs7QUQ3REE7RUFDRSxVQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBRUEsV0FBQTtFQUNBLG1CQUFBO0FDK0RGOztBRDVEQTtFQUNFLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esc0NBQUE7RUFDQSxlQUFBO0FDK0RGIiwiZmlsZSI6ImxvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hci0we21hcmdpbjogMDt9XHJcbi5wYWQtMHtwYWRkaW5nOiAwO31cclxuLmxvZ28tYmxvY2t7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbWFpbi1iZy1jb2xvcik7XHJcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMzAlO1xyXG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAzMCU7XHJcbiAgLy8gYm94LXNoYWRvdzogMHB4IDBweCAyMHB4IDZweCAjZDlkOWQ5O1xyXG4gIGhlaWdodDogMTcwcHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGJveC1zaGFkb3c6IDBweCAxMHB4ICNmZjQ2NTgsIDBweCAyMHB4ICNmZjdjODksO1xyXG59XHJcblxyXG4ubG9nb3toZWlnaHQ6MzAlO21hcmdpbi10b3A6IDUlO31cclxuLmxvZ28taW1ne3dpZHRoOiA4NSU7bWFyZ2luLXRvcDogLTUlO31cclxuLmNlbnRlciB7IGRpc3BsYXk6IGJsb2NrOyAgbWFyZ2luLWxlZnQ6IGF1dG87ICBtYXJnaW4tcmlnaHQ6IGF1dG87fVxyXG4uZm9ybS1jYXJke2JvcmRlci1yYWRpdXM6NSU7Ym9yZGVyLXRvcDogNXB4IHNvbGlkIHZhcigtLW1haW4tYmctY29sb3IpO31cclxuLnBvaW50ZXJ7Y3Vyc29yOiBwb2ludGVyO31cclxuLmZvcm0tY2FyZHtiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7fVxyXG4ubG9naW4tdGl0bGV7Zm9udC13ZWlnaHQ6IGJvbGQ7ICB9XHJcbi5jbHItYmxhY2t7Y29sb3I6IHZhcigtLWJsYWNrLWNscik7fVxyXG4uaW5wdXQtaWNvbntmb250LXNpemU6IDEuNXJlbTsgbWFyZ2luLXRvcDogMjFweDttYXJnaW4tcmlnaHQ6IDRweDt9XHJcbi5pY29uLWNvbHtkaXNwbGF5OiBmbGV4OyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgYWxpZ24taXRlbXM6IGNlbnRlcjt9XHJcbi5mb3JtLWxibHtmb250LXdlaWdodDogYm9sZDt9XHJcbi5sb2dpbi1idG57IC0tY29sb3I6ICNmZmZmZmYgO1xyXG4gIC8vIG1hcmdpbi10b3A6MTElO1xyXG59XHJcbi5mb3JnZXQtbGJse2Zsb2F0OiByaWdodDsgIG1hcmdpbi10b3A6NCU7fVxyXG4uc2lnbnVwe3RleHQtYWxpZ246IGNlbnRlcjt9XHJcbi5leWVidG57ei1pbmRleDogOTk5OyAgcG9zaXRpb246IGFic29sdXRlOyAgcmlnaHQ6IDA7fVxyXG5pb24taW5wdXR7Zm9udC1zaXplOiAxLjFyZW07IGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpOyAgZm9udC13ZWlnaHQ6IGJvbGQ7fVxyXG4uYWxpZ24tY2hlY2sge1xyXG4gIGhlaWdodDogMS42cmVtO1xyXG4gIHdpZHRoOiAxLjZyZW07XHJcbiAgei1pbmRleDogOTk7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHJpZ2h0OiAwO1xyXG4gIG1hcmdpbjogLTIuM3JlbSAwLjRyZW0gMHJlbSAwcmVtO1xyXG59XHJcbmlvbi1pdGVtey0tYmFja2dyb3VuZDp2YXIoLS13aGl0ZS1jbHIpO31cclxuXHJcbi50cmFuc0ltZ3tcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAxMyU7XHJcbiAgd2lkdGg6IDIwMHB4O1xyXG4gIHJpZ2h0OiAyNiU7XHJcbiAgb3BhY2l0eTogLjA1O1xyXG59XHJcbi5mb3JtLWxibCB7XHJcbiAgLy8gbWFyZ2luLWxlZnQ6IDMlO1xyXG59XHJcblxyXG4uaW5wdXRzIHtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U1ZTVlNTtcclxuICBvcGFjaXR5OiAxO1xyXG4gIGNvbG9yOiAjNDQ1Yjc4O1xyXG4gIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxuICB3aWR0aDogMTAwJTtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIC8vIHBhZGRpbmc6IDByZW0gMS42cmVtIDByZW0gMS4xcmVtO1xyXG59XHJcblxyXG5cclxuLnByb2dyZXNzLW91dGVyIHtcclxuICB3aWR0aDogOTYlO1xyXG4gIG1hcmdpbjogMTBweCAyJTtcclxuICBwYWRkaW5nOiAzcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmNGY0ZjQ7XHJcbiAgLy8gYm9yZGVyOiAxcHggc29saWQgI2RjZGNkYztcclxuICBjb2xvcjogI2ZmZjtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcblxyXG4ucHJvZ3Jlc3MtaW5uZXIge1xyXG4gIG1pbi13aWR0aDogMTUlO1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICBwYWRkaW5nOiAycHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOnZhcigtLW1haW4tYmctY29sb3IpO1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxufSIsIi5tYXItMCB7XG4gIG1hcmdpbjogMDtcbn1cblxuLnBhZC0wIHtcbiAgcGFkZGluZzogMDtcbn1cblxuLmxvZ28tYmxvY2sge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1tYWluLWJnLWNvbG9yKTtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMzAlO1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMzAlO1xuICBoZWlnaHQ6IDE3MHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJveC1zaGFkb3c6IDBweCAxMHB4ICNmZjQ2NTgsIDBweCAyMHB4ICNmZjdjODk7XG59XG5cbi5sb2dvIHtcbiAgaGVpZ2h0OiAzMCU7XG4gIG1hcmdpbi10b3A6IDUlO1xufVxuXG4ubG9nby1pbWcge1xuICB3aWR0aDogODUlO1xuICBtYXJnaW4tdG9wOiAtNSU7XG59XG5cbi5jZW50ZXIge1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbn1cblxuLmZvcm0tY2FyZCB7XG4gIGJvcmRlci1yYWRpdXM6IDUlO1xuICBib3JkZXItdG9wOiA1cHggc29saWQgdmFyKC0tbWFpbi1iZy1jb2xvcik7XG59XG5cbi5wb2ludGVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uZm9ybS1jYXJkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpO1xufVxuXG4ubG9naW4tdGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLmNsci1ibGFjayB7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xufVxuXG4uaW5wdXQtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMS41cmVtO1xuICBtYXJnaW4tdG9wOiAyMXB4O1xuICBtYXJnaW4tcmlnaHQ6IDRweDtcbn1cblxuLmljb24tY29sIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5mb3JtLWxibCB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4ubG9naW4tYnRuIHtcbiAgLS1jb2xvcjogI2ZmZmZmZiA7XG59XG5cbi5mb3JnZXQtbGJsIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiA0JTtcbn1cblxuLnNpZ251cCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmV5ZWJ0biB7XG4gIHotaW5kZXg6IDk5OTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMDtcbn1cblxuaW9uLWlucHV0IHtcbiAgZm9udC1zaXplOiAxLjFyZW07XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLmFsaWduLWNoZWNrIHtcbiAgaGVpZ2h0OiAxLjZyZW07XG4gIHdpZHRoOiAxLjZyZW07XG4gIHotaW5kZXg6IDk5O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAwO1xuICBtYXJnaW46IC0yLjNyZW0gMC40cmVtIDByZW0gMHJlbTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6dmFyKC0td2hpdGUtY2xyKTtcbn1cblxuLnRyYW5zSW1nIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDEzJTtcbiAgd2lkdGg6IDIwMHB4O1xuICByaWdodDogMjYlO1xuICBvcGFjaXR5OiAwLjA1O1xufVxuXG4uaW5wdXRzIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlNWU1ZTU7XG4gIG9wYWNpdHk6IDE7XG4gIGNvbG9yOiAjNDQ1Yjc4O1xuICBmb250LWZhbWlseTogaW5oZXJpdDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICB3aWR0aDogMTAwJTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxuLnByb2dyZXNzLW91dGVyIHtcbiAgd2lkdGg6IDk2JTtcbiAgbWFyZ2luOiAxMHB4IDIlO1xuICBwYWRkaW5nOiAzcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y0ZjRmNDtcbiAgY29sb3I6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5wcm9ncmVzcy1pbm5lciB7XG4gIG1pbi13aWR0aDogMTUlO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwYWRkaW5nOiAycHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW1haW4tYmctY29sb3IpO1xuICBmb250LXNpemU6IDEycHg7XG59Il19 */";

/***/ }),

/***/ 6908:
/*!***************************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.scss?ngResource ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".card {\n  border-left: 3px solid red;\n}\n\n.next_arrow {\n  margin-top: 15%;\n  font-size: 20px;\n}\n\n.total_count {\n  float: right;\n  background: red;\n}\n\n.filter-icon {\n  font-size: 1.3rem;\n  color: var(--white-clr);\n  padding-right: 12px;\n}\n\n.fltr-btn {\n  padding: 6px;\n  --border-radius: 3px;\n}\n\nion-item {\n  --background:var(--white-clr) ;\n}\n\nion-select {\n  color: var(--black-clr) !important;\n}\n\n.faq-list {\n  margin: 0% 0% 3% 0%;\n  border-radius: 5px;\n  border-top: 3px solid var(--main-bg-color);\n}\n\n.faq-list-data {\n  border: 1px solid #f4f5f8;\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px;\n  margin-top: -1px;\n}\n\ntable {\n  width: 100%;\n  border-bottom: 3px solid #58b900;\n}\n\ntable tr, td {\n  padding: 4% 0% 4% 0%;\n  font-size: 0.8rem;\n  border: 1px solid #91949c;\n  color: var(--black-clr);\n  text-align: center;\n}\n\ntable tr th {\n  padding: 4% 1% 4% 1%;\n  font-size: 0.7rem;\n  text-align: center;\n  border: 1px solid #91949c;\n  color: var(--black-clr);\n}\n\n.tbl-lbl {\n  width: 50%;\n}\n\n.tbl-val {\n  width: 60%;\n}\n\nion-searchbar, ion-textarea {\n  color: var(--black-clr);\n}\n\n.list-lbl {\n  font-size: 1rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: var(--white-clr) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhc2hib2FyZC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcaW9uaWMlMjBQcm9cXGZnJTIwYmFuY2ElMjBjb25uZWN0XFxzcmNcXGFwcFxcZGFzaGJvYXJkXFxkYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7RUFDQSxvQkFBQTtBQ0VKOztBREFBO0VBQVMsOEJBQUE7QUNJVDs7QURGQTtFQUFXLGtDQUFBO0FDTVg7O0FERkE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7QUNLSjs7QURGQTtFQUNJLHlCQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtFQUNBLGdCQUFBO0FDS0o7O0FEREE7RUFDSSxXQUFBO0VBQ0EsZ0NBQUE7QUNJSjs7QURFQTtFQUNJLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURDQTtFQUNJLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsdUJBQUE7QUNFSjs7QURDQTtFQUNJLFVBQUE7QUNFSjs7QURDQTtFQUNJLFVBQUE7QUNFSjs7QURBQTtFQUEyQix1QkFBQTtBQ0kzQjs7QUREQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0NBQUE7QUNJSiIsImZpbGUiOiJkYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZCB7XHJcbiAgICBib3JkZXItbGVmdDogM3B4IHNvbGlkIHJlZDtcclxufVxyXG5cclxuLm5leHRfYXJyb3cge1xyXG4gICAgbWFyZ2luLXRvcDogMTUlO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcblxyXG4udG90YWxfY291bnQge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgYmFja2dyb3VuZDogcmVkO1xyXG59XHJcblxyXG4uZmlsdGVyLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxLjNyZW07XHJcbiAgICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDEycHg7XHJcbn1cclxuLmZsdHItYnRuIHtcclxuICAgIHBhZGRpbmc6IDZweDtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogM3B4O1xyXG59XHJcbmlvbi1pdGVtey0tYmFja2dyb3VuZDp2YXIoLS13aGl0ZS1jbHIpIH1cclxuLy8gaW9uLWxhYmVse2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7fVxyXG5pb24tc2VsZWN0e2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7fVxyXG5cclxuXHJcblxyXG4uZmFxLWxpc3Qge1xyXG4gICAgbWFyZ2luOiAwJSAwJSAzJSAwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIGJvcmRlci10b3A6IDNweCBzb2xpZCB2YXIoLS1tYWluLWJnLWNvbG9yKTtcclxufVxyXG5cclxuLmZhcS1saXN0LWRhdGEge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2Y0ZjVmODtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMXB4O1xyXG59XHJcblxyXG5cclxudGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItYm90dG9tOiAzcHggc29saWQgIzU4YjkwMDtcclxufVxyXG4vLyAubGlzdC1sYmwge1xyXG4vLyAgICAgY29sb3I6IHZhcigtLXdoaXRlLWNscikgO1xyXG4vLyB9XHJcblxyXG50YWJsZSB0ciwgdGQge1xyXG4gICAgcGFkZGluZzogNCUgMCUgNCUgMCU7XHJcbiAgICBmb250LXNpemU6IDAuOHJlbTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM5MTk0OWM7XHJcbiAgICBjb2xvcjogdmFyKC0tYmxhY2stY2xyKTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG50YWJsZSB0ciB0aCB7XHJcbiAgICBwYWRkaW5nOiA0JSAxJSA0JSAxJTtcclxuICAgIGZvbnQtc2l6ZTogMC43cmVtO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzkxOTQ5YztcclxuICAgIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xyXG59XHJcblxyXG4udGJsLWxibCB7XHJcbiAgICB3aWR0aDogNTAlO1xyXG59XHJcblxyXG4udGJsLXZhbCB7XHJcbiAgICB3aWR0aDogNjAlO1xyXG59XHJcbmlvbi1zZWFyY2hiYXIsaW9uLXRleHRhcmVhe2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpO31cclxuXHJcblxyXG4ubGlzdC1sYmwge1xyXG4gICAgZm9udC1zaXplOiAxLjByZW07XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgIGNvbG9yOnZhcigtLXdoaXRlLWNscikgIWltcG9ydGFudCA7XHJcbn1cclxuIFxyXG5cclxuXHJcbiAiLCIuY2FyZCB7XG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgcmVkO1xufVxuXG4ubmV4dF9hcnJvdyB7XG4gIG1hcmdpbi10b3A6IDE1JTtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4udG90YWxfY291bnQge1xuICBmbG9hdDogcmlnaHQ7XG4gIGJhY2tncm91bmQ6IHJlZDtcbn1cblxuLmZpbHRlci1pY29uIHtcbiAgZm9udC1zaXplOiAxLjNyZW07XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xufVxuXG4uZmx0ci1idG4ge1xuICBwYWRkaW5nOiA2cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogM3B4O1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDp2YXIoLS13aGl0ZS1jbHIpIDtcbn1cblxuaW9uLXNlbGVjdCB7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7XG59XG5cbi5mYXEtbGlzdCB7XG4gIG1hcmdpbjogMCUgMCUgMyUgMCU7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLXRvcDogM3B4IHNvbGlkIHZhcigtLW1haW4tYmctY29sb3IpO1xufVxuXG4uZmFxLWxpc3QtZGF0YSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmNGY1Zjg7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcbiAgbWFyZ2luLXRvcDogLTFweDtcbn1cblxudGFibGUge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICM1OGI5MDA7XG59XG5cbnRhYmxlIHRyLCB0ZCB7XG4gIHBhZGRpbmc6IDQlIDAlIDQlIDAlO1xuICBmb250LXNpemU6IDAuOHJlbTtcbiAgYm9yZGVyOiAxcHggc29saWQgIzkxOTQ5YztcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxudGFibGUgdHIgdGgge1xuICBwYWRkaW5nOiA0JSAxJSA0JSAxJTtcbiAgZm9udC1zaXplOiAwLjdyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyOiAxcHggc29saWQgIzkxOTQ5YztcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG59XG5cbi50YmwtbGJsIHtcbiAgd2lkdGg6IDUwJTtcbn1cblxuLnRibC12YWwge1xuICB3aWR0aDogNjAlO1xufVxuXG5pb24tc2VhcmNoYmFyLCBpb24tdGV4dGFyZWEge1xuICBjb2xvcjogdmFyKC0tYmxhY2stY2xyKTtcbn1cblxuLmxpc3QtbGJsIHtcbiAgZm9udC1zaXplOiAxcmVtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xuICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xufSJdfQ== */";

/***/ }),

/***/ 3306:
/*!*******************************************************************!*\
  !*** ./src/app/dsrActivity/dsrActivity.component.scss?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".mar-0 {\n  margin: 0;\n}\n\n.pad-0 {\n  padding: 0;\n}\n\n.bold {\n  font-weight: bold;\n}\n\n.header-title {\n  position: absolute;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  text-align: left !important;\n  padding-left: 2%;\n}\n\n.center {\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\n.form-card {\n  border-radius: 15px;\n  border-top: 5px solid var(--main-bg-color);\n}\n\n.pointer {\n  cursor: pointer;\n}\n\n.form-card {\n  background-color: rgb(255, 255, 255);\n}\n\n.login-title {\n  font-weight: bold;\n}\n\n.input-icon {\n  font-size: 1.5rem;\n  margin-top: 7px;\n}\n\n.icon-col {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.login-btn {\n  --color: var(--white-clr);\n  margin-top: 11%;\n}\n\n.input {\n  border-bottom: 1px solid #e6e6e6 !important;\n  opacity: 1;\n  color: var(--black-clr);\n  font-family: inherit;\n  font-size: 15px;\n  width: 100%;\n  text-align: left;\n}\n\n.item-interactive {\n  --border-width: 0 0 0 0 !important;\n  --inner-border-width: 0;\n  --show-full-highlight: 0;\n  --show-inset-highlight: 0;\n}\n\n.add-icon {\n  font-size: 1.3rem;\n  color: #ffffff;\n  margin-right: 3%;\n}\n\n.filter-icon {\n  font-size: 1.3rem;\n  color: #06005f;\n  margin-right: auto;\n  margin-left: auto;\n  margin-top: 14%;\n  display: block;\n}\n\n.fltr-btn {\n  margin: 9% 0% 6% 0%;\n  font-size: 18px;\n  color: var(--main-bg-color);\n  font-weight: bold;\n  cursor: pointer;\n}\n\n.filter-close-icon {\n  float: right;\n  font-size: 1.5rem;\n  color: #a9a9a9;\n}\n\n.download-icon {\n  font-size: 1.5rem;\n  color: var(--white-clr);\n  margin-right: 3%;\n}\n\n.faq-list {\n  margin: 0% 0% 3% 0%;\n  border-radius: 5px;\n  border-top: 3px solid var(--main-bg-color);\n}\n\n.faq-list-data {\n  border: 1px solid #f4f5f8;\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px;\n  margin-top: -1px;\n}\n\n.list-date {\n  font-size: 0.7rem;\n  color: var(--white-clr);\n  padding-bottom: 5px;\n}\n\n.list-lbl {\n  font-size: 1rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: var(--white-clr);\n}\n\n.detail-lbl {\n  font-size: 0.7rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: #343f5e;\n}\n\ntable {\n  width: 100%;\n  border-bottom: 3px solid #58b900;\n}\n\ntable tr td {\n  padding: 3% 2% 3% 2%;\n  font-size: 0.8rem;\n  border: 1px solid #91949c;\n  color: var(--black-clr);\n}\n\n.tbl-lbl {\n  width: 40%;\n}\n\n.tbl-val {\n  width: 60%;\n}\n\nion-accordion {\n  margin: 0 auto;\n}\n\n.fix-searchbar {\n  width: 100%;\n  background: var(--body-bg);\n  border-bottom: 1px solid rgba(36, 36, 36, 0.1843137255);\n}\n\n.sc-ion-searchbar-md-h {\n  --box-shadow: none !important;\n}\n\n.remove-icon {\n  font-size: 1.9rem;\n  color: red;\n  margin-left: auto;\n  display: block;\n}\n\n.subActivity {\n  border: 1px solid #e1e1e1;\n  border-radius: 5px;\n}\n\n.sub_activity {\n  margin-left: 12%;\n  padding: 0;\n}\n\n.sub_activity li {\n  padding: 5px;\n}\n\nform ion-item {\n  --background: var(--white-clr) !important;\n}\n\nion-searchbar,\nion-textarea {\n  color: var(--black-clr);\n}\n\n.empty-btn {\n  width: 55%;\n}\n\n.popover-row {\n  display: inline-block;\n}\n\n.popover-row ion-icon {\n  font-size: 1.1rem;\n}\n\nion-popover ion-content ion-list {\n  background: rgb(255, 255, 255);\n}\n\nion-popover ion-content ion-list ion-item {\n  --background: rgb(255, 255, 255) !important;\n}\n\nion-popover ion-content ion-list ion-item span,\nion-icon {\n  color: var(--black-clr);\n}\n\n.calander-icon {\n  position: absolute;\n  right: 7%;\n  float: right;\n  margin-top: 22%;\n  font-size: 14px;\n}\n\n.calander-input {\n  position: relative;\n  border-bottom: 1px solid rgb(214, 214, 214);\n  --padding-bottom: 2px;\n  font-size: 13px;\n  font-weight: bold;\n  margin-top: 9px;\n  width: 94%;\n}\n\n.dt-icon {\n  position: absolute;\n  right: 6%;\n  float: right;\n  margin-top: 12%;\n  font-size: 16px;\n}\n\n.time-icon {\n  position: absolute;\n  right: 10%;\n  float: right;\n  margin-top: 22%;\n  font-size: 16px;\n}\n\n.sub-time-icon {\n  position: absolute;\n  right: 11%;\n  float: right;\n  margin-top: 36%;\n  font-size: 17px;\n}\n\n.back-arrow {\n  font-size: 20px;\n  margin: 0px 0px -4px 0px;\n  color: white;\n}\n\n.sc-ion-buttons-md-s ion-button:not(.button-round) {\n  font-weight: bold !important;\n  --color: white !important;\n}\n\n.textarea {\n  width: 100%;\n  border: 1px solid lightgray;\n  overflow: auto;\n  background: var(--white-clr);\n  color: var(--black-clr);\n  padding: 10px;\n  border-radius: 5px;\n  box-shadow: 2px 2px 10px 0px #f0f0f0;\n}\n\ntextarea:focus {\n  outline: none;\n}\n\n.progress-inner {\n  min-width: 15%;\n  white-space: nowrap;\n  overflow: hidden;\n  padding: 2px;\n  border-radius: 10px;\n  background-color: var(--main-bg-color);\n  font-size: 12px;\n}\n\nion-modal {\n  --width: 320px;\n  --height: 400px;\n  --border-radius: 8px;\n}\n\nion-modal ion-datetime {\n  height: 400px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRzckFjdGl2aXR5LmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxpb25pYyUyMFByb1xcZmclMjBiYW5jYSUyMGNvbm5lY3RcXHNyY1xcYXBwXFxkc3JBY3Rpdml0eVxcZHNyQWN0aXZpdHkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxTQUFBO0FDQ0o7O0FERUE7RUFDSSxVQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLGdCQUFBO0FDQ0o7O0FERUE7RUFDSSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ0NKOztBREVBO0VBQ0ksbUJBQUE7RUFDQSwwQ0FBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtBQ0NKOztBREVBO0VBQ0ksb0NBQUE7QUNDSjs7QURFQTtFQUNJLGlCQUFBO0FDQ0o7O0FER0E7RUFDSSxpQkFBQTtFQUNBLGVBQUE7QUNBSjs7QURHQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0E7RUFDSSx5QkFBQTtFQUNBLGVBQUE7QUNBSjs7QURPQTtFQUNJLDJDQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FDSko7O0FEUUE7RUFDSSxrQ0FBQTtFQUNBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSx5QkFBQTtBQ0xKOztBRFFBO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNMSjs7QURRQTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQ0xKOztBRFNBO0VBQ0ksbUJBQUE7RUFDQSxlQUFBO0VBQ0EsMkJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUNOSjs7QURTQTtFQUNJLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUNOSjs7QURTQTtFQUNJLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtBQ05KOztBRFdBO0VBQ0ksbUJBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0FDUko7O0FEV0E7RUFDSSx5QkFBQTtFQUNBLDhCQUFBO0VBQ0EsK0JBQUE7RUFDQSxnQkFBQTtBQ1JKOztBRFdBO0VBQ0ksaUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDUko7O0FEV0E7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FDUko7O0FEV0E7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FDUko7O0FEV0E7RUFDSSxXQUFBO0VBQ0EsZ0NBQUE7QUNSSjs7QURXQTtFQUNJLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLHVCQUFBO0FDUko7O0FEV0E7RUFDSSxVQUFBO0FDUko7O0FEV0E7RUFDSSxVQUFBO0FDUko7O0FEV0E7RUFDSSxjQUFBO0FDUko7O0FEWUE7RUFFSSxXQUFBO0VBRUEsMEJBQUE7RUFDQSx1REFBQTtBQ1hKOztBRGNBO0VBQ0ksNkJBQUE7QUNYSjs7QURlQTtFQUNJLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBRUEsY0FBQTtBQ2JKOztBRGdCQTtFQUNJLHlCQUFBO0VBQ0Esa0JBQUE7QUNiSjs7QURnQkE7RUFDSSxnQkFBQTtFQUNBLFVBQUE7QUNiSjs7QURnQkE7RUFDSSxZQUFBO0FDYko7O0FEZ0JBO0VBQ0kseUNBQUE7QUNiSjs7QURnQkE7O0VBRUksdUJBQUE7QUNiSjs7QURpQkE7RUFDSSxVQUFBO0FDZEo7O0FEa0JBO0VBQ0kscUJBQUE7QUNmSjs7QURrQkE7RUFDSSxpQkFBQTtBQ2ZKOztBRGtCQTtFQUNJLDhCQUFBO0FDZko7O0FEa0JBO0VBQ0ksMkNBQUE7QUNmSjs7QURrQkE7O0VBRUksdUJBQUE7QUNmSjs7QURrQkE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUNmSjs7QURrQkE7RUFDSSxrQkFBQTtFQUNBLDJDQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQ2ZKOztBRGtCQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQ2ZKOztBRGtCQTtFQUNJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQ2ZKOztBRGtCQTtFQUNJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQ2ZKOztBRGtCQTtFQUNJLGVBQUE7RUFDQSx3QkFBQTtFQUNBLFlBQUE7QUNmSjs7QURrQkE7RUFDSSw0QkFBQTtFQUNBLHlCQUFBO0FDZko7O0FEa0JBO0VBQ0ksV0FBQTtFQUNBLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLDRCQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQ0FBQTtBQ2ZKOztBRGtCQTtFQUNJLGFBQUE7QUNmSjs7QURvQkE7RUFDSSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHNDQUFBO0VBQ0EsZUFBQTtBQ2pCSjs7QURzQkE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0FDbkJKOztBRHFCRTtFQUNFLGFBQUE7QUNsQkoiLCJmaWxlIjoiZHNyQWN0aXZpdHkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFyLTAge1xyXG4gICAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4ucGFkLTAge1xyXG4gICAgcGFkZGluZzogMDtcclxufVxyXG5cclxuLmJvbGQge1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5oZWFkZXItdGl0bGV7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQgIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctbGVmdDogMiU7XHJcbn1cclxuXHJcbi5jZW50ZXIge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxufVxyXG5cclxuLmZvcm0tY2FyZCB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgYm9yZGVyLXRvcDogNXB4IHNvbGlkIHZhcigtLW1haW4tYmctY29sb3IpO1xyXG59XHJcblxyXG4ucG9pbnRlciB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5mb3JtLWNhcmQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpO1xyXG59XHJcblxyXG4ubG9naW4tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcblxyXG4uaW5wdXQtaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuNXJlbTtcclxuICAgIG1hcmdpbi10b3A6IDdweDtcclxufVxyXG5cclxuLmljb24tY29sIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5sb2dpbi1idG4ge1xyXG4gICAgLS1jb2xvcjogdmFyKC0td2hpdGUtY2xyKTtcclxuICAgIG1hcmdpbi10b3A6IDExJTtcclxufVxyXG5cclxuLmZvcm0tbGJsIHtcclxuICAgIC8vIG1hcmdpbi1sZWZ0OiAzJTtcclxufVxyXG5cclxuLmlucHV0IHtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZTZlNmU2ICFpbXBvcnRhbnQ7XHJcbiAgICBvcGFjaXR5OiAxO1xyXG4gICAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XHJcbiAgICBmb250LWZhbWlseTogaW5oZXJpdDtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIC8vIHBhZGRpbmc6IDByZW0gMS42cmVtIDByZW0gMS4xcmVtO1xyXG59XHJcblxyXG4uaXRlbS1pbnRlcmFjdGl2ZSB7XHJcbiAgICAtLWJvcmRlci13aWR0aDogMCAwIDAgMCAhaW1wb3J0YW50O1xyXG4gICAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDA7XHJcbiAgICAtLXNob3ctZnVsbC1oaWdobGlnaHQ6IDA7XHJcbiAgICAtLXNob3ctaW5zZXQtaGlnaGxpZ2h0OiAwO1xyXG59XHJcblxyXG4uYWRkLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxLjNyZW07XHJcbiAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgIG1hcmdpbi1yaWdodDogMyU7XHJcbn1cclxuXHJcbi5maWx0ZXItaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuM3JlbTtcclxuICAgIGNvbG9yOiAjMDYwMDVmO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAxNCU7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuXHJcbi5mbHRyLWJ0biB7XHJcbiAgICBtYXJnaW46IDklIDAlIDYlIDAlO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgY29sb3I6IHZhcigtLW1haW4tYmctY29sb3IpO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5maWx0ZXItY2xvc2UtaWNvbiB7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBmb250LXNpemU6IDEuNXJlbTtcclxuICAgIGNvbG9yOiAjYTlhOWE5O1xyXG59XHJcblxyXG4uZG93bmxvYWQtaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuNXJlbTtcclxuICAgIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAzJTtcclxufVxyXG5cclxuLy8gZmFxIGxpc3QgY3NzIHN0YXJ0IGhlcmUgXHJcblxyXG4uZmFxLWxpc3Qge1xyXG4gICAgbWFyZ2luOiAwJSAwJSAzJSAwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIGJvcmRlci10b3A6IDNweCBzb2xpZCB2YXIoLS1tYWluLWJnLWNvbG9yKTtcclxufVxyXG5cclxuLmZhcS1saXN0LWRhdGEge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2Y0ZjVmODtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMXB4O1xyXG59XHJcblxyXG4ubGlzdC1kYXRlIHtcclxuICAgIGZvbnQtc2l6ZTogMC43cmVtO1xyXG4gICAgY29sb3I6IHZhcigtLXdoaXRlLWNscik7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG59XHJcblxyXG4ubGlzdC1sYmwge1xyXG4gICAgZm9udC1zaXplOiAxLjByZW07XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xyXG59XHJcblxyXG4uZGV0YWlsLWxibCB7XHJcbiAgICBmb250LXNpemU6IDAuN3JlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG4gICAgY29sb3I6ICMzNDNmNWU7XHJcbn1cclxuXHJcbnRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICM1OGI5MDA7XHJcbn1cclxuXHJcbnRhYmxlIHRyIHRkIHtcclxuICAgIHBhZGRpbmc6IDMlIDIlIDMlIDIlO1xyXG4gICAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjOTE5NDljO1xyXG4gICAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XHJcbn1cclxuXHJcbi50YmwtbGJsIHtcclxuICAgIHdpZHRoOiA0MCU7XHJcbn1cclxuXHJcbi50YmwtdmFsIHtcclxuICAgIHdpZHRoOiA2MCU7XHJcbn1cclxuXHJcbmlvbi1hY2NvcmRpb24ge1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbn1cclxuXHJcblxyXG4uZml4LXNlYXJjaGJhciB7XHJcbiAgICAvLyBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIC8vIHotaW5kZXg6IDk7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1ib2R5LWJnKTtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMjQyNDI0MmY7XHJcbn1cclxuXHJcbi5zYy1pb24tc2VhcmNoYmFyLW1kLWgge1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcblxyXG4ucmVtb3ZlLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxLjlyZW07XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICAvLyBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLnN1YkFjdGl2aXR5IHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlMWUxZTE7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbn1cclxuXHJcbi5zdWJfYWN0aXZpdHkge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEyJTtcclxuICAgIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbi5zdWJfYWN0aXZpdHkgbGkge1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG59XHJcblxyXG5mb3JtIGlvbi1pdGVtIHtcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tc2VhcmNoYmFyLFxyXG5pb24tdGV4dGFyZWEge1xyXG4gICAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XHJcbn1cclxuXHJcblxyXG4uZW1wdHktYnRuIHtcclxuICAgIHdpZHRoOiA1NSU7XHJcbn1cclxuXHJcblxyXG4ucG9wb3Zlci1yb3cge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4ucG9wb3Zlci1yb3cgaW9uLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxLjFyZW07XHJcbn1cclxuXHJcbmlvbi1wb3BvdmVyIGlvbi1jb250ZW50IGlvbi1saXN0IHtcclxuICAgIGJhY2tncm91bmQ6IHJnYigyNTUsIDI1NSwgMjU1KSA7XHJcbn1cclxuXHJcbmlvbi1wb3BvdmVyIGlvbi1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIHtcclxuICAgIC0tYmFja2dyb3VuZDogcmdiKDI1NSwgMjU1LCAyNTUpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1wb3BvdmVyIGlvbi1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIHNwYW4sXHJcbmlvbi1pY29uIHtcclxuICAgIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xyXG59XHJcblxyXG4uY2FsYW5kZXItaWNvbiB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogNyU7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBtYXJnaW4tdG9wOiAyMiU7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuXHJcbi5jYWxhbmRlci1pbnB1dCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiKDIxNCwgMjE0LCAyMTQpO1xyXG4gICAgLS1wYWRkaW5nLWJvdHRvbTogMnB4O1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBtYXJnaW4tdG9wOiA5cHg7XHJcbiAgICB3aWR0aDogOTQlO1xyXG59XHJcblxyXG4uZHQtaWNvbiB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogNiU7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBtYXJnaW4tdG9wOiAxMiU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbi50aW1lLWljb24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDEwJTtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIG1hcmdpbi10b3A6IDIyJTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5cclxuLnN1Yi10aW1lLWljb24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDExJTtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIG1hcmdpbi10b3A6IDM2JTtcclxuICAgIGZvbnQtc2l6ZTogMTdweDtcclxufVxyXG5cclxuLmJhY2stYXJyb3cge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbWFyZ2luOiAwcHggMHB4IC00cHggMHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uc2MtaW9uLWJ1dHRvbnMtbWQtcyBpb24tYnV0dG9uOm5vdCguYnV0dG9uLXJvdW5kKSB7XHJcbiAgICBmb250LXdlaWdodDogYm9sZCAhaW1wb3J0YW50O1xyXG4gICAgLS1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRleHRhcmVhIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS13aGl0ZS1jbHIpO1xyXG4gICAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDJweCAxMHB4IDBweCAjZjBmMGYwO1xyXG59XHJcblxyXG50ZXh0YXJlYTpmb2N1cyB7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcblxyXG5cclxuXHJcbi5wcm9ncmVzcy1pbm5lciB7XHJcbiAgICBtaW4td2lkdGg6IDE1JTtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgcGFkZGluZzogMnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW1haW4tYmctY29sb3IpO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcblxyXG5cclxuLy8gZGF0ZSBjbGFuZGVyIHN0YXJ0IGhlcmUgXHJcbmlvbi1tb2RhbCB7XHJcbiAgICAtLXdpZHRoOiAzMjBweDtcclxuICAgIC0taGVpZ2h0OiA0MDBweDtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIH1cclxuICBpb24tbW9kYWwgaW9uLWRhdGV0aW1lIHtcclxuICAgIGhlaWdodDogNDAwcHg7XHJcbiAgfVxyXG4iLCIubWFyLTAge1xuICBtYXJnaW46IDA7XG59XG5cbi5wYWQtMCB7XG4gIHBhZGRpbmc6IDA7XG59XG5cbi5ib2xkIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5oZWFkZXItdGl0bGUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgdGV4dC1hbGlnbjogbGVmdCAhaW1wb3J0YW50O1xuICBwYWRkaW5nLWxlZnQ6IDIlO1xufVxuXG4uY2VudGVyIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59XG5cbi5mb3JtLWNhcmQge1xuICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICBib3JkZXItdG9wOiA1cHggc29saWQgdmFyKC0tbWFpbi1iZy1jb2xvcik7XG59XG5cbi5wb2ludGVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uZm9ybS1jYXJkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpO1xufVxuXG4ubG9naW4tdGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLmlucHV0LWljb24ge1xuICBmb250LXNpemU6IDEuNXJlbTtcbiAgbWFyZ2luLXRvcDogN3B4O1xufVxuXG4uaWNvbi1jb2wge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmxvZ2luLWJ0biB7XG4gIC0tY29sb3I6IHZhcigtLXdoaXRlLWNscik7XG4gIG1hcmdpbi10b3A6IDExJTtcbn1cblxuLmlucHV0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlNmU2ZTYgIWltcG9ydGFudDtcbiAgb3BhY2l0eTogMTtcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG4gIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xuICBmb250LXNpemU6IDE1cHg7XG4gIHdpZHRoOiAxMDAlO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuXG4uaXRlbS1pbnRlcmFjdGl2ZSB7XG4gIC0tYm9yZGVyLXdpZHRoOiAwIDAgMCAwICFpbXBvcnRhbnQ7XG4gIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xuICAtLXNob3ctZnVsbC1oaWdobGlnaHQ6IDA7XG4gIC0tc2hvdy1pbnNldC1oaWdobGlnaHQ6IDA7XG59XG5cbi5hZGQtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMS4zcmVtO1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgbWFyZ2luLXJpZ2h0OiAzJTtcbn1cblxuLmZpbHRlci1pY29uIHtcbiAgZm9udC1zaXplOiAxLjNyZW07XG4gIGNvbG9yOiAjMDYwMDVmO1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICBtYXJnaW4tdG9wOiAxNCU7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4uZmx0ci1idG4ge1xuICBtYXJnaW46IDklIDAlIDYlIDAlO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiB2YXIoLS1tYWluLWJnLWNvbG9yKTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLmZpbHRlci1jbG9zZS1pY29uIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBmb250LXNpemU6IDEuNXJlbTtcbiAgY29sb3I6ICNhOWE5YTk7XG59XG5cbi5kb3dubG9hZC1pY29uIHtcbiAgZm9udC1zaXplOiAxLjVyZW07XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xuICBtYXJnaW4tcmlnaHQ6IDMlO1xufVxuXG4uZmFxLWxpc3Qge1xuICBtYXJnaW46IDAlIDAlIDMlIDAlO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGJvcmRlci10b3A6IDNweCBzb2xpZCB2YXIoLS1tYWluLWJnLWNvbG9yKTtcbn1cblxuLmZhcS1saXN0LWRhdGEge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZjRmNWY4O1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XG4gIG1hcmdpbi10b3A6IC0xcHg7XG59XG5cbi5saXN0LWRhdGUge1xuICBmb250LXNpemU6IDAuN3JlbTtcbiAgY29sb3I6IHZhcigtLXdoaXRlLWNscik7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG59XG5cbi5saXN0LWxibCB7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgcGFkZGluZy1ib3R0b206IDVweDtcbiAgY29sb3I6IHZhcigtLXdoaXRlLWNscik7XG59XG5cbi5kZXRhaWwtbGJsIHtcbiAgZm9udC1zaXplOiAwLjdyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIGNvbG9yOiAjMzQzZjVlO1xufVxuXG50YWJsZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgIzU4YjkwMDtcbn1cblxudGFibGUgdHIgdGQge1xuICBwYWRkaW5nOiAzJSAyJSAzJSAyJTtcbiAgZm9udC1zaXplOiAwLjhyZW07XG4gIGJvcmRlcjogMXB4IHNvbGlkICM5MTk0OWM7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xufVxuXG4udGJsLWxibCB7XG4gIHdpZHRoOiA0MCU7XG59XG5cbi50YmwtdmFsIHtcbiAgd2lkdGg6IDYwJTtcbn1cblxuaW9uLWFjY29yZGlvbiB7XG4gIG1hcmdpbjogMCBhdXRvO1xufVxuXG4uZml4LXNlYXJjaGJhciB7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1ib2R5LWJnKTtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHJnYmEoMzYsIDM2LCAzNiwgMC4xODQzMTM3MjU1KTtcbn1cblxuLnNjLWlvbi1zZWFyY2hiYXItbWQtaCB7XG4gIC0tYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4ucmVtb3ZlLWljb24ge1xuICBmb250LXNpemU6IDEuOXJlbTtcbiAgY29sb3I6IHJlZDtcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4uc3ViQWN0aXZpdHkge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZTFlMWUxO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG5cbi5zdWJfYWN0aXZpdHkge1xuICBtYXJnaW4tbGVmdDogMTIlO1xuICBwYWRkaW5nOiAwO1xufVxuXG4uc3ViX2FjdGl2aXR5IGxpIHtcbiAgcGFkZGluZzogNXB4O1xufVxuXG5mb3JtIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS13aGl0ZS1jbHIpICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1zZWFyY2hiYXIsXG5pb24tdGV4dGFyZWEge1xuICBjb2xvcjogdmFyKC0tYmxhY2stY2xyKTtcbn1cblxuLmVtcHR5LWJ0biB7XG4gIHdpZHRoOiA1NSU7XG59XG5cbi5wb3BvdmVyLXJvdyB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cblxuLnBvcG92ZXItcm93IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAxLjFyZW07XG59XG5cbmlvbi1wb3BvdmVyIGlvbi1jb250ZW50IGlvbi1saXN0IHtcbiAgYmFja2dyb3VuZDogcmdiKDI1NSwgMjU1LCAyNTUpO1xufVxuXG5pb24tcG9wb3ZlciBpb24tY29udGVudCBpb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogcmdiKDI1NSwgMjU1LCAyNTUpICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1wb3BvdmVyIGlvbi1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIHNwYW4sXG5pb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xufVxuXG4uY2FsYW5kZXItaWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDclO1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDIyJTtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4uY2FsYW5kZXItaW5wdXQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCByZ2IoMjE0LCAyMTQsIDIxNCk7XG4gIC0tcGFkZGluZy1ib3R0b206IDJweDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLXRvcDogOXB4O1xuICB3aWR0aDogOTQlO1xufVxuXG4uZHQtaWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDYlO1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDEyJTtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4udGltZS1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTAlO1xuICBmbG9hdDogcmlnaHQ7XG4gIG1hcmdpbi10b3A6IDIyJTtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4uc3ViLXRpbWUtaWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDExJTtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAzNiU7XG4gIGZvbnQtc2l6ZTogMTdweDtcbn1cblxuLmJhY2stYXJyb3cge1xuICBmb250LXNpemU6IDIwcHg7XG4gIG1hcmdpbjogMHB4IDBweCAtNHB4IDBweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uc2MtaW9uLWJ1dHRvbnMtbWQtcyBpb24tYnV0dG9uOm5vdCguYnV0dG9uLXJvdW5kKSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkICFpbXBvcnRhbnQ7XG4gIC0tY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbi50ZXh0YXJlYSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIG92ZXJmbG93OiBhdXRvO1xuICBiYWNrZ3JvdW5kOiB2YXIoLS13aGl0ZS1jbHIpO1xuICBjb2xvcjogdmFyKC0tYmxhY2stY2xyKTtcbiAgcGFkZGluZzogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBib3gtc2hhZG93OiAycHggMnB4IDEwcHggMHB4ICNmMGYwZjA7XG59XG5cbnRleHRhcmVhOmZvY3VzIHtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLnByb2dyZXNzLWlubmVyIHtcbiAgbWluLXdpZHRoOiAxNSU7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHBhZGRpbmc6IDJweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbWFpbi1iZy1jb2xvcik7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuaW9uLW1vZGFsIHtcbiAgLS13aWR0aDogMzIwcHg7XG4gIC0taGVpZ2h0OiA0MDBweDtcbiAgLS1ib3JkZXItcmFkaXVzOiA4cHg7XG59XG5cbmlvbi1tb2RhbCBpb24tZGF0ZXRpbWUge1xuICBoZWlnaHQ6IDQwMHB4O1xufSJdfQ== */";

/***/ }),

/***/ 961:
/*!*****************************************************!*\
  !*** ./src/app/home/home.component.scss?ngResource ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".title {\n  margin-top: 8%;\n  font-size: 1.2rem;\n  text-align: center;\n  position: relative;\n}\n\n.bg {\n  position: absolute;\n  background-size: cover;\n  width: 100%;\n}\n\n.bg img {\n  width: 100%;\n}\n\n.progress-outer {\n  width: 96%;\n  margin: 10px 2%;\n  padding: 2px;\n  text-align: center;\n  background-color: #f4f4f4;\n  color: #fff;\n  border-radius: 10px;\n}\n\n.progress-inner {\n  min-width: 15%;\n  white-space: nowrap;\n  overflow: hidden;\n  padding: 2px;\n  border-radius: 10px;\n  background-color: var(--main-bg-color);\n  font-size: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUuY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGlvbmljJTIwUHJvXFxmZyUyMGJhbmNhJTIwY29ubmVjdFxcc3JjXFxhcHBcXGhvbWVcXGhvbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDQ0Y7O0FERUE7RUFDRSxrQkFBQTtFQUdBLHNCQUFBO0VBQ0EsV0FBQTtBQ0NGOztBREVBO0VBQ0UsV0FBQTtBQ0NGOztBREtBO0VBQ0UsVUFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUVBLFdBQUE7RUFDQSxtQkFBQTtBQ0hGOztBRE1BO0VBQ0UsY0FBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQ0FBQTtFQUNBLGVBQUE7QUNIRiIsImZpbGUiOiJob21lLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdGxlIHtcclxuICBtYXJnaW4tdG9wOiA4JTtcclxuICBmb250LXNpemU6IDEuMnJlbTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4uYmcge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAtd2Via2l0LWJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgLW1vei1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5iZyBpbWcge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG4ucHJvZ3Jlc3Mtb3V0ZXIge1xyXG4gIHdpZHRoOiA5NiU7XHJcbiAgbWFyZ2luOiAxMHB4IDIlO1xyXG4gIHBhZGRpbmc6IDJweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y0ZjRmNDtcclxuICAvLyBib3JkZXI6IDFweCBzb2xpZCAjZGNkY2RjO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbi5wcm9ncmVzcy1pbm5lciB7XHJcbiAgbWluLXdpZHRoOiAxNSU7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIHBhZGRpbmc6IDJweDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6dmFyKC0tbWFpbi1iZy1jb2xvcik7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG59IiwiLnRpdGxlIHtcbiAgbWFyZ2luLXRvcDogOCU7XG4gIGZvbnQtc2l6ZTogMS4ycmVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmJnIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICAtd2Via2l0LWJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIC1tb3otYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5iZyBpbWcge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLnByb2dyZXNzLW91dGVyIHtcbiAgd2lkdGg6IDk2JTtcbiAgbWFyZ2luOiAxMHB4IDIlO1xuICBwYWRkaW5nOiAycHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y0ZjRmNDtcbiAgY29sb3I6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5wcm9ncmVzcy1pbm5lciB7XG4gIG1pbi13aWR0aDogMTUlO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBwYWRkaW5nOiAycHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLW1haW4tYmctY29sb3IpO1xuICBmb250LXNpemU6IDEwcHg7XG59Il19 */";

/***/ }),

/***/ 6174:
/*!*******************************************************************!*\
  !*** ./src/app/network-err/network-err.component.scss?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJuZXR3b3JrLWVyci5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 9320:
/*!*********************************************************!*\
  !*** ./src/app/report/report.component.scss?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".filter-icon {\n  font-size: 1.3rem;\n  color: #ffffff;\n  margin-right: 12px;\n  margin-left: auto;\n  display: block;\n}\n\n.fltr-btn {\n  font-size: 18px;\n  color: var(--main-bg-color);\n  font-weight: bold;\n  cursor: pointer;\n}\n\n.filter-close-icon {\n  float: right;\n  font-size: 1.5rem;\n  color: #a9a9a9;\n}\n\n.faq-list {\n  margin: 0% 0% 3% 0%;\n  border-radius: 5px;\n  border-top: 3px solid var(--main-bg-color);\n}\n\n.faq-list-data {\n  border: 1px solid #f4f5f8;\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px;\n  margin-top: -1px;\n}\n\n.list-date {\n  font-size: 0.7rem;\n  color: var(--white-clr) !important;\n  padding-bottom: 5px;\n}\n\n.add-icon {\n  font-size: 1.3rem;\n  color: #ffffff;\n  margin-right: 1%;\n}\n\n.list-lbl {\n  font-size: 1.1rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: var(--white-clr) !important;\n}\n\n.detail-lbl {\n  font-size: 0.7rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: #343f5e;\n}\n\ntable {\n  width: 100%;\n  border-bottom: 3px solid #58b900;\n}\n\ntable tr td {\n  padding: 3% 2% 3% 2%;\n  font-size: 0.8rem;\n  border: 1px solid #91949c;\n  color: var(--black-clr);\n}\n\n.tbl-lbl {\n  width: 40%;\n}\n\n.tbl-val {\n  width: 60%;\n}\n\nion-accordion {\n  margin: 0 auto;\n}\n\n.fix-searchbar {\n  width: 100%;\n  background: var(--body-bg);\n  border-bottom: 1px solid rgba(36, 36, 36, 0.1843137255);\n}\n\n.sc-ion-searchbar-md-h {\n  --box-shadow: none !important;\n}\n\n.remove-icon {\n  font-size: 1.9rem;\n  color: red;\n  margin-left: auto;\n  margin-right: auto;\n  display: block;\n}\n\nform ion-item {\n  --background: var(--white-clr) !important;\n}\n\n.subActivity {\n  border: 1px solid #e1e1e1;\n  border-radius: 5px;\n}\n\n.sub_activity {\n  margin-left: 12%;\n  padding: 0;\n}\n\n.sub_activity li {\n  padding: 5px;\n}\n\n.calander-icon {\n  position: absolute;\n  right: 7%;\n  float: right;\n  margin-top: 20%;\n  font-size: 14px;\n}\n\n.calander-input {\n  position: relative;\n  border-bottom: 1px solid rgb(87, 86, 86);\n  --padding-bottom: 2px;\n  font-size: 13px;\n  font-weight: bold;\n  width: 94%;\n}\n\n.error2 {\n  color: red;\n  font-size: 9px;\n  margin: 0% 0% 0% 0%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlcG9ydC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcaW9uaWMlMjBQcm9cXGZnJTIwYmFuY2ElMjBjb25uZWN0XFxzcmNcXGFwcFxccmVwb3J0XFxyZXBvcnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQ0FKOztBREdBO0VBQ0ksZUFBQTtFQUNBLDJCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FDQUo7O0FER0E7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FDQUo7O0FES0E7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7QUNGSjs7QURLQTtFQUNJLHlCQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtFQUNBLGdCQUFBO0FDRko7O0FES0E7RUFDSSxpQkFBQTtFQUNBLGtDQUFBO0VBQ0EsbUJBQUE7QUNGSjs7QURJQTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDREo7O0FER0E7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQ0FBQTtBQ0FKOztBREdBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQ0FKOztBREdBO0VBQ0ksV0FBQTtFQUNBLGdDQUFBO0FDQUo7O0FER0E7RUFDSSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSx1QkFBQTtBQ0FKOztBREdBO0VBQ0ksVUFBQTtBQ0FKOztBREdBO0VBQ0ksVUFBQTtBQ0FKOztBREdBO0VBQ0ksY0FBQTtBQ0FKOztBRElBO0VBRUksV0FBQTtFQUVBLDBCQUFBO0VBQ0EsdURBQUE7QUNISjs7QURNQTtFQUNJLDZCQUFBO0FDSEo7O0FETUE7RUFDSSxpQkFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQ0hKOztBRE1BO0VBQ0kseUNBQUE7QUNISjs7QURNQTtFQUNJLHlCQUFBO0VBQ0Esa0JBQUE7QUNISjs7QURNQTtFQUNJLGdCQUFBO0VBQ0EsVUFBQTtBQ0hKOztBRE1BO0VBQ0ksWUFBQTtBQ0hKOztBREtBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FDRko7O0FES0E7RUFDSSxrQkFBQTtFQUNBLHdDQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFBc0IsVUFBQTtBQ0QxQjs7QURJQTtFQUNJLFVBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUNESiIsImZpbGUiOiJyZXBvcnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLmZpbHRlci1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMS4zcmVtO1xyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEycHg7XHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4uZmx0ci1idG4ge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgY29sb3I6IHZhcigtLW1haW4tYmctY29sb3IpO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5maWx0ZXItY2xvc2UtaWNvbiB7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBmb250LXNpemU6IDEuNXJlbTtcclxuICAgIGNvbG9yOiAjYTlhOWE5O1xyXG59XHJcblxyXG4vLyBmYXEgbGlzdCBjc3Mgc3RhcnQgaGVyZSBcclxuXHJcbi5mYXEtbGlzdCB7XHJcbiAgICBtYXJnaW46IDAlIDAlIDMlIDAlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm9yZGVyLXRvcDogM3B4IHNvbGlkIHZhcigtLW1haW4tYmctY29sb3IpO1xyXG59XHJcblxyXG4uZmFxLWxpc3QtZGF0YSB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZjRmNWY4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgIG1hcmdpbi10b3A6IC0xcHg7XHJcbn1cclxuXHJcbi5saXN0LWRhdGUge1xyXG4gICAgZm9udC1zaXplOiAwLjdyZW07XHJcbiAgICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxufVxyXG4uYWRkLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxLjNyZW07XHJcbiAgICBjb2xvcjogI2ZmZmZmZjtcclxuICAgIG1hcmdpbi1yaWdodDogMSU7XHJcbn1cclxuLmxpc3QtbGJsIHtcclxuICAgIGZvbnQtc2l6ZTogMS4xcmVtO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbiAgICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZGV0YWlsLWxibCB7XHJcbiAgICBmb250LXNpemU6IDAuN3JlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG4gICAgY29sb3I6ICMzNDNmNWU7XHJcbn1cclxuXHJcbnRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICM1OGI5MDA7XHJcbn1cclxuXHJcbnRhYmxlIHRyIHRkIHtcclxuICAgIHBhZGRpbmc6IDMlIDIlIDMlIDIlO1xyXG4gICAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjOTE5NDljO1xyXG4gICAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XHJcbn1cclxuXHJcbi50YmwtbGJsIHtcclxuICAgIHdpZHRoOiA0MCU7XHJcbn1cclxuXHJcbi50YmwtdmFsIHtcclxuICAgIHdpZHRoOiA2MCU7XHJcbn1cclxuXHJcbmlvbi1hY2NvcmRpb24ge1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbn1cclxuXHJcblxyXG4uZml4LXNlYXJjaGJhciB7XHJcbiAgICAvLyBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIC8vIHotaW5kZXg6IDk7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1ib2R5LWJnKTtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMjQyNDI0MmY7XHJcbn1cclxuXHJcbi5zYy1pb24tc2VhcmNoYmFyLW1kLWgge1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5yZW1vdmUtaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuOXJlbTtcclxuICAgIGNvbG9yOiByZWQ7XHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG5mb3JtIGlvbi1pdGVtIHtcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc3ViQWN0aXZpdHkge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2UxZTFlMTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxufVxyXG5cclxuLnN1Yl9hY3Rpdml0eSB7XHJcbiAgICBtYXJnaW4tbGVmdDogMTIlO1xyXG4gICAgcGFkZGluZzogMDtcclxufVxyXG5cclxuLnN1Yl9hY3Rpdml0eSBsaSB7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbn1cclxuLmNhbGFuZGVyLWljb24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDclO1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgbWFyZ2luLXRvcDogMjAlO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4uY2FsYW5kZXItaW5wdXQge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHJnYig4NywgODYsIDg2KTtcclxuICAgIC0tcGFkZGluZy1ib3R0b206IDJweDtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkOyAgICB3aWR0aDogOTQlO1xyXG59XHJcbiBcclxuLmVycm9yMntcclxuICAgIGNvbG9yOiByZWQ7XHJcbiAgICBmb250LXNpemU6IDlweDtcclxuICAgIG1hcmdpbjogMCUgMCUgMCUgMCU7XHJcbn1cclxuXHJcbiIsIi5maWx0ZXItaWNvbiB7XG4gIGZvbnQtc2l6ZTogMS4zcmVtO1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5mbHRyLWJ0biB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgY29sb3I6IHZhcigtLW1haW4tYmctY29sb3IpO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uZmlsdGVyLWNsb3NlLWljb24ge1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMS41cmVtO1xuICBjb2xvcjogI2E5YTlhOTtcbn1cblxuLmZhcS1saXN0IHtcbiAgbWFyZ2luOiAwJSAwJSAzJSAwJTtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBib3JkZXItdG9wOiAzcHggc29saWQgdmFyKC0tbWFpbi1iZy1jb2xvcik7XG59XG5cbi5mYXEtbGlzdC1kYXRhIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2Y0ZjVmODtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNXB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNXB4O1xuICBtYXJnaW4tdG9wOiAtMXB4O1xufVxuXG4ubGlzdC1kYXRlIHtcbiAgZm9udC1zaXplOiAwLjdyZW07XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG59XG5cbi5hZGQtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMS4zcmVtO1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgbWFyZ2luLXJpZ2h0OiAxJTtcbn1cblxuLmxpc3QtbGJsIHtcbiAgZm9udC1zaXplOiAxLjFyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpICFpbXBvcnRhbnQ7XG59XG5cbi5kZXRhaWwtbGJsIHtcbiAgZm9udC1zaXplOiAwLjdyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIGNvbG9yOiAjMzQzZjVlO1xufVxuXG50YWJsZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgIzU4YjkwMDtcbn1cblxudGFibGUgdHIgdGQge1xuICBwYWRkaW5nOiAzJSAyJSAzJSAyJTtcbiAgZm9udC1zaXplOiAwLjhyZW07XG4gIGJvcmRlcjogMXB4IHNvbGlkICM5MTk0OWM7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xufVxuXG4udGJsLWxibCB7XG4gIHdpZHRoOiA0MCU7XG59XG5cbi50YmwtdmFsIHtcbiAgd2lkdGg6IDYwJTtcbn1cblxuaW9uLWFjY29yZGlvbiB7XG4gIG1hcmdpbjogMCBhdXRvO1xufVxuXG4uZml4LXNlYXJjaGJhciB7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1ib2R5LWJnKTtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHJnYmEoMzYsIDM2LCAzNiwgMC4xODQzMTM3MjU1KTtcbn1cblxuLnNjLWlvbi1zZWFyY2hiYXItbWQtaCB7XG4gIC0tYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xufVxuXG4ucmVtb3ZlLWljb24ge1xuICBmb250LXNpemU6IDEuOXJlbTtcbiAgY29sb3I6IHJlZDtcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbmZvcm0gaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLXdoaXRlLWNscikgIWltcG9ydGFudDtcbn1cblxuLnN1YkFjdGl2aXR5IHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2UxZTFlMTtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuXG4uc3ViX2FjdGl2aXR5IHtcbiAgbWFyZ2luLWxlZnQ6IDEyJTtcbiAgcGFkZGluZzogMDtcbn1cblxuLnN1Yl9hY3Rpdml0eSBsaSB7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLmNhbGFuZGVyLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiA3JTtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAyMCU7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmNhbGFuZGVyLWlucHV0IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiKDg3LCA4NiwgODYpO1xuICAtLXBhZGRpbmctYm90dG9tOiAycHg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHdpZHRoOiA5NCU7XG59XG5cbi5lcnJvcjIge1xuICBjb2xvcjogcmVkO1xuICBmb250LXNpemU6IDlweDtcbiAgbWFyZ2luOiAwJSAwJSAwJSAwJTtcbn0iXX0= */";

/***/ }),

/***/ 6383:
/*!*********************************************************************************!*\
  !*** ./src/app/services/components/dropdown/dropdown.component.scss?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkcm9wZG93bi5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 6635:
/*!******************************************************************************!*\
  !*** ./src/app/services/custom-popup/custom-popup.component.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".popup-wrapper {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 100%;\n  height: 100%;\n  background-color: rgba(0, 0, 0, 0.3);\n  z-index: 15;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.waite {\n  margin-top: 0.5rem;\n  font-size: 15px;\n}\n\n.popup-content-wrapper {\n  background-color: #fff;\n  box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;\n  padding: 1rem;\n  border-radius: 0.5rem;\n  width: 100%;\n  height: 100%;\n  max-width: 460px;\n  max-height: 400px;\n}\n\nmat-spinner {\n  zoom: 0.7;\n  margin: 1rem;\n}\n\n.app-update-wrapper {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  text-align: center;\n}\n\n.app-update-image-container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n  text-align: center;\n  padding: 1rem;\n}\n\n.app-update-image-container img {\n  width: 180px;\n}\n\n.success-image-container img {\n  width: 100px;\n}\n\n.app-update-title {\n  color: var(--gray-dark);\n}\n\n.app-update-button {\n  background-color: var(--main-color);\n  outline: none;\n  border: none;\n  padding: 1rem;\n  color: white;\n  margin: 0.5rem auto;\n  cursor: pointer;\n  opacity: 0.9;\n}\n\n.app-update-button:hover {\n  opacity: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbS1wb3B1cC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGlvbmljJTIwUHJvXFxmZyUyMGJhbmNhJTIwY29ubmVjdFxcc3JjXFxhcHBcXHNlcnZpY2VzXFxjdXN0b20tcG9wdXBcXGN1c3RvbS1wb3B1cC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQ0FBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSxzQkFBQTtFQUNBLDRDQUFBO0VBQ0EsYUFBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FERUE7RUFDRSxTQUFBO0VBQ0EsWUFBQTtBQ0NGOztBREVBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUNDRjs7QURFQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUNDRjs7QURBRTtFQUNFLFlBQUE7QUNFSjs7QURFRTtFQUNFLFlBQUE7QUNDSjs7QURHQTtFQUNFLHVCQUFBO0FDQUY7O0FER0E7RUFDRSxtQ0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDQUY7O0FER0E7RUFDRSxVQUFBO0FDQUYiLCJmaWxlIjoiY3VzdG9tLXBvcHVwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnBvcHVwLXdyYXBwZXIge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICByaWdodDogMDtcclxuICBib3R0b206IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICB6LWluZGV4OiAxNTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi53YWl0ZSB7XHJcbiAgbWFyZ2luLXRvcDogMC41cmVtO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG5cclxuLnBvcHVwLWNvbnRlbnQtd3JhcHBlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICBib3gtc2hhZG93OiByZ2JhKDAsIDAsIDAsIDAuMzUpIDBweCA1cHggMTVweDtcclxuICBwYWRkaW5nOiAxcmVtO1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuNXJlbTtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgbWF4LXdpZHRoOiA0NjBweDtcclxuICBtYXgtaGVpZ2h0OiA0MDBweDtcclxufVxyXG5cclxubWF0LXNwaW5uZXIge1xyXG4gIHpvb206IDAuNztcclxuICBtYXJnaW46IDFyZW07XHJcbn1cclxuXHJcbi5hcHAtdXBkYXRlLXdyYXBwZXIge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmFwcC11cGRhdGUtaW1hZ2UtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgcGFkZGluZzogMXJlbTtcclxuICBpbWcge1xyXG4gICAgd2lkdGg6IDE4MHB4O1xyXG4gIH1cclxufVxyXG4uc3VjY2Vzcy1pbWFnZS1jb250YWluZXIge1xyXG4gIGltZyB7XHJcbiAgICB3aWR0aDogMTAwcHg7XHJcbiAgfVxyXG59XHJcblxyXG4uYXBwLXVwZGF0ZS10aXRsZSB7XHJcbiAgY29sb3I6IHZhcigtLWdyYXktZGFyayk7XHJcbn1cclxuXHJcbi5hcHAtdXBkYXRlLWJ1dHRvbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbWFpbi1jb2xvcik7XHJcbiAgb3V0bGluZTogbm9uZTtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgcGFkZGluZzogMXJlbTtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgbWFyZ2luOiAwLjVyZW0gYXV0bztcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgb3BhY2l0eTogMC45O1xyXG59XHJcblxyXG4uYXBwLXVwZGF0ZS1idXR0b246aG92ZXIge1xyXG4gIG9wYWNpdHk6IDE7XHJcbn1cclxuIiwiLnBvcHVwLXdyYXBwZXIge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIGJvdHRvbTogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjMpO1xuICB6LWluZGV4OiAxNTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi53YWl0ZSB7XG4gIG1hcmdpbi10b3A6IDAuNXJlbTtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuXG4ucG9wdXAtY29udGVudC13cmFwcGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjM1KSAwcHggNXB4IDE1cHg7XG4gIHBhZGRpbmc6IDFyZW07XG4gIGJvcmRlci1yYWRpdXM6IDAuNXJlbTtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgbWF4LXdpZHRoOiA0NjBweDtcbiAgbWF4LWhlaWdodDogNDAwcHg7XG59XG5cbm1hdC1zcGlubmVyIHtcbiAgem9vbTogMC43O1xuICBtYXJnaW46IDFyZW07XG59XG5cbi5hcHAtdXBkYXRlLXdyYXBwZXIge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uYXBwLXVwZGF0ZS1pbWFnZS1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiAxcmVtO1xufVxuLmFwcC11cGRhdGUtaW1hZ2UtY29udGFpbmVyIGltZyB7XG4gIHdpZHRoOiAxODBweDtcbn1cblxuLnN1Y2Nlc3MtaW1hZ2UtY29udGFpbmVyIGltZyB7XG4gIHdpZHRoOiAxMDBweDtcbn1cblxuLmFwcC11cGRhdGUtdGl0bGUge1xuICBjb2xvcjogdmFyKC0tZ3JheS1kYXJrKTtcbn1cblxuLmFwcC11cGRhdGUtYnV0dG9uIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbWFpbi1jb2xvcik7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGJvcmRlcjogbm9uZTtcbiAgcGFkZGluZzogMXJlbTtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW46IDAuNXJlbSBhdXRvO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIG9wYWNpdHk6IDAuOTtcbn1cblxuLmFwcC11cGRhdGUtYnV0dG9uOmhvdmVyIHtcbiAgb3BhY2l0eTogMTtcbn0iXX0= */";

/***/ }),

/***/ 8698:
/*!*************************************************************!*\
  !*** ./src/app/teamdemo/teamdemo.component.scss?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".card {\n  border-left: 3px solid red;\n}\n\n.next_arrow {\n  margin-top: 15%;\n  font-size: 20px;\n}\n\n.total_count {\n  float: right;\n  background: red;\n}\n\n.filter-icon {\n  font-size: 1.3rem;\n  color: var(--white-clr);\n  padding-right: 12px;\n}\n\n.fltr-btn {\n  padding: 6px;\n  --border-radius: 3px;\n}\n\nion-item {\n  --background:var(--white-clr) ;\n}\n\nion-select {\n  color: var(--black-clr) !important;\n}\n\n.faq-list {\n  margin: 0% 0% 3% 0%;\n  border-radius: 5px;\n  border-top: 3px solid red;\n}\n\n.faq-list-data {\n  border: 1px solid #f4f5f8;\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px;\n  margin-top: -1px;\n}\n\ntable {\n  width: 100%;\n  border-bottom: 3px solid #58b900;\n}\n\ntable tr td {\n  padding: 4% 0% 4% 0%;\n  font-size: 0.8rem;\n  border: 1px solid #f4f5f8;\n  color: var(--black-clr);\n  text-align: center;\n}\n\ntable tr th {\n  padding: 4% 0% 4% 0%;\n  font-size: 0.8rem;\n  text-align: center;\n  color: var(--black-clr);\n}\n\n.tbl-lbl {\n  width: 40%;\n}\n\n.tbl-val {\n  width: 60%;\n}\n\nion-searchbar, ion-textarea {\n  color: var(--black-clr);\n}\n\n.list-lbl {\n  font-size: 1.1rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: var(--white-clr);\n}\n\n.empty-img {\n  width: 55%;\n  margin-top: 50%;\n}\n\nion-card ion-item ion-label {\n  font-size: 16px;\n  font-weight: bold;\n  color: var(--white-clr) !important;\n}\n\n.backButton {\n  margin-left: 14px;\n  color: white;\n  font-size: 1.4rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlYW1kZW1vLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxpb25pYyUyMFByb1xcZmclMjBiYW5jYSUyMGNvbm5lY3RcXHNyY1xcYXBwXFx0ZWFtZGVtb1xcdGVhbWRlbW8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7RUFDQSxvQkFBQTtBQ0VKOztBREFBO0VBQVMsOEJBQUE7QUNJVDs7QURGQTtFQUFXLGtDQUFBO0FDTVg7O0FERkE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUNLSjs7QURGQTtFQUNJLHlCQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtFQUNBLGdCQUFBO0FDS0o7O0FEREE7RUFDSSxXQUFBO0VBQ0EsZ0NBQUE7QUNJSjs7QURFQTtFQUNJLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURDQTtFQUNJLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FDRUo7O0FEQ0E7RUFDSSxVQUFBO0FDRUo7O0FEQ0E7RUFDSSxVQUFBO0FDRUo7O0FEQUE7RUFBMkIsdUJBQUE7QUNJM0I7O0FEREE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ0lKOztBREFBO0VBQ0ksVUFBQTtFQUNBLGVBQUE7QUNHSjs7QURBQTtFQUE0QixlQUFBO0VBQ3hCLGlCQUFBO0VBQ0Esa0NBQUE7QUNJSjs7QURGQTtFQUFnQixpQkFBQTtFQUNaLFlBQUE7RUFDQSxpQkFBQTtBQ01KIiwiZmlsZSI6InRlYW1kZW1vLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmQge1xyXG4gICAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCByZWQ7XHJcbn1cclxuXHJcbi5uZXh0X2Fycm93IHtcclxuICAgIG1hcmdpbi10b3A6IDE1JTtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG5cclxuLnRvdGFsX2NvdW50IHtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIGJhY2tncm91bmQ6IHJlZDtcclxufVxyXG5cclxuLmZpbHRlci1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMS4zcmVtO1xyXG4gICAgY29sb3I6IHZhcigtLXdoaXRlLWNscik7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xyXG59XHJcbi5mbHRyLWJ0biB7XHJcbiAgICBwYWRkaW5nOiA2cHg7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDNweDtcclxufVxyXG5pb24taXRlbXstLWJhY2tncm91bmQ6dmFyKC0td2hpdGUtY2xyKSB9XHJcbi8vIGlvbi1sYWJlbHtjb2xvcjogdmFyKC0tYmxhY2stY2xyKSAhaW1wb3J0YW50O31cclxuaW9uLXNlbGVjdHtjb2xvcjogdmFyKC0tYmxhY2stY2xyKSAhaW1wb3J0YW50O31cclxuXHJcblxyXG5cclxuLmZhcS1saXN0IHtcclxuICAgIG1hcmdpbjogMCUgMCUgMyUgMCU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBib3JkZXItdG9wOiAzcHggc29saWQgcmVkO1xyXG59XHJcblxyXG4uZmFxLWxpc3QtZGF0YSB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZjRmNWY4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgIG1hcmdpbi10b3A6IC0xcHg7XHJcbn1cclxuXHJcblxyXG50YWJsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1ib3R0b206IDNweCBzb2xpZCAjNThiOTAwO1xyXG59XHJcbi8vIC5saXN0LWxibCB7XHJcbi8vICAgICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKSA7XHJcbi8vIH1cclxuXHJcbnRhYmxlIHRyIHRkIHtcclxuICAgIHBhZGRpbmc6IDQlIDAlIDQlIDAlO1xyXG4gICAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZjRmNWY4O1xyXG4gICAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxudGFibGUgdHIgdGgge1xyXG4gICAgcGFkZGluZzogNCUgMCUgNCUgMCU7XHJcbiAgICBmb250LXNpemU6IDAuOHJlbTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xyXG59XHJcblxyXG4udGJsLWxibCB7XHJcbiAgICB3aWR0aDogNDAlO1xyXG59XHJcblxyXG4udGJsLXZhbCB7XHJcbiAgICB3aWR0aDogNjAlO1xyXG59XHJcbmlvbi1zZWFyY2hiYXIsaW9uLXRleHRhcmVhe2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpO31cclxuXHJcblxyXG4ubGlzdC1sYmwge1xyXG4gICAgZm9udC1zaXplOiAxLjFyZW07XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgIGNvbG9yOnZhcigtLXdoaXRlLWNscik7XHJcbn1cclxuXHJcblxyXG4uZW1wdHktaW1nIHtcclxuICAgIHdpZHRoOiA1NSU7XHJcbiAgICBtYXJnaW4tdG9wOjUwJTtcclxufVxyXG5cclxuaW9uLWNhcmQgaW9uLWl0ZW0gaW9uLWxhYmVse2ZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6dmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xyXG59XHJcbi5iYWNrQnV0dG9ueyAgICBtYXJnaW4tbGVmdDogMTRweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMS40cmVtO30iLCIuY2FyZCB7XG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgcmVkO1xufVxuXG4ubmV4dF9hcnJvdyB7XG4gIG1hcmdpbi10b3A6IDE1JTtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4udG90YWxfY291bnQge1xuICBmbG9hdDogcmlnaHQ7XG4gIGJhY2tncm91bmQ6IHJlZDtcbn1cblxuLmZpbHRlci1pY29uIHtcbiAgZm9udC1zaXplOiAxLjNyZW07XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xufVxuXG4uZmx0ci1idG4ge1xuICBwYWRkaW5nOiA2cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogM3B4O1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDp2YXIoLS13aGl0ZS1jbHIpIDtcbn1cblxuaW9uLXNlbGVjdCB7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7XG59XG5cbi5mYXEtbGlzdCB7XG4gIG1hcmdpbjogMCUgMCUgMyUgMCU7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLXRvcDogM3B4IHNvbGlkIHJlZDtcbn1cblxuLmZhcS1saXN0LWRhdGEge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZjRmNWY4O1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XG4gIG1hcmdpbi10b3A6IC0xcHg7XG59XG5cbnRhYmxlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1ib3R0b206IDNweCBzb2xpZCAjNThiOTAwO1xufVxuXG50YWJsZSB0ciB0ZCB7XG4gIHBhZGRpbmc6IDQlIDAlIDQlIDAlO1xuICBmb250LXNpemU6IDAuOHJlbTtcbiAgYm9yZGVyOiAxcHggc29saWQgI2Y0ZjVmODtcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxudGFibGUgdHIgdGgge1xuICBwYWRkaW5nOiA0JSAwJSA0JSAwJTtcbiAgZm9udC1zaXplOiAwLjhyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG59XG5cbi50YmwtbGJsIHtcbiAgd2lkdGg6IDQwJTtcbn1cblxuLnRibC12YWwge1xuICB3aWR0aDogNjAlO1xufVxuXG5pb24tc2VhcmNoYmFyLCBpb24tdGV4dGFyZWEge1xuICBjb2xvcjogdmFyKC0tYmxhY2stY2xyKTtcbn1cblxuLmxpc3QtbGJsIHtcbiAgZm9udC1zaXplOiAxLjFyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xufVxuXG4uZW1wdHktaW1nIHtcbiAgd2lkdGg6IDU1JTtcbiAgbWFyZ2luLXRvcDogNTAlO1xufVxuXG5pb24tY2FyZCBpb24taXRlbSBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xufVxuXG4uYmFja0J1dHRvbiB7XG4gIG1hcmdpbi1sZWZ0OiAxNHB4O1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMS40cmVtO1xufSJdfQ== */";

/***/ }),

/***/ 818:
/*!*************************************************************************!*\
  !*** ./src/app/teams-activity/teams-activity.component.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".card {\n  border-left: 3px solid red;\n}\n\n.next_arrow {\n  margin-top: 15%;\n  font-size: 20px;\n}\n\n.total_count {\n  float: right;\n  background: red;\n}\n\n.filter-icon {\n  font-size: 1.3rem;\n  color: var(--white-clr);\n  padding-right: 12px;\n}\n\n.fltr-btn {\n  padding: 6px;\n  --border-radius: 3px;\n}\n\nion-item {\n  --background:var(--white-clr) ;\n}\n\nion-select {\n  color: var(--black-clr) !important;\n}\n\n.faq-list {\n  margin: 0% 0% 3% 0%;\n  border-radius: 5px;\n  border-top: 3px solid red;\n}\n\n.faq-list-data {\n  border: 1px solid #f4f5f8;\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px;\n  margin-top: -1px;\n}\n\ntable {\n  width: 100%;\n}\n\ntable tr td {\n  padding: 4% 0% 4% 0%;\n  font-size: 0.8rem;\n  border: 1px solid #f4f5f8;\n  color: var(--black-clr);\n  text-align: center;\n}\n\ntable tr th {\n  padding: 4% 0% 4% 0%;\n  font-size: 0.8rem;\n  text-align: center;\n  color: var(--black-clr);\n}\n\n.tbl-lbl {\n  width: 40%;\n}\n\n.tbl-val {\n  width: 60%;\n}\n\nion-searchbar, ion-textarea {\n  color: var(--black-clr);\n}\n\n.list-lbl {\n  font-size: 1.1rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: var(--white-clr);\n}\n\n.empty-img {\n  width: 55%;\n  margin-top: 50%;\n}\n\nion-card ion-item ion-label {\n  font-size: 16px;\n  font-weight: bold;\n  color: var(--black-clr);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlYW1zLWFjdGl2aXR5LmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxpb25pYyUyMFByb1xcZmclMjBiYW5jYSUyMGNvbm5lY3RcXHNyY1xcYXBwXFx0ZWFtcy1hY3Rpdml0eVxcdGVhbXMtYWN0aXZpdHkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7RUFDQSxvQkFBQTtBQ0VKOztBREFBO0VBQVMsOEJBQUE7QUNJVDs7QURGQTtFQUFXLGtDQUFBO0FDTVg7O0FERkE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7QUNLSjs7QURGQTtFQUNJLHlCQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtFQUNBLGdCQUFBO0FDS0o7O0FEREE7RUFDSSxXQUFBO0FDSUo7O0FERUE7RUFDSSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtBQ0VKOztBRENBO0VBQ0ksVUFBQTtBQ0VKOztBRENBO0VBQ0ksVUFBQTtBQ0VKOztBREFBO0VBQTJCLHVCQUFBO0FDSTNCOztBRERBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUNJSjs7QURBQTtFQUNJLFVBQUE7RUFDQSxlQUFBO0FDR0o7O0FEQUE7RUFBNEIsZUFBQTtFQUN4QixpQkFBQTtFQUNBLHVCQUFBO0FDSUoiLCJmaWxlIjoidGVhbXMtYWN0aXZpdHkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZCB7XHJcbiAgICBib3JkZXItbGVmdDogM3B4IHNvbGlkIHJlZDtcclxufVxyXG5cclxuLm5leHRfYXJyb3cge1xyXG4gICAgbWFyZ2luLXRvcDogMTUlO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcblxyXG4udG90YWxfY291bnQge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgYmFja2dyb3VuZDogcmVkO1xyXG59XHJcblxyXG4uZmlsdGVyLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxLjNyZW07XHJcbiAgICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKTtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDEycHg7XHJcbn1cclxuLmZsdHItYnRuIHtcclxuICAgIHBhZGRpbmc6IDZweDtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogM3B4O1xyXG59XHJcbmlvbi1pdGVtey0tYmFja2dyb3VuZDp2YXIoLS13aGl0ZS1jbHIpIH1cclxuLy8gaW9uLWxhYmVse2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7fVxyXG5pb24tc2VsZWN0e2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7fVxyXG5cclxuXHJcblxyXG4uZmFxLWxpc3Qge1xyXG4gICAgbWFyZ2luOiAwJSAwJSAzJSAwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIGJvcmRlci10b3A6IDNweCBzb2xpZCByZWQ7XHJcbn1cclxuXHJcbi5mYXEtbGlzdC1kYXRhIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNmNGY1Zjg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogLTFweDtcclxufVxyXG5cclxuXHJcbnRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcbi8vIC5saXN0LWxibCB7XHJcbi8vICAgICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKSA7XHJcbi8vIH1cclxuXHJcbnRhYmxlIHRyIHRkIHtcclxuICAgIHBhZGRpbmc6IDQlIDAlIDQlIDAlO1xyXG4gICAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZjRmNWY4O1xyXG4gICAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxudGFibGUgdHIgdGgge1xyXG4gICAgcGFkZGluZzogNCUgMCUgNCUgMCU7XHJcbiAgICBmb250LXNpemU6IDAuOHJlbTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xyXG59XHJcblxyXG4udGJsLWxibCB7XHJcbiAgICB3aWR0aDogNDAlO1xyXG59XHJcblxyXG4udGJsLXZhbCB7XHJcbiAgICB3aWR0aDogNjAlO1xyXG59XHJcbmlvbi1zZWFyY2hiYXIsaW9uLXRleHRhcmVhe2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpO31cclxuXHJcblxyXG4ubGlzdC1sYmwge1xyXG4gICAgZm9udC1zaXplOiAxLjFyZW07XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgIGNvbG9yOnZhcigtLXdoaXRlLWNscikgO1xyXG59XHJcblxyXG5cclxuLmVtcHR5LWltZyB7XHJcbiAgICB3aWR0aDogNTUlO1xyXG4gICAgbWFyZ2luLXRvcDo1MCU7XHJcbn1cclxuXHJcbmlvbi1jYXJkIGlvbi1pdGVtIGlvbi1sYWJlbHtmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpfSIsIi5jYXJkIHtcbiAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCByZWQ7XG59XG5cbi5uZXh0X2Fycm93IHtcbiAgbWFyZ2luLXRvcDogMTUlO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi50b3RhbF9jb3VudCB7XG4gIGZsb2F0OiByaWdodDtcbiAgYmFja2dyb3VuZDogcmVkO1xufVxuXG4uZmlsdGVyLWljb24ge1xuICBmb250LXNpemU6IDEuM3JlbTtcbiAgY29sb3I6IHZhcigtLXdoaXRlLWNscik7XG4gIHBhZGRpbmctcmlnaHQ6IDEycHg7XG59XG5cbi5mbHRyLWJ0biB7XG4gIHBhZGRpbmc6IDZweDtcbiAgLS1ib3JkZXItcmFkaXVzOiAzcHg7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOnZhcigtLXdoaXRlLWNscikgO1xufVxuXG5pb24tc2VsZWN0IHtcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscikgIWltcG9ydGFudDtcbn1cblxuLmZhcS1saXN0IHtcbiAgbWFyZ2luOiAwJSAwJSAzJSAwJTtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBib3JkZXItdG9wOiAzcHggc29saWQgcmVkO1xufVxuXG4uZmFxLWxpc3QtZGF0YSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmNGY1Zjg7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcbiAgbWFyZ2luLXRvcDogLTFweDtcbn1cblxudGFibGUge1xuICB3aWR0aDogMTAwJTtcbn1cblxudGFibGUgdHIgdGQge1xuICBwYWRkaW5nOiA0JSAwJSA0JSAwJTtcbiAgZm9udC1zaXplOiAwLjhyZW07XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmNGY1Zjg7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbnRhYmxlIHRyIHRoIHtcbiAgcGFkZGluZzogNCUgMCUgNCUgMCU7XG4gIGZvbnQtc2l6ZTogMC44cmVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xufVxuXG4udGJsLWxibCB7XG4gIHdpZHRoOiA0MCU7XG59XG5cbi50YmwtdmFsIHtcbiAgd2lkdGg6IDYwJTtcbn1cblxuaW9uLXNlYXJjaGJhciwgaW9uLXRleHRhcmVhIHtcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG59XG5cbi5saXN0LWxibCB7XG4gIGZvbnQtc2l6ZTogMS4xcmVtO1xuICBmb250LXdlaWdodDogNjAwO1xuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xuICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKTtcbn1cblxuLmVtcHR5LWltZyB7XG4gIHdpZHRoOiA1NSU7XG4gIG1hcmdpbi10b3A6IDUwJTtcbn1cblxuaW9uLWNhcmQgaW9uLWl0ZW0gaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG59Il19 */";

/***/ }),

/***/ 3111:
/*!***************************************************************************!*\
  !*** ./src/app/teams-dashboard/teams-dashboard.component.scss?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".card {\n  border-left: 3px solid red;\n}\n\n.next_arrow {\n  margin-top: 15%;\n  font-size: 20px;\n}\n\n.total_count {\n  float: right;\n  background: red;\n}\n\n.filter-icon {\n  font-size: 1.3rem;\n  color: var(--white-clr);\n  padding-right: 12px;\n}\n\n.fltr-btn {\n  padding: 6px;\n  --border-radius: 3px;\n}\n\nion-item {\n  --background:var(--white-clr) ;\n}\n\nion-select {\n  color: var(--black-clr) !important;\n}\n\n.faq-list {\n  margin: 0% 0% 3% 0%;\n  border-radius: 5px;\n  border-top: 3px solid var(--main-bg-color);\n}\n\n.faq-list-data {\n  border: 1px solid #f4f5f8;\n  border-bottom-left-radius: 5px;\n  border-bottom-right-radius: 5px;\n  margin-top: -1px;\n}\n\ntable {\n  width: 100%;\n  border-bottom: 3px solid #58b900;\n  background: var(--white-clr);\n}\n\ntable thead {\n  background: var(--main-bg-color);\n}\n\ntable tr, td {\n  padding: 4% 0% 4% 0%;\n  font-size: 0.8rem;\n  border: 1px solid #91949c;\n  color: var(--black-clr);\n  text-align: center;\n}\n\ntable tr th {\n  padding: 6% 1% 6% 1%;\n  font-size: 0.9rem;\n  text-align: center;\n  border: 1px solid #91949c;\n}\n\ntable .th-label {\n  color: var(--white-clr) !important;\n}\n\n.tbl-lbl {\n  width: 50%;\n}\n\n.tbl-val {\n  width: 60%;\n}\n\nion-searchbar, ion-textarea {\n  color: var(--black-clr);\n}\n\n.list-lbl {\n  font-size: 1rem;\n  font-weight: 600;\n  padding-bottom: 5px;\n  color: var(--white-clr) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlYW1zLWRhc2hib2FyZC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcaW9uaWMlMjBQcm9cXGZnJTIwYmFuY2ElMjBjb25uZWN0XFxzcmNcXGFwcFxcdGVhbXMtZGFzaGJvYXJkXFx0ZWFtcy1kYXNoYm9hcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7RUFDQSxvQkFBQTtBQ0VKOztBREFBO0VBQVMsOEJBQUE7QUNJVDs7QURGQTtFQUFXLGtDQUFBO0FDTVg7O0FERkE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7QUNLSjs7QURGQTtFQUNJLHlCQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtFQUNBLGdCQUFBO0FDS0o7O0FEREE7RUFDSSxXQUFBO0VBQ0EsZ0NBQUE7RUFDQSw0QkFBQTtBQ0lKOztBREZBO0VBQ0ksZ0NBQUE7QUNLSjs7QURGQTtFQUNJLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUNLSjs7QURIQTtFQUNJLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FDTUo7O0FESkE7RUFDSSxrQ0FBQTtBQ09KOztBREpBO0VBQ0ksVUFBQTtBQ09KOztBREpBO0VBQ0ksVUFBQTtBQ09KOztBRExBO0VBQTJCLHVCQUFBO0FDUzNCOztBRE5BO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQ0FBQTtBQ1NKIiwiZmlsZSI6InRlYW1zLWRhc2hib2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJkIHtcclxuICAgIGJvcmRlci1sZWZ0OiAzcHggc29saWQgcmVkO1xyXG59XHJcblxyXG4ubmV4dF9hcnJvdyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxNSU7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuXHJcbi50b3RhbF9jb3VudCB7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBiYWNrZ3JvdW5kOiByZWQ7XHJcbn1cclxuXHJcbi5maWx0ZXItaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuM3JlbTtcclxuICAgIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xyXG4gICAgcGFkZGluZy1yaWdodDogMTJweDtcclxufVxyXG4uZmx0ci1idG4ge1xyXG4gICAgcGFkZGluZzogNnB4O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAzcHg7XHJcbn1cclxuaW9uLWl0ZW17LS1iYWNrZ3JvdW5kOnZhcigtLXdoaXRlLWNscikgfVxyXG4vLyBpb24tbGFiZWx7Y29sb3I6IHZhcigtLWJsYWNrLWNscikgIWltcG9ydGFudDt9XHJcbmlvbi1zZWxlY3R7Y29sb3I6IHZhcigtLWJsYWNrLWNscikgIWltcG9ydGFudDt9XHJcblxyXG5cclxuXHJcbi5mYXEtbGlzdCB7XHJcbiAgICBtYXJnaW46IDAlIDAlIDMlIDAlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYm9yZGVyLXRvcDogM3B4IHNvbGlkIHZhcigtLW1haW4tYmctY29sb3IpO1xyXG59XHJcblxyXG4uZmFxLWxpc3QtZGF0YSB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZjRmNWY4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgIG1hcmdpbi10b3A6IC0xcHg7XHJcbn1cclxuXHJcblxyXG50YWJsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1ib3R0b206IDNweCBzb2xpZCAjNThiOTAwO1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0td2hpdGUtY2xyKTtcclxufVxyXG50YWJsZSB0aGVhZHtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLW1haW4tYmctY29sb3IpO1xyXG59XHJcblxyXG50YWJsZSB0ciwgdGQge1xyXG4gICAgcGFkZGluZzogNCUgMCUgNCUgMCU7XHJcbiAgICBmb250LXNpemU6IDAuOHJlbTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM5MTk0OWM7XHJcbiAgICBjb2xvcjogdmFyKC0tYmxhY2stY2xyKTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG50YWJsZSB0ciB0aCB7XHJcbiAgICBwYWRkaW5nOiA2JSAxJSA2JSAxJTtcclxuICAgIGZvbnQtc2l6ZTogMC45cmVtO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzkxOTQ5YztcclxufVxyXG50YWJsZSAudGgtbGFiZWx7XHJcbiAgICBjb2xvcjogdmFyKC0td2hpdGUtY2xyKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGJsLWxibCB7XHJcbiAgICB3aWR0aDogNTAlO1xyXG59XHJcblxyXG4udGJsLXZhbCB7XHJcbiAgICB3aWR0aDogNjAlO1xyXG59XHJcbmlvbi1zZWFyY2hiYXIsaW9uLXRleHRhcmVhe2NvbG9yOiB2YXIoLS1ibGFjay1jbHIpO31cclxuXHJcblxyXG4ubGlzdC1sYmwge1xyXG4gICAgZm9udC1zaXplOiAxLjByZW07XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgIGNvbG9yOnZhcigtLXdoaXRlLWNscikgIWltcG9ydGFudCA7XHJcbn1cclxuIFxyXG5cclxuXHJcbiAiLCIuY2FyZCB7XG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgcmVkO1xufVxuXG4ubmV4dF9hcnJvdyB7XG4gIG1hcmdpbi10b3A6IDE1JTtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4udG90YWxfY291bnQge1xuICBmbG9hdDogcmlnaHQ7XG4gIGJhY2tncm91bmQ6IHJlZDtcbn1cblxuLmZpbHRlci1pY29uIHtcbiAgZm9udC1zaXplOiAxLjNyZW07XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpO1xuICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xufVxuXG4uZmx0ci1idG4ge1xuICBwYWRkaW5nOiA2cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogM3B4O1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDp2YXIoLS13aGl0ZS1jbHIpIDtcbn1cblxuaW9uLXNlbGVjdCB7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7XG59XG5cbi5mYXEtbGlzdCB7XG4gIG1hcmdpbjogMCUgMCUgMyUgMCU7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLXRvcDogM3B4IHNvbGlkIHZhcigtLW1haW4tYmctY29sb3IpO1xufVxuXG4uZmFxLWxpc3QtZGF0YSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmNGY1Zjg7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcbiAgbWFyZ2luLXRvcDogLTFweDtcbn1cblxudGFibGUge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkICM1OGI5MDA7XG4gIGJhY2tncm91bmQ6IHZhcigtLXdoaXRlLWNscik7XG59XG5cbnRhYmxlIHRoZWFkIHtcbiAgYmFja2dyb3VuZDogdmFyKC0tbWFpbi1iZy1jb2xvcik7XG59XG5cbnRhYmxlIHRyLCB0ZCB7XG4gIHBhZGRpbmc6IDQlIDAlIDQlIDAlO1xuICBmb250LXNpemU6IDAuOHJlbTtcbiAgYm9yZGVyOiAxcHggc29saWQgIzkxOTQ5YztcbiAgY29sb3I6IHZhcigtLWJsYWNrLWNscik7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxudGFibGUgdHIgdGgge1xuICBwYWRkaW5nOiA2JSAxJSA2JSAxJTtcbiAgZm9udC1zaXplOiAwLjlyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyOiAxcHggc29saWQgIzkxOTQ5Yztcbn1cblxudGFibGUgLnRoLWxhYmVsIHtcbiAgY29sb3I6IHZhcigtLXdoaXRlLWNscikgIWltcG9ydGFudDtcbn1cblxuLnRibC1sYmwge1xuICB3aWR0aDogNTAlO1xufVxuXG4udGJsLXZhbCB7XG4gIHdpZHRoOiA2MCU7XG59XG5cbmlvbi1zZWFyY2hiYXIsIGlvbi10ZXh0YXJlYSB7XG4gIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpO1xufVxuXG4ubGlzdC1sYmwge1xuICBmb250LXNpemU6IDFyZW07XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIGNvbG9yOiB2YXIoLS13aGl0ZS1jbHIpICFpbXBvcnRhbnQ7XG59Il19 */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\r\n  <ion-split-pane contentId=\"main-content\">\r\n    <ion-menu contentId=\"main-content\" side=\"start\" class=\"menuContainer\">\r\n      <ion-content>\r\n        <!-- <ion-list class=\"menu-list\"> -->\r\n        <ion-list id=\"inbox-list\">\r\n\r\n          <ion-row>\r\n            <ion-col size=\"10\" size-md=\"12\" size-lg=\"12\">\r\n              <img class=\"fgi-logo center\" routerLink=\"/home\" src=\"./assets/New/fgi.png\" alt=\"\">\r\n            </ion-col>\r\n            <ion-col size=\"2\" size-md=\"0\" size-lg=\"0\">\r\n              <ion-icon (click)=\"close()\" class=\"sidemenu-close-btn\" [ios]=\"'close'\" [md]=\"'close'\"\r\n                style=\"font-size: 24px;color:white\">\r\n              </ion-icon>\r\n            </ion-col>\r\n          </ion-row>\r\n\r\n          <ion-list-header [ngStyle]=\"{'color':'white'}\">&nbsp;<span class=\"center\">Hi\r\n              {{userName}}</span></ion-list-header>\r\n          <ion-note [ngStyle]=\"{'color':'white'}\">&nbsp; {{userEmail}}</ion-note><br>\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let page of appPages; let i=index\" class=\"menuWrapper\">\r\n            <ion-item class=\"label\" (click)=\"goToHome(page)\" [ngClass]=\"{'active': i==0}\">\r\n              <ion-icon slot=\"start\" [ios]=\"page.icon + '-outline'\" [md]=\"page.icon + '-outline'\"\r\n                [ngStyle]=\"{'color':'white'}\"></ion-icon>\r\n              <span class=\"bold\" [ngStyle]=\"{'color':'white'}\">{{page.title}}</span>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n\r\n          <ion-menu-toggle auto-hide=\"false\" class=\"menuWrapper\">\r\n            <ion-item class=\"label\" routerLink=\"/home\">\r\n              <ion-icon slot=\"start\" name=\"home\" [ngStyle]=\"{'color':'white'}\"></ion-icon>\r\n              <span class=\"bold\" [ngStyle]=\"{'color':'white'}\">Home</span>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n\r\n          <ion-menu-toggle auto-hide=\"false\" class=\"menuWrapper\">\r\n            <ion-item *ngIf=\"userFlag > 1\" class=\"label\" routerLink=\"/dashboard\">\r\n              <ion-icon slot=\"start\" name=\"apps\" [ngStyle]=\"{'color':'white'}\"></ion-icon>\r\n              <span class=\"bold\" [ngStyle]=\"{'color':'white'}\">Dashboard</span>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n          <!-- <ion-menu-toggle auto-hide=\"false\" class=\"menuWrapper\">\r\n          <ion-item *ngIf=\"userFlag < 2\" class=\"label\" routerLink=\"/dsrActivity\">\r\n            <ion-icon slot=\"start\" name=\"add-circle\" [ngStyle]=\"{'color':'white'}\"></ion-icon>\r\n            <span class=\"bold\" [ngStyle]=\"{'color':'white'}\">DSR Activity</span>\r\n          </ion-item>\r\n        </ion-menu-toggle> -->\r\n          <ion-menu-toggle auto-hide=\"false\" class=\"menuWrapper\">\r\n            <ion-item *ngIf=\"userFlag > 1\" class=\"label\" routerLink=\"/teamsDemo:id\">\r\n              <ion-icon slot=\"start\" name=\"people\" [ngStyle]=\"{'color':'white'}\"></ion-icon>\r\n              <span class=\"bold\" [ngStyle]=\"{'color':'white'}\">Teams Activity</span>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n          <ion-menu-toggle auto-hide=\"false\" class=\"menuWrapper\">\r\n            <ion-item *ngIf=\"userFlag > 1\" class=\"label\" routerLink=\"/report\">\r\n              <ion-icon slot=\"start\" name=\"document-text\" [ngStyle]=\"{'color':'white'}\"></ion-icon>\r\n              <span class=\"bold\" [ngStyle]=\"{'color':'white'}\">Reports</span>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n          <ion-item class=\"label pointer\" (click)=\"logout()\">\r\n            <ion-icon slot=\"start\" name=\"power\" [ngStyle]=\"{'color':'white'}\"></ion-icon>\r\n            <span class=\"bold\" [ngStyle]=\"{'color':'white'}\">Logout</span>\r\n          </ion-item>\r\n        </ion-list>\r\n\r\n      </ion-content>\r\n      <ion-footer collapse=\"fade\" class=\"footer\">\r\n        <ion-toolbar style=\"border-top: 1px solid white;\">\r\n          <ion-title style=\"font-size: 12px;\">\r\n            <span class=\"version\">Version {{ appVersionNumber}}</span>\r\n          </ion-title>\r\n        </ion-toolbar>\r\n      </ion-footer>\r\n\r\n    </ion-menu>\r\n    <ion-router-outlet id=\"main-content\" main> </ion-router-outlet>\r\n  </ion-split-pane>\r\n\r\n</ion-app>\r\n\r\n \r\n\r\n<div *ngIf=\"loaderStatus===true\" class=\"loader\">\r\n  <div class=\"loader-element\">\r\n      <ion-spinner class=\"spinner\" name=\"lines\"> </ion-spinner>\r\n      <p>Please Wait...</p>\r\n      <!-- develop by manoj kumar -->\r\n  </div>\r\n</div>\r\n\r\n\r\n<ng-container *ngIf=\"newVersionAvailable\">\r\n  <div (parentFun)=\"updateClient()\" [popuptype]=\"'app-update'\"></div>\r\n</ng-container>";

/***/ }),

/***/ 5639:
/*!************************************************************!*\
  !*** ./src/app/auth/login/login.component.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<!-- <app-header [showBackButton]=\"false\" [showMenu]=\"false\"></app-header> -->\n<ion-content [scrollEvents]=\"true\">\n\n  <div class=\"progress-outer\" *ngIf=\"progressBar\"  >\n    <div class=\"progress-inner\" [style.width]=\"progress + '%'\">\n      {{ progress}}%\n    </div>\n  </div>\n  <ion-grid class=\"pad-0\">\n    <div class=\"parent\">\n      <ion-row class=\"ion-align-items-center child\">\n        <ion-col size=\"12\" size-md=\"6\" size-lg=\"6\">\n          <!-- <img class=\"logo-img center\" src=\"../../../assets/New/login1.png\" alt=\"login banner\"> -->\n          <img class=\"logo-img center\" src=\"./assets/New/login1.png\" alt=\"login banner\">\n        </ion-col>\n        <ion-col size=\"12\" size-md=\"6\" size-lg=\"6\">\n\n          <ion-card class=\"form-card login-form\">\n            <ion-card-header>\n              <ion-card-title class=\"login-title clr-black\">LOGIN</ion-card-title>\n            </ion-card-header>\n\n            <ion-card-content>\n              <form [formGroup]=\"loginForm\">\n                <ion-row>\n                  <ion-col class=\"icon-col pad-0\" size=\"1\">\n                    <ion-icon class=\"input-icon\" name=\"mail-outline\"></ion-icon>\n                  </ion-col>\n                  <ion-col class=\"pad-0\" size=\"11\">\n                    <ion-label class=\"form-lbl clr-black\"\n                      [ngStyle]=\"{'color':loginForm.controls.userName.invalid ? 'red':'green'}\" position=\"floating\">User\n                      Name\n                    </ion-label>\n                    <div class=\"inputs\">\n                      <ion-input #input1 (keyup.enter)=\"login()\" enterkeyhint=\"go\" formControlName=\"userName\"\n                        placeholder=\"Username\" ondrop=\"return false;\" onpaste=\"return false;\"></ion-input>\n                      <img class=\"align-check\" [hidden]=\"loginForm.controls.userName.invalid\"\n                        src=\"./assets/icon/check mark.png\">\n                      <!-- <img class=\"align-check\" [hidden]=\"loginForm.controls.Uname.valid\" src=\"assets/icon/error.png\"> -->\n                    </div>\n                  </ion-col>\n                </ion-row>\n                <br>\n           \n                <ion-row>\n                  <ion-col class=\"icon-col pad-0\" size=\"1\">\n                    <ion-icon class=\"input-icon\" name=\"lock-closed-outline\"></ion-icon>\n                  </ion-col>\n                  <ion-col class=\"pad-0\" size=\"11\">\n                    <ion-label class=\"form-lbl clr-black\"\n                      [ngStyle]=\"{'color':loginForm.controls.password.invalid ? 'red':'green'}\" position=\"floating\">\n                      Password</ion-label>\n                    <div class=\"inputs\">\n                      <ion-input #input2 (keyup.enter)=\"login()\" enterkeyhint=\"go\" placeholder=\"Password\"\n                        formControlName=\"password\" [type]=\"showPassword ?'text': 'password'\" ondrop=\"return false;\" onpaste=\"return false;\">\n                      </ion-input>\n                      <ion-icon class=\"align-check eyebtn clr-black\" style=\"z-index:99;\" (click)=\"togglepassword()\"\n                        [name]=\"passwordtoggleicon\"></ion-icon>\n                    </div>\n                  </ion-col>\n                </ion-row>\n                <!-- <ion-row>\n                <ion-col>\n                  <ion-label class=\"forget-lbl bold clr-black pointer\">Forgot Password?</ion-label>\n                </ion-col>\n              </ion-row> -->\n                <br><br>\n                <ion-row>\n                  <ion-col>\n                    <ion-button (click)=\"login()\" *ngIf=\"loginBtn\"   [disabled]=\"loginForm.invalid\"\n                      class=\"login-btn bold center\">SIGN IN\n                    </ion-button>\n                  </ion-col>\n                </ion-row>\n              </form>\n            </ion-card-content>\n          </ion-card>\n          <ion-row style=\"display:none ;\">\n            <ion-col>\n              <p class=\"signup bold clr-black\">Don't have an account ? <a href=\"\" (click)=\"registerLink()\"\n                  class=\"pointer\">&nbsp;Sign Up</a> </p>\n            </ion-col>\n          </ion-row>\n\n        </ion-col>\n      </ion-row>\n    </div>\n  </ion-grid>\n\n\n\n</ion-content>";

/***/ }),

/***/ 1029:
/*!***************************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.html?ngResource ***!
  \***************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <div>\n        <ion-back-button defaultHref=\"/\" mode=\"md\"></ion-back-button>\n      </div>\n    </ion-buttons>\n    <ion-buttons [hidden]=\"true\" slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"bold\">{{titleMsg}} [{{teamsData.length}}] </ion-title>\n    <ion-icon class=\"filter-icon\" (click)=\"filterOpen()\" slot=\"end\" name=\"funnel-outline\"></ion-icon>\n  </ion-toolbar>\n  <ion-card class=\"mar-0\" *ngIf=\"openFilter\">\n    <ion-card-content>\n      <ion-icon (click)=\"filterOpen()\" style=\"float: right;font-size: 18px;\" color=\"danger\" name=\"close-circle-outline\">\n      </ion-icon>\n      <form [formGroup]=\"managerForm\">\n        <ion-row>\n          <ion-col size=\"12\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone <span class=\"error\"\n                *ngIf=\"(managerForm.controls.zone.touched || submitted) && managerForm.controls.zone.errors?.required\">\n                *</span></ion-label>\n            <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\" placeholder=\"Select Zone\"\n              [multiple]=\"true\">\n              <ion-select-option *ngFor=\"let z of zoneData\" value=\"{{z.zone}}\">{{z.zone}}</ion-select-option>\n            </ion-select>\n          </ion-col>\n        </ion-row>\n      </form>\n    </ion-card-content>\n    <ion-badge style=\"float: right;padding: 6px;margin:6px;\" (click)=\"clearManagerFilter()\" color=\"danger\">Clear Filter\n    </ion-badge>&nbsp;\n  </ion-card>\n</ion-header>\n<ion-content>\n\n  <!-- <ion-card class=\"mar-0\" *ngIf=\"openFilter\">\n    <ion-card-content>\n      <ion-icon (click)=\"filterOpen()\" style=\"float: right;font-size: 18px;\" color=\"danger\" name=\"close-circle-outline\">\n      </ion-icon>\n      <form [formGroup]=\"managerForm\">\n        <ion-row>\n          <ion-col size=\"12\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone <span class=\"error\"\n                *ngIf=\"(managerForm.controls.zone.touched || submitted) && managerForm.controls.zone.errors?.required\">\n                *</span></ion-label>\n            <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\" placeholder=\"Select Zone\"\n              [multiple]=\"true\">\n              <ion-select-option value=\"East\">East</ion-select-option>\n              <ion-select-option value=\"West\">West</ion-select-option>\n              <ion-select-option value=\"North\">North</ion-select-option>\n              <ion-select-option value=\"South\">South</ion-select-option>\n              <ion-select-option value=\"Central\">Central</ion-select-option>\n            </ion-select>\n          </ion-col>\n        </ion-row>\n      </form>\n    </ion-card-content>\n    <ion-badge style=\"float: right;padding: 6px;margin:6px;\" (click)=\"clearManagerFilter()\" color=\"danger\">Clear Filter\n    </ion-badge>&nbsp;\n  </ion-card> -->\n\n  <ion-grid>\n    <ion-accordion-group>\n      <ion-accordion class=\"faq-list\" *ngFor=\"let item of teamsData;let i=index\" (click)=\"getCounts(item.id)\"\n        value=\"{{i+1}}\">\n        <ion-item slot=\"header\">\n          <div>\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-label class=\"list-lbl bold\">{{i+1}}. {{item.name | titlecase  }}</ion-label>\n                <ion-label class=\"list-lbl\" style=\" font-size:11px; \"><span>Total Dsr Count : {{item.Count}}</span> |\n                  <span>Total premium : {{item.sum ? (item.sum |currency: 'INR':'symbol':'1.0-0'):0 }}</span>\n                </ion-label>\n                <!-- | currency: 'INR' -->\n              </ion-col>\n            </ion-row>\n          </div>\n        </ion-item>\n        <div class=\"faq-list-data\" slot=\"content\">\n          <table>\n            <tr>\n              <th>Activities</th>\n              <th>{{yesturdayDate | date }}</th>\n              <th>\n                Current Month till<br>\n                {{yesturdayDate | date }}\n                <!-- {{month | date:'MMMM'}} -->\n                <!-- <p class=\"mar-0\">{{date}}</p> -->\n              </th>\n            </tr>\n\n            <tr *ngFor=\"let item of typeOfActivityData\">\n              <td class=\"tbl-lbl\">{{item.type}}</td>\n              <td>{{item.count}}</td>\n              <td>{{item.mnthCount}}</td>\n            </tr>\n             \n            <tr>\n              <th><b>Total</b> </th>\n              <th>{{yesturdayCount}}</th>\n              <th>{{monthCount}}   <ion-spinner [hidden]=\"spiner\" name=\"lines-sharp-small\"></ion-spinner> </th>\n            </tr>\n\n          </table>\n        </div>\n      </ion-accordion>\n    </ion-accordion-group>\n  </ion-grid>\n\n\n  <!-- if dsr avtivity is empty  -->\n\n  <div *ngIf=\"teamsData.length<=0\">\n    <img class=\"center empty-img ion-align-items-center\"  src=\"./assets/New/empty.svg\">\n    <h3 class=\"recordfound\">No Record Found !</h3>\n  </div>\n\n \n\n</ion-content>";

/***/ }),

/***/ 6396:
/*!*******************************************************************!*\
  !*** ./src/app/dsrActivity/dsrActivity.component.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <div>\n        <ion-back-button defaultHref=\"/\" mode=\"md\"></ion-back-button>\n      </div>\n    </ion-buttons> -->\n    <ion-buttons [hidden]=\"true\" slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"bold header-title\">\n      <ion-icon class=\"back-arrow\" (click)=\"backButton()\" name=\"arrow-back-outline\"></ion-icon>&nbsp;\n      {{titleMsg}} &nbsp; [{{filterData.length}}]\n    </ion-title>\n    <!-- <ion-icon class=\"download-icon\" slot=\"end\" (click)=\"excelExport('excel-table')\" name=\"download-outline\"></ion-icon> -->\n    <ion-icon class=\"add-icon\" slot=\"end\" routerLink=\"/home\" name=\"home-outline\"></ion-icon>\n    <ion-icon class=\"add-icon\" slot=\"end\" *ngIf=\"userFlag==1 || addAccess==Y\" (click)=\"AddDsrActivity()\" name=\"add-circle-outline\">\n    </ion-icon>\n    <ion-icon class=\"add-icon\" slot=\"end\" (click)=\"searchIcon()\" name=\"search-outline\"></ion-icon>\n    <ion-icon class=\"add-icon\" id=\"popover-button\" slot=\"end\" name=\"ellipsis-vertical-outline\"></ion-icon>\n  </ion-toolbar>\n  <ion-row *ngIf=\"searchBar\" class=\"fix-searchbar\">\n    <ion-col class=\"pad-0\">\n      <ion-searchbar [(ngModel)]=\"filterSearch\"  animated=\"true\" color=\"light\" class=\"pad-0\"\n        placeholder=\"search here\">\n      </ion-searchbar>\n    </ion-col>\n    <!-- <ion-col size=\"2\" class=\"pad-0\">\n      <ion-icon class=\"filter-icon\" (click)=\"searchIcon()\" name=\"close-outline\"></ion-icon>\n    </ion-col> -->\n  </ion-row>\n\n  <!-- filter start here -->\n  <ion-grid *ngIf=\"openFilter\" style=\"background:white\">\n    <ion-segment value=\"zone\" [scrollable]=\"true\" color=\"danger\" (ionChange)=\"segmentChanged($event)\">\n      <ion-segment-button [hidden]=\"userFlag<=1\" value=\"manager\">\n        <ion-label>Manager</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"zone\">\n        <ion-label>Zone</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"bank\">\n        <ion-label>Bank</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"activity\">\n        <ion-label>Activity</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"date\">\n        <ion-label>Date</ion-label>\n      </ion-segment-button>\n    </ion-segment>\n\n    <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'manager'\">\n      <ion-card-content>\n        <ion-icon (click)=\"filterOpen()\" style=\"float: right;font-size: 18px;\" color=\"danger\"\n          name=\"close-circle-outline\"></ion-icon>\n        <form [formGroup]=\"managerForm\">\n          <ion-row>\n            <ion-col size=\"12\" class=\"pad-0\">\n              <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone <span class=\"error\"\n                  *ngIf=\"(managerForm.controls.zone.touched || submitted) && managerForm.controls.zone.errors?.required\">\n                  *</span></ion-label>\n              <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\" placeholder=\"Select Zone\"\n                [multiple]=\"true\">\n                <!-- <ion-select formControlName=\"zone\"  mode=\"ios\" placeholder=\"Select Zone\" [multiple]=\"true\"> -->\n                <ion-select-option *ngFor=\"let z of zoneData\" value=\"{{z.zone}}\">{{z.zone}}</ion-select-option>\n              </ion-select>\n            </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col size=\"12\" class=\"pad-0\">\n              <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Manager <span class=\"error\"\n                  *ngIf=\"(managerForm.controls.manager.touched || submitted) && managerForm.controls.manager.errors?.required\">\n                  *</span></ion-label>\n              <ion-select [disabled]=\"managerForm.controls.zone.invalid\" formControlName=\"manager\"\n                (ionChange)=\"chngeManagers($event)\" placeholder=\"Select Manager\" [multiple]=\"true\" mode=\"ios\">\n                <ion-select-option value=\"{{item.id}}\" *ngFor=\"let item of managerData\">{{item.name}}\n                </ion-select-option>\n              </ion-select>\n            </ion-col>\n          </ion-row>\n        </form>\n      </ion-card-content>\n      <ion-badge style=\"float: right;padding: 6px;margin: 6px;\" (click)=\"clearManagerFilter()\" color=\"danger\">Clear\n        Filter</ion-badge>\n    </ion-card>\n\n    <div\n      *ngIf=\"segmentValue == 'zone' || segmentValue == 'bank' || segmentValue == 'activity' || segmentValue == 'date' \">\n      <form [formGroup]=\"filterForm\">\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'zone'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"12\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone</ion-label>\n                <!-- <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\" placeholder=\"Select Zone\" [multiple]=\"true\"> -->\n                <ion-select formControlName=\"zone\" mode=\"ios\" placeholder=\"Select Zone\" [multiple]=\"true\">\n                  <ion-select-option *ngFor=\"let z of zoneData\" value=\"{{z.zone}}\">{{z.zone}}</ion-select-option>\n                </ion-select>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'bank'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"12\" class=\"pad-0\">\n                <ion-item>\n                  <ion-label class=\"clr-black\">Bank Name </ion-label>\n                  <!-- itemValueField=\"id\" -->\n                  <ionic-selectable formControlName=\"bank\" itemValueField=\"bank_Name\" item-content [(ngModel)]=\"bank\"\n                    [items]=\"banks\" itemTextField=\"bank_Name\" [canSearch]=\"true\" [isMultiple]=\"true\" [canClear]=\"true\"\n                    [hasVirtualScroll]=\"true\" [hasInfiniteScroll]=\"true\" [shouldFocusSearchbar]=\"false\">\n                  </ionic-selectable>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'activity'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"12\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select activity</ion-label>\n                <ion-select formControlName=\"activity\" placeholder=\"Select Type of Activity\" [multiple]=\"true\"\n                  mode=\"ios\">\n                  <div>\n                    <ion-select-option value=\"Bank Branch visit\">Bank Branch visit</ion-select-option>\n                    <ion-select-option value=\"Bank Zonal office\">Bank Zonal office</ion-select-option>\n                    <ion-select-option value=\"Bank Regional office\">Bank Regional office</ion-select-option>\n                    <ion-select-option value=\"Customer service\">Customer service</ion-select-option>\n                    <ion-select-option value=\"Promotional activity\">Promotional activity</ion-select-option>\n                    <ion-select-option value=\"Joint call with supevisor\">Joint call with supevisor</ion-select-option>\n                    <ion-select-option value=\"Review/Office Meeting\">Review/Office meeting</ion-select-option>\n                    <ion-select-option value=\"Corporate salary\">Corporate salary</ion-select-option>\n                    <ion-select-option value=\"Policy Issuance/Other Back office work\">Policy issuance/Other Back office\n                      work</ion-select-option>\n                  </div>\n                </ion-select>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'date'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"6\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Start Date</ion-label>\n                <!-- <ion-icon class=\"calander-icon \" name=\"calendar-outline\"></ion-icon> -->\n                <ion-input class=\"calander-input\" formControlName=\"startDate\" type=\"date\"></ion-input>\n              </ion-col>\n              <ion-col size=\"6\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">End Date</ion-label>\n                <!-- <ion-icon class=\"calander-icon \" name=\"calendar-outline\"></ion-icon> -->\n                <ion-input class=\"calander-input\" formControlName=\"endDate\" type=\"date\"></ion-input>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n        <ion-row>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-label color=\"danger\" (click)=\"filterClose()\" class=\"fltr-btn center\">Close</ion-label>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-label color=\"warning\" [disabled]=\"true\" (click)=\"clearFilterForm()\" class=\"fltr-btn center\">Clear\n            </ion-label>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-label color=\"success\" [disabled]=\"true\" (click)=\"applyFilters()\" class=\"fltr-btn center\">Apply\n            </ion-label>\n          </ion-col>\n        </ion-row>\n      </form>\n    </div>\n\n  </ion-grid>\n  <!-- folter end here -->\n\n</ion-header>\n<ion-content [scrollEvents]=\"true\">\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content pullingIcon=\"arrow-down\" pullingText=\"Pull to refresh\" refreshingSpinner=\"bubbles\"\n      refreshingText=\"Refreshing...\"></ion-refresher-content>\n  </ion-refresher>\n\n  <div class=\"progress-outer\" *ngIf=\"progressBar\"  >\n    <div class=\"progress-inner\" [style.width]=\"progress + '%'\">\n      {{ progress}}%\n    </div>\n  </div>\n\n  <!-- <ion-card *ngIf=\"openFilter\" class=\"mar-0\">\n    <ion-card-content>\n      <form [formGroup]=\"filterForm\">\n        <ion-row>\n          <ion-col size=\"6\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Start Date</ion-label>\n            <ion-icon class=\"calander-icon\" name=\"calendar-outline\"></ion-icon>\n            <ion-input class=\"calander-input\" formControlName=\"startDate\" type=\"date\"></ion-input>\n            <span class=\"error\"\n              *ngIf=\"(filterForm.controls.startDate.touched || submitted) && filterForm.controls.startDate.errors?.required\">\n              Start Date is required</span>\n          </ion-col>\n          <ion-col size=\"6\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">End Date</ion-label>\n            <ion-icon class=\"calander-icon \" name=\"calendar-outline\"></ion-icon>\n            <ion-input class=\"calander-input\" formControlName=\"endDate\" type=\"date\"></ion-input>\n            <span class=\"error\"\n              *ngIf=\"(filterForm.controls.endDate.touched || submitted) && filterForm.controls.endDate.errors?.required\">\n              Start Date is required</span>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"danger\" (click)=\"filterOpen()\" class=\"fltr-btn bold center\">Close</ion-button>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"warning\" (click)=\"ClearFltr()\" class=\"fltr-btn bold center\">Clear</ion-button>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"success\" (click)=\"filterSubmit()\" class=\"fltr-btn bold center\">Filter</ion-button>\n          </ion-col>\n        </ion-row>\n\n      </form>\n    </ion-card-content>\n  </ion-card> -->\n\n  <!-- <ion-row *ngIf=\"searchBar\" class=\"fix-searchbar\">\n    <ion-col class=\"pad-0\">\n      <ion-searchbar [(ngModel)]=\"filterSearch\" class=\"pad-0\" placeholder=\"bank name, branch code, activity \">\n      </ion-searchbar>\n    </ion-col>\n    <ion-col size=\"2\" class=\"pad-0\">\n      <ion-icon class=\"filter-icon\" (click)=\"searchIcon()\" name=\"close-outline\"></ion-icon>\n    </ion-col>\n  </ion-row> -->\n\n  <ion-grid *ngIf=\"dsrDetails\">\n    <ion-accordion-group>\n      <ion-accordion class=\"faq-list\" mode=\"ios\" *ngFor=\"let item of filterData | filterdata:filterSearch; let i=index\"\n        value=\"{{i}}\">\n        <ion-item slot=\"header\">\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-label class=\"list-lbl\">{{item.type_Of_Activity | titlecase}}</ion-label>\n              <ion-label class=\"list-date\">{{item.date_Of_Visit | date: 'dd/MM/yyyy'}} | <span>\n                  {{item.zone | titlecase}} | {{item.bank_Name | titlecase}}</span>\n              </ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-item>\n        <div class=\"faq-list-data\" slot=\"content\">\n          <table>\n            <tr>\n              <td class=\"tbl-lbl\">Executive</td>\n              <td>{{item.executive | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Team Leader</td>\n              <td>{{item.team_Leader}}</td>\n            </tr>\n            <tr>\n              <td>Date of visit</td>\n              <td>{{item.date_Of_Visit | date: 'dd/MM/yyyy'}}</td>\n            </tr>\n            <tr>\n              <td>Start Time</td>\n              <td>{{item.start_Time}}</td>\n            </tr>\n            <tr>\n              <td>End Time</td>\n              <td>{{item.end_Time}}</td>\n            </tr>\n            <tr>\n              <td>Duration</td>\n              <td>{{item.duration}} HH:MM</td>\n            </tr>\n            <tr>\n              <td>Type of Activity</td>\n              <td>{{item.type_Of_Activity | titlecase}}</td>\n            </tr>\n            <ng-container *ngIf=\"item?.subTypeOfActivity.length > 0\">\n              <tr *ngFor=\"let subItem of item?.subTypeOfActivity\">\n                <td>\n                  <ul class=\"sub_activity\">\n                    <li>Sub Type of Activity</li>\n                    <li>Start Time</li>\n                    <li>End Time</li>\n                    <li>Duration</li>\n                    <li>Premium Collected Including GST</li>\n                  </ul>\n                </td>\n                <td>\n                  <ul class=\"sub_activity\">\n                    <li>{{subItem?.subTypeOfActivity | titlecase}}</li>\n                    <li>{{subItem?.subStartTime}}</li>\n                    <li>{{subItem?.subEndTime}}</li>\n                    <li>{{subItem?.subDuration}} HH:MM</li>\n                    <li>{{subItem ?.premium_Collected ? (subItem ?.premium_Collected |currency:\n                      'INR':'symbol':'1.0-0'):0}}</li>\n                  </ul>\n                </td>\n              </tr>\n            </ng-container>\n            <tr>\n              <td>Bank Name</td>\n              <td>{{item.bank_Name | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Branch Code</td>\n              <td>{{item.branch_Code}}</td>\n            </tr>\n            <tr>\n              <td>Bank Branch name</td>\n              <td>{{item.bank_Branch_Name | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Person Meet</td>\n              <td>{{item.to_Whom_Meet | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Contact Number</td>\n              <td>{{item.to_Whom_Meet_Number}}</td>\n            </tr>\n            <tr>\n              <td>Other Remark Comments</td>\n              <td>{{item.remark_Comments | titlecase}}</td>\n            </tr>\n          </table>\n        </div>\n      </ion-accordion>\n    </ion-accordion-group>\n  </ion-grid>\n\n  <ion-grid *ngIf=\"dsrActivityAdd\" class=\"pad-0\">\n    <ion-row class=\"form-row\">\n      <ion-col>\n        <ion-card class=\"form-card pad-0 mar-0\">\n          <ion-card-header>\n            <ion-card-title class=\"login-title center clr-black\">DSR Activity\n              <ion-icon (click)=\"closeAddActivity()\" style=\"float: right;color: red;\"\n                name=\"close-circle-outline\"></ion-icon>\n            </ion-card-title>\n          </ion-card-header>\n\n          <ion-card-content style=\"padding: 6px;\">\n            <form [formGroup]=\"drsFrom\">\n              <div [hidden]=\"true\">\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-label class=\"form-lbl clr-black\">Executive</ion-label>\n                    <ion-input class=\"input\" formControlName=\"executive\" clearInput readonly placeholder=\"Executive\">\n                    </ion-input>\n                    <span class=\"error\"\n                      *ngIf=\"(drsFrom.controls.executive.touched || submitted) && drsFrom.controls.executive.errors?.required\">\n                      Executive is required</span>\n                  </ion-col>\n                </ion-row>\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-label class=\"form-lbl clr-black\">Team Leader</ion-label>\n                    <ion-input class=\"input\" placeholder=\"Team Leader\" formControlName=\"team_Leader\"></ion-input>\n                  </ion-col>\n                </ion-row>\n\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-label class=\"form-lbl clr-black\">User Role</ion-label>\n                    <ion-input class=\"input\" formControlName=\"auth_role\"></ion-input>\n                  </ion-col>\n                </ion-row>\n\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-label class=\"form-lbl clr-black\">User Name</ion-label>\n                    <ion-input class=\"input\" formControlName=\"userName\"></ion-input>\n                  </ion-col>\n                </ion-row>\n\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-label class=\"form-lbl clr-black\">Zone</ion-label>\n                    <ion-input class=\"input\" formControlName=\"zone\" type=\"text\"></ion-input>\n                  </ion-col>\n                </ion-row>\n              </div>\n              <ion-row>\n                <ion-col size=\"12\">\n                 \n                  <ion-list class=\"calendar\" style=\"padding: 0;\">\n                    <ion-item id=\"open-modal2\" style=\"margin-left: -17px;border-bottom: 1px solid #e4dddd;\">\n                      <ion-label style=\"color:rgb(21, 20, 20);\">Date of visit</ion-label>\n                      <ion-note style=\"color:rgb(16, 15, 15);font-size: 14px;\" slot=\"end\">{{clanderDate ? (clanderDate | date ): 'MM/DD/YYYY' }}</ion-note>\n                    </ion-item>\n                    <ion-modal trigger=\"open-modal2\" [cssClass]=\"'bottom-end'\">\n                      <ng-template>\n                        <ion-datetime presentation=\"date\" displayFormat=\"YYYY-MM-DD\"\n                          (ionChange)=\"dateClanderChange($event)\" size=\"cover\" [showDefaultButtons]=\"true\"\n                          min=\"{{minDate}}\" max='{{maxDate}}' formControlName=\"date_Of_Visit\"></ion-datetime>\n                      </ng-template> </ion-modal>\n                  </ion-list>\n                  \n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.date_Of_Visit.touched || submitted) && drsFrom.controls.date_Of_Visit.errors?.required\">Date is required</span>\n                </ion-col>\n              </ion-row>\n              <!-- <p>{{d}}</p> -->\n              <!-- min='{{minDate}}' -->\n              <ion-row>\n                <ion-col size=\"6\">\n                  <ion-label class=\"form-lbl clr-black\">Start Time\n                  </ion-label>\n                  <!-- <ion-icon class=\"time-icon extra-icon\" name=\"time-outline\"></ion-icon> -->\n                  <ion-input (change)=\"startTimeChange($event)\" class=\"input calander-input\"\n                    formControlName=\"start_Time\" type=\"time\"></ion-input>\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.start_Time.touched || submitted) && drsFrom.controls.start_Time.errors?.required\">Start\n                    time is required</span>\n                </ion-col>\n                <ion-col size=\"6\">\n                  <ion-label class=\"form-lbl clr-black\">End Time\n                  </ion-label>\n                  <!-- <ion-icon class=\"time-icon extra-icon\" name=\"time-outline\"></ion-icon> -->\n                  <ion-input (change)=\"endTimeChange($event)\" class=\"input calander-input\" formControlName=\"end_Time\"\n                    type=\"time\" [disabled]=\"end_Time_picker\">\n                  </ion-input>\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.end_Time.touched || submitted) && drsFrom.controls.end_Time.errors?.required\">End\n                    time is required</span>\n                </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl clr-black\">Duration </ion-label>\n                  <ion-input class=\"input\" placeholder=\"Time Duration\" formControlName=\"duration\" value=\"{{Duration}}\"\n                    readonly>\n                  </ion-input>\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.duration.touched || submitted) && drsFrom.controls.duration.errors?.required\">\n                    Duration is required</span>\n                </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl clr-black\">Type of Activity\n                  </ion-label>\n                  <ion-select class=\"input\" style=\"padding-left:5px\" (ionChange)=\"checkSpaicelChar($event)\" formControlName=\"type_Of_Activity\"\n                    placeholder=\"Select Type of Activity\" mode=\"ios\">\n                    <div>\n                      <ion-select-option value=\"Bank Branch visit\">Bank Branch visit</ion-select-option>\n                      <ion-select-option value=\"Bank Zonal office\">Bank Zonal office</ion-select-option>\n                      <ion-select-option value=\"Bank Regional office\">Bank Regional office</ion-select-option>\n                      <ion-select-option value=\"Customer service\">Customer service</ion-select-option>\n                      <ion-select-option value=\"Promotional activity\">Promotional activity</ion-select-option>\n                      <ion-select-option value=\"Joint call with supevisor\">Joint call with supevisor</ion-select-option>\n                      <ion-select-option value=\"Review/Office Meeting\">Review/Office meeting</ion-select-option>\n                      <ion-select-option value=\"Corporate salary\">Corporate salary</ion-select-option>\n                      <ion-select-option value=\"Policy Issuance/Other Back office work\">Policy issuance/Other Back\n                        office\n                        work</ion-select-option>\n                    </div>\n                  </ion-select>\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.type_Of_Activity.touched || submitted) && drsFrom.controls.type_Of_Activity.errors?.required\">Type\n                    of Activity is required</span>\n\n                </ion-col>\n              </ion-row>\n              <br>\n              <ion-row class=\"subActivity\" formArrayName=\"subTypeOfActivity\">\n                <ion-col size=\"12\">\n                  <ion-row *ngFor=\"let activity of subTypeOfActivity().controls;let i=index\" [formGroupName]=\"i\"\n                    style=\"margin-bottom: 5%;\">\n                    <ion-col size=\"10\">\n                      <ion-label class=\"form-lbl clr-black\">Sub Type of Activity </ion-label>\n                      <ion-select class=\"input\" (ionChange)=\"checkSpaicelChar($event)\"\n                        formControlName=\"subTypeOfActivity\" placeholder=\"Select Type of Activity\" mode=\"ios\">\n                        <div>\n                          <ion-select-option value=\"New Premium Collection\">New Premium Collection</ion-select-option>\n                          <ion-select-option value=\"Renewal Premium\">Renewal Premium</ion-select-option>\n                          <ion-select-option value=\"Cross-sell\"> Cross-sell</ion-select-option>\n                          <ion-select-option value=\"Business Planning Discussion\"> Business Planning Discussion\n                          </ion-select-option>\n                        </div>\n                      </ion-select>\n\n                      <span class=\"error\" *ngIf=\"(newSubTypeOfActivity().controls.subTypeOfActivity.touched || \n                      submitted) && newSubTypeOfActivity().controls.subTypeOfActivity.errors?.required ||\n                      newSubTypeOfActivity().controls.subTypeOfActivity.dirty\">Sub Type of activity is required</span>\n                    </ion-col>\n                    <ion-col size=\"2\">\n                      <ion-icon class=\"remove-icon\" (click)=\"removeSubTypeActivity(i)\" name=\"close-circle-outline\">\n                      </ion-icon>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                      <ion-label class=\"form-lbl clr-black\">Start Time\n                      </ion-label>\n                      <!-- <ion-icon class=\"sub-time-icon extra-icon\" name=\"time-outline\"></ion-icon> -->\n                      <ion-input (change)=\"substartTimeChange($event)\" class=\"input calander-input\"\n                        formControlName=\"subStartTime\" type=\"time\">\n                      </ion-input>\n                      <span class=\"error\" *ngIf=\"(newSubTypeOfActivity().controls.subStartTime.touched || \n                        submitted) && newSubTypeOfActivity().controls.subStartTime.errors?.required\">Start time is\n                        required</span>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                      <ion-label class=\"form-lbl clr-black\">End Time </ion-label>\n                      <!-- <ion-icon class=\"sub-time-icon extra-icon\" name=\"time-outline\"></ion-icon> -->\n                      <ion-input (change)=\"subendTimeChange($event,activity)\" class=\"input calander-input\"\n                        formControlName=\"subEndTime\" type=\"time\">\n                      </ion-input>\n                      <span class=\"error\" *ngIf=\"(newSubTypeOfActivity().controls.subEndTime.touched || \n                        submitted) && newSubTypeOfActivity().controls.subEndTime.errors?.required\">End time is\n                        required</span>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                      <ion-label class=\"form-lbl clr-black\">Duration </ion-label>\n                      <ion-input class=\"input\" formControlName=\"subDuration\" readonly> </ion-input>\n                      <span class=\"error\" *ngIf=\"(newSubTypeOfActivity().controls.subDuration.touched || \n                        submitted) && newSubTypeOfActivity().controls.subDuration.errors?.required\">Duration is\n                        required</span>\n                    </ion-col>\n                    <ion-col size=\"12\">\n                      <ion-label class=\"form-lbl clr-black\">Premium Collected Including GST\n                      </ion-label>\n                      <ion-input type=\"number\" formControlName=\"premium_Collected\"\n                        (ionChange)=\"checkSpaicelChar($event)\" class=\"input\" clearInput placeholder=\"Premium Collected\"\n                        ondrop=\"return false;\" onpaste=\"return false;\"></ion-input>\n                      <span class=\"error\" *ngIf=\"(newSubTypeOfActivity().controls.premium_Collected.touched || \n                      submitted) && newSubTypeOfActivity().controls.premium_Collected.errors?.required\">Premium\n                        Collected is required</span>\n\n                    </ion-col>\n                  </ion-row>\n\n                  <ion-row>\n                    <ion-col size=\"8\">\n                      <ion-label class=\"form-lbl clr-black\">Add Sub Type of Activity</ion-label>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                      <ion-label (click)=\"addSubTypeOfActivity()\" class=\"bold\" style=\"float: right;\" color=\"success\">Add\n                        New +\n                      </ion-label>\n                    </ion-col>\n                  </ion-row>\n                </ion-col>\n              </ion-row>\n              <br>\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-item class=\"input\" style=\"--padding-start:0px;\" (click)=\"bankLoad()\">\n                    <ion-label class=\"clr-black\">Bank Name\n                    </ion-label>\n                    <!-- itemValueField=\"id\" -->\n                    <ionic-selectable formControlName=\"bank_Name\" item-content [(ngModel)]=\"bank\" [items]=\"banks\"\n                      itemTextField=\"bank_Name\" (onChange)=\"bankNameChange($event)\" [canSearch]=\"true\"\n                      [isMultiple]=\"false\" [canClear]=\"true\" [hasVirtualScroll]=\"true\" [hasInfiniteScroll]=\"true\"\n                      [shouldBackDropClose]=\"false\" [shouldFocusSearchbar]=\"false\">\n                    </ionic-selectable>\n                  </ion-item>\n\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.bank_Name.touched || submitted) && drsFrom.controls.bank_Name.errors?.required\">Bank\n                    Name is required</span>\n                </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-item class=\"input\" (click)=\"bankBranchClick()\" style=\"--padding-start:0px;\" [disabled]=\"drsFrom.controls.bank_Name.invalid\">\n                    <ion-label class=\"clr-black\">Bank Branch Name\n                    </ion-label>\n                    <!-- itemValueField=\"id\" -->\n                    <ionic-selectable formControlName=\"bank_Branch_Name\" item-content [(ngModel)]=\"branchName\"\n                      [items]=\"branchNames\" itemTextField=\"bank_Branch_Name\" (onChange)=\"bankBranchNameChange($event)\"\n                      [canSearch]=\"true\" [isMultiple]=\"false\" [canClear]=\"true\" [hasVirtualScroll]=\"true\"\n                      [hasInfiniteScroll]=\"true\" [shouldFocusSearchbar]=\"false\">\n                    </ionic-selectable>\n                  </ion-item>\n\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.bank_Branch_Name.touched || submitted) && drsFrom.controls.bank_Branch_Name.errors?.required\">Bank\n                    Branch Name is required</span>\n                </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl clr-black\">Branch code</ion-label>\n                  <ion-input formControlName=\"branch_Code\" (ionChange)=\"checkSpaicelChar($event)\"\n                    value=\"{{bankBranchCode}}\" readonly class=\"input\" placeholder=\"Branch code\" ondrop=\"return false;\"\n                    onpaste=\"return false;\">\n                  </ion-input>\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.branch_Code.touched || submitted) && drsFrom.controls.branch_Code.errors?.required\">Branch\n                    Code is required</span>\n\n                </ion-col>\n              </ion-row>\n\n              <!-- <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl bold clr-black\">Bank Branch name</ion-label>\n                  <ion-input formControlName=\"bank_Branch_Name\" class=\"input\" clearInput placeholder=\"Bank Branch name\">\n                  </ion-input>\n                </ion-col>\n              </ion-row> -->\n\n              <!-- <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl bold clr-black\">Mode of Transport</ion-label>\n                  <ion-select formControlName=\"mode_Of_Transport\" placeholder=\"Plz Select Mode of Transport\">\n                    <div>\n                      <ion-select-option value=\"Bus\">Bus</ion-select-option>\n                      <ion-select-option value=\"Train\">Train</ion-select-option>\n                      <ion-select-option value=\" Two wheeler\"> Two wheeler</ion-select-option>\n                      <ion-select-option value=\"Four wheelers\">Four wheelers</ion-select-option>\n                      <ion-select-option value=\"Auto rickshaw\">Auto rickshaw</ion-select-option>\n                    </div>\n                  </ion-select>\n                </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl bold clr-black\">Travel From</ion-label>\n                  <ion-input formControlName=\"travel_From\" class=\"input\" clearInput placeholder=\"Travel From\">\n                  </ion-input>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl bold clr-black\">Travel To</ion-label>\n                  <ion-input formControlName=\"travel_To\" class=\"input\" clearInput placeholder=\"Travel To\"></ion-input>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl bold clr-black\">Kilometers Travelled</ion-label>\n                  <ion-input formControlName=\"kilometers_Travelled\" class=\"input\" clearInput\n                    placeholder=\"Kilometers Travelled\"></ion-input>\n                </ion-col>\n              </ion-row> -->\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl clr-black\">Person meet\n                  </ion-label>\n                  <ion-input formControlName=\"to_Whom_Meet\" (ionChange)=\"checkSpaicelChar($event)\" class=\"input\"\n                    clearInput placeholder=\"He/She\" onPaste=\"return false\" onCopy=\"return false\"\n                    onCut=\"return false\"></ion-input>\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.to_Whom_Meet.touched || submitted) && drsFrom.controls.to_Whom_Meet.errors?.required\">Person\n                    meet is required</span>\n                </ion-col>\n              </ion-row>\n\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl clr-black\">Contact number </ion-label>\n                  <ion-input formControlName=\"to_Whom_Meet_Number\" (ionChange)=\"checkSpaicelChar($event)\" class=\"input\" onKeyPress=\"if(this.value.length==10) return false;\"\n                    clearInput type=\"number\" placeholder=\"99********\" onPaste=\"return false\" onCopy=\"return false\"\n                    onCut=\"return false\" inputmode=\"numeric\"></ion-input>\n                  <span style=\"font-size:11px;color: red;\"\n                    *ngIf=\"drsFrom.controls.to_Whom_Meet_Number.errors?.pattern\">Please Enter 10 digit\n                    mobile number\n                  </span>\n                  <span class=\"error\"\n                    *ngIf=\"(drsFrom.controls.to_Whom_Meet_Number.touched || submitted) && drsFrom.controls.to_Whom_Meet_Number.errors?.required\">Mobile\n                    number is required</span>\n                    <p>{{text}}</p>\n                </ion-col>\n              </ion-row>\n              <br>\n              <ion-row>\n                <ion-col size=\"12\">\n                  <ion-label class=\"form-lbl clr-black\">Other Remark Comments</ion-label>\n                  <textarea class=\"textarea input\" rows=\"4\" formControlName=\"remark_Comments\"\n                    placeholder=\"Other remark comments....\" onPaste=\"return false\" onCopy=\"return false\"\n                    onCut=\"return false\"></textarea>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col>\n                  <!-- [disabled]=\"drsFrom.invalid\" -->\n                  <ion-button (click)=\"onSubmit()\" class=\"login-btn bold center\">SUBMIT\n                    &nbsp; <ion-icon style=\"color: white;\" name=\"arrow-forward-outline\"></ion-icon>\n                  </ion-button>\n                </ion-col>\n              </ion-row>\n            </form>\n          </ion-card-content>\n        </ion-card>\n\n\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n  <!-- This code only for download excel , start here -->\n  <div id=\"excel-table\" style=\"display: none;\">\n    <tr>\n      <th>Executive</th>\n      <th>Team Leader</th>\n      <th>Date of visit</th>\n      <th>Start Time</th>\n      <th>End Time</th>\n      <th>Duration</th>\n      <th>Type of Activity</th>\n      <ul class=\"sub_activity\">\n        <li>Sub Type of Activity</li>\n        <li>Start Time</li>\n        <li>End Time</li>\n        <li>Duration</li>\n        <li>Premium Collected Including GST</li>\n      </ul>\n      <th>Bank Name</th>\n      <th>Branch Code</th>\n      <th>Bank Branch name</th>\n      <th>Person Meet</th>\n      <th>Contact Number</th>\n      <th>Other Remark Comments</th>\n    </tr>\n    <table *ngFor=\"let item of filterData | filterdata:filterSearch; let i=index\">\n      <tr>\n        <td>{{item.executive}}</td>\n        <td>{{item.team_Leader}}</td>\n        <td>{{item.date_Of_Visit}}</td>\n        <td>{{item.start_Time}}</td>\n        <td>{{item.end_Time}}</td>\n        <td>{{item.duration}}</td>\n        <td>{{item.type_Of_Activity}}</td>\n\n        <td *ngFor=\"let subItem of item.subTypeOfActivity\">\n          <ul class=\"sub_activity\">\n            <li>{{subItem.subTypeOfActivity}}</li>\n            <li>{{subItem.subStartTime}}</li>\n            <li>{{subItem.subEndTime}}</li>\n            <li>{{subItem.subDuration}}</li>\n            <li>{{item.premium_Collected ? (item.premium_Collected |currency: 'INR':'symbol':'1.0-0'):0}}</li>\n          </ul>\n        </td>\n        <td>{{item.bank_Name}}</td>\n        <td>{{item.branch_Code}}</td>\n        <td>{{item.bank_Branch_Name}}</td>\n        <td>{{item.to_Whom_Meet}}</td>\n        <td>{{item.to_Whom_Meet_Number}}</td>\n\n        <td>{{item.remark_Comments}}</td>\n      </tr>\n    </table>\n  </div>\n  <!-- This code only for download excel , end here -->\n\n  <!-- if dsr avtivity is empty  -->\n  <ng-container *ngIf=\"emptyRecord\">\n    <div *ngIf=\"filterData.length == 0\">\n      <img class=\"center empty-img\" src=\"./assets/New/empty.svg\">\n      <h3 class=\"recordfound\">No Record Found !</h3><br>\n      <!-- <ion-button class=\"empty-btn center\" *ngIf=\"userFlag==1\" (click)=\"AddDsrActivity()\" size=\"small\">Add Dsr Activity\n      </ion-button> -->\n    </div>\n  </ng-container>\n\n\n\n\n  <ion-popover trigger=\"popover-button\" [dismissOnSelect]=\"true\" mode=\"ios\">\n    <ng-template>\n      <ion-content>\n        <ion-list>\n          <ion-item [button]=\"true\" (click)=\"filterOpen()\" [detail]=\"false\">\n            <ion-row class=\"popover-row\">\n              <ion-col size=\"3\">\n                <ion-icon name=\"funnel-outline\"></ion-icon>\n              </ion-col>\n              <ion-col><span>Filter</span></ion-col>\n            </ion-row>\n          </ion-item>\n          <!-- <ion-item [button]=\"true\" (click)=\"filterOpen()\" [detail]=\"false\">\n            <ion-row class=\"popover-row\">\n              <ion-col size=\"3\">\n                <ion-icon name=\"calendar-number-outline\"></ion-icon>\n              </ion-col>\n              <ion-col><span>Find By Date</span></ion-col>\n            </ion-row>\n          </ion-item> -->\n          <!-- <ion-item [button]=\"true\" (click)=\"excelExport('excel-table')\" \n            [hidden]=\"filterData.length == 0\" [detail]=\"false\">\n            <ion-row class=\"popover-row\">\n              <ion-col size=\"3\">\n                <ion-icon name=\"download-outline\"></ion-icon>\n              </ion-col>\n              <ion-col><span>Download</span></ion-col>\n            </ion-row>\n          </ion-item> -->\n        </ion-list>\n      </ion-content>\n    </ng-template>\n  </ion-popover>\n\n</ion-content>\n<ng-container *ngIf=\"PremiumFooter\">\n  <ion-footer *ngIf=\"totalPremium\">\n    <ion-toolbar>\n      <ion-row>\n        <!-- <ion-col size=\"9\">\n          <ion-title style=\"font-size:12px\">Total Premium :</ion-title>\n        </ion-col> -->\n        <ion-col size=\"12\">\n          <p class=\"center\" style=\"font-size:15px;color: white;margin: 0;\"><b>\n              Total Premium : {{totalPremium ? (totalPremium |currency: 'INR':'symbol':'1.0-0'):0}}</b></p>\n        </ion-col>\n      </ion-row>\n    </ion-toolbar>\n  </ion-footer>\n</ng-container>";

/***/ }),

/***/ 4715:
/*!*****************************************************!*\
  !*** ./src/app/home/home.component.html?ngResource ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<!-- <app-header [titleMsg]=\"titleMsg\" [menuBtn]=\"true\" [showBackButton]=\"false\"></app-header> -->\n\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons  slot=\"start\">\n      <ion-menu-button (ionWillOpen)=\"onMenuOpen()\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"bold\">{{titleMsg}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"progress-outer\" *ngIf=\"progressBar\"  >\n    <div class=\"progress-inner\" [style.width]=\"progress + '%'\">\n      {{ progress}}%\n    </div>\n  </div>\n\n  <ion-row>\n     <ion-col *ngIf=\"userFlag==1\" size=\"12\" size-md=\"6\" size-lg=\"6\">\n     <!-- <ion-col *ngIf=\"userFlag==1 || addAccess==Y\" size=\"12\" size-md=\"6\" size-lg=\"6\"> -->\n      <ion-card>\n        <div class=\"bg\"><img class=\"center\" src=\"./assets/New/w2.jpg\"></div>\n        <ion-card-content routerLink=\"/dsrActivity\">\n          <ion-row>\n            <ion-col size=\"3\">\n              <img class=\"center\" src=\"./assets/New/dsr.png\">\n            </ion-col>\n            <ion-col size=\"9\">\n              <p class=\"bold title center\">DSR Activity</p>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n    \n    <ion-col size=\"12\" size-md=\"6\" size-lg=\"6\" *ngIf=\"userFlag>1\">\n      <ion-card>\n        <div class=\"bg\"><img class=\"center\" src=\"./assets/New/w2.jpg\"></div>\n        <ion-card-content routerLink=\"/dashboard\">\n          <ion-row>\n            <ion-col size=\"3\">\n              <img class=\"center\" src=\"./assets/New/dashboard.png\">\n            </ion-col>\n            <ion-col size=\"9\">\n              <p class=\"bold title center\">Dashboard</p>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n\n    <ion-col *ngIf=\"userFlag>1\" size=\"12\" size-md=\"6\" size-lg=\"6\">\n      <ion-card>\n        <div class=\"bg\"><img class=\"center\" src=\"./assets/New/w2.jpg\"></div>\n        <ion-card-content routerLink=\"/teamsDemo:id\">\n          <ion-row>\n            <ion-col size=\"3\">\n              <img class=\"center\" src=\"./assets/New/teams.png\">\n            </ion-col>\n            <ion-col size=\"9\">\n              <p class=\"bold title center\">Teams Activity</p>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n    </ion-col> \n\n    <ion-col size=\"12\" size-md=\"6\" size-lg=\"6\" *ngIf=\"userFlag>1\">\n      <ion-card>\n        <div class=\"bg\"><img class=\"center\" src=\"./assets/New/w2.jpg\"></div>\n        <ion-card-content routerLink=\"/report\">\n          <ion-row>\n            <ion-col size=\"3\">\n              <img class=\"center\" src=\"./assets/New/reports.png\">\n            </ion-col>\n            <ion-col size=\"9\">\n              <p class=\"bold title center\">Reports</p>\n            </ion-col>\n          </ion-row>\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n\n  </ion-row>\n\n\n</ion-content>";

/***/ }),

/***/ 3045:
/*!*******************************************************************!*\
  !*** ./src/app/network-err/network-err.component.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\n  <ion-card>\n    <ion-card-header>\n    </ion-card-header>\n    <ion-card-content>\n      <!-- <img class=\"center\" src=\"./assets/New/internet.svg\"> -->\n      <p class=\"wifi\"> 📶 </p>\n      <ion-label class=\"center network\">Check Your Internet Connection !</ion-label><br><br>\n      <ion-button (click)=\"exitApp()\" class=\"center\">Reload</ion-button>\n    </ion-card-content>\n  </ion-card>\n  <style>\n    .center {\n      margin-left: auto;\n      margin-right: auto;\n      display: block;\n      text-align: center;\n      \n    }\n    .network {\n      font-weight: bold;\n      font-size: 22px;\n    }\n    .wifi{\n      text-align: center;\n    font-size: 4rem;\n    background: #f0f8ff;\n    border-radius: 10px;\n    padding: 40px;\n    }\n  </style>\n</ion-content>";

/***/ }),

/***/ 9779:
/*!*********************************************************!*\
  !*** ./src/app/report/report.component.html?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <div>\n        <ion-back-button defaultHref=\"/\" mode=\"md\"></ion-back-button>\n      </div>\n    </ion-buttons>\n    <ion-buttons [hidden]=\"true\" slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"bold\">{{titleMsg}} [{{filterData.length}}]</ion-title>\n    <ion-icon class=\"filter-icon\" (click)=\"filterOpen()\" slot=\"end\" name=\"funnel-outline\"></ion-icon>\n    <ion-icon class=\"add-icon\" slot=\"end\" (click)=\"searchIcon()\" name=\"search-outline\"></ion-icon>\n    <!-- <ion-icon class=\"filter-icon download-btn\" (click)=\"excelExport('excel-table')\" [hidden]=\"filterData.length == 0\"\n      slot=\"end\" name=\"download-outline\"></ion-icon> -->\n  </ion-toolbar>\n\n  <ion-row *ngIf=\"searchBar\" class=\"fix-searchbar\">\n    <ion-col class=\"pad-0\">\n      <ion-searchbar [(ngModel)]=\"filterSearch\" autofocus=\"true\" animated=\"true\" color=\"light\" class=\"pad-0\"\n        placeholder=\"search here\">\n      </ion-searchbar>\n    </ion-col>\n    <!-- <ion-col size=\"2\" class=\"pad-0\">\n      <ion-icon class=\"filter-icon\" (click)=\"searchIcon()\" name=\"close-outline\"></ion-icon>\n    </ion-col> -->\n  </ion-row>\n  <!-- filter start here -->\n  <ion-grid *ngIf=\"openFilter\" style=\"background:white\">\n    <ion-segment value=\"manager\" [scrollable]=\"true\" color=\"danger\" (ionChange)=\"segmentChanged($event)\">\n      <ion-segment-button [hidden]=\"userFlag<=1\" value=\"manager\">\n        <ion-label>Manager</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"zone\">\n        <ion-label>Zone</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"bank\">\n        <ion-label>Bank</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"activity\">\n        <ion-label>Activity</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"date\">\n        <ion-label>Date</ion-label>\n      </ion-segment-button>\n    </ion-segment>\n\n    <div [hidden]=\"userFlag<=1\">\n      <div *ngIf=\"segmentValue == 'manager'\">\n        <ion-card class=\"mar-0\">\n          <ion-card-content>\n            <ion-icon (click)=\"filterOpen()\" style=\"float: right;font-size: 18px;\" color=\"danger\"\n              name=\"close-circle-outline\"></ion-icon>\n            <form [formGroup]=\"managerForm\">\n              <ion-row>\n                <ion-col size=\"12\" class=\"pad-0\">\n                  <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone <span class=\"error\"\n                      *ngIf=\"(managerForm.controls.zone.touched || submitted) && managerForm.controls.zone.errors?.required\">\n                      *</span></ion-label>\n                  <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\"\n                    placeholder=\"Select Zone\" [multiple]=\"true\">\n                    <!-- <ion-select formControlName=\"zone\"  mode=\"ios\" placeholder=\"Select Zone\" [multiple]=\"true\"> -->\n                    <ion-select-option *ngFor=\"let z of zoneData\" value=\"{{z.zone}}\">{{z.zone}}</ion-select-option>\n                  </ion-select>\n                </ion-col>\n              </ion-row>\n              <ion-row>\n                <ion-col size=\"12\" class=\"pad-0\">\n                  <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Manager <span class=\"error\"\n                      *ngIf=\"(managerForm.controls.manager.touched || submitted) && managerForm.controls.manager.errors?.required\">\n                      *  <span class=\"error2\"  *ngIf=\"showmangerDrop\">Manager Data Not Found</span></span>\n                     \n                    </ion-label>\n                    <ion-select *ngIf=\"managerData\" [disabled]=\"managerForm.controls.zone.invalid\" formControlName=\"manager\"\n                      (ionChange)=\"chngeManagers($event)\" placeholder=\"Select Manager\" [multiple]=\"true\" mode=\"ios\">\n                     <ion-select-option value=\"{{item.id}}\" *ngFor=\"let item of managerData\">{{item.name | titlecase }}\n                     </ion-select-option>\n                    </ion-select>\n                </ion-col>\n              </ion-row>\n            </form>\n          </ion-card-content>\n          <!-- <ion-badge style=\"float: right;padding: 6px;margin: 6px;\" (click)=\"clearManagerFilter()\" color=\"danger\">Clear\n          Filter</ion-badge> -->\n\n        </ion-card>\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-label (click)=\"closeFilter()\" style=\"margin: 1% 0% 1% 0%;\" class=\"fltr-btn center\">Close</ion-label>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-label (click)=\"clearManagerFilter()\" style=\"margin: 1% 0% 1% 0%;\" class=\"fltr-btn center\">Clear\n              Filter</ion-label>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n\n\n    <div\n      *ngIf=\"segmentValue == 'zone' || segmentValue == 'bank' || segmentValue == 'activity' || segmentValue == 'date' \">\n      <form [formGroup]=\"filterForm\">\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'zone'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"12\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone</ion-label>\n                <!-- <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\" placeholder=\"Select Zone\" [multiple]=\"true\"> -->\n                <ion-select formControlName=\"zone\" mode=\"ios\" placeholder=\"Select Zone\" [multiple]=\"true\">\n                  <ion-select-option *ngFor=\"let z of zoneData\" value=\"{{z.zone}}\">{{z.zone}}</ion-select-option>\n                </ion-select>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'bank'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"12\" class=\"pad-0\">\n                <ion-item>\n                  <ion-label class=\"clr-black\">Bank Name</ion-label>\n                  <!-- itemValueField=\"id\" -->\n                  <ionic-selectable formControlName=\"bank\" item-content [(ngModel)]=\"bank\" [items]=\"banks\"\n                    itemTextField=\"bank_Name\" [canSearch]=\"true\" [canClear]=\"true\" [isMultiple]=\"true\"\n                    [hasVirtualScroll]=\"true\" [hasInfiniteScroll]=\"true\" [shouldFocusSearchbar]=\"false\">\n                  </ionic-selectable>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'activity'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"12\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select activity</ion-label>\n                <ion-select formControlName=\"activity\" placeholder=\"Plz Select Type of Activity\" [multiple]=\"true\"\n                  mode=\"ios\">\n                  <div>\n                    <ion-select-option value=\"Bank Branch visit\">Bank Branch visit</ion-select-option>\n                    <ion-select-option value=\"Bank Zonal office\">Bank Zonal office</ion-select-option>\n                    <ion-select-option value=\"Bank Regional office\">Bank Regional office</ion-select-option>\n                    <ion-select-option value=\"Customer service\">Customer service</ion-select-option>\n                    <ion-select-option value=\"Promotional activity\">Promotional activity</ion-select-option>\n                    <ion-select-option value=\"Joint call with supevisor\">Joint call with supevisor</ion-select-option>\n                    <ion-select-option value=\"Review/Office Meeting\">Review/Office meeting</ion-select-option>\n                    <ion-select-option value=\"Corporate salary\">Corporate salary</ion-select-option>\n                    <ion-select-option value=\"Policy Issuance/Other Back office work\">Policy issuance/Other Back office\n                      work</ion-select-option>\n                  </div>\n                </ion-select>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n\n        <ion-card class=\"mar-0\" *ngIf=\"segmentValue == 'date'\">\n          <ion-card-content>\n            <ion-row>\n              <ion-col size=\"6\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Start Date</ion-label>\n                <!-- <ion-icon class=\"calander-icon \" name=\"calendar-outline\"></ion-icon> -->\n                <ion-input class=\"calander-input\" formControlName=\"startDate\" type=\"date\"></ion-input>\n    \n              </ion-col>\n              <ion-col size=\"6\" class=\"pad-0\">\n                <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">End Date</ion-label>\n                <!-- <ion-icon class=\"calander-icon \" name=\"calendar-outline\"></ion-icon> -->\n                <ion-input class=\"calander-input\" formControlName=\"endDate\" type=\"date\"></ion-input>\n              </ion-col>\n            </ion-row>\n          </ion-card-content>\n        </ion-card>\n\n        <ion-row>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-label (click)=\"filterOpen()\" style=\"margin: 3% 0% 2% 0%;\" class=\"fltr-btn center\">Close</ion-label>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-label [disabled]=\"true\" (click)=\"clearFilterForm()\" style=\"margin: 3% 0% 2% 0%;\"\n              class=\"fltr-btn center\">Clear</ion-label>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-label [disabled]=\"true\" (click)=\"applyFilters()\" style=\"margin: 3% 0% 2% 0%;\"\n              class=\"fltr-btn center\">Apply</ion-label>\n\n          </ion-col>\n        </ion-row>\n      </form>\n    </div>\n\n  </ion-grid>\n  <!-- filter end here -->\n\n</ion-header>\n<ion-content>\n\n\n  <ion-grid *ngIf=\"dsrDetails\">\n    <ion-accordion-group>\n      <ion-accordion class=\"faq-list\" *ngFor=\"let item of filterData | filterdata:filterSearch; let i=index\"\n        value=\"{{i}}\">\n        <ion-item slot=\"header\">\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-label class=\"list-lbl\">{{item.type_Of_Activity | titlecase}}</ion-label>\n              <ion-label class=\"list-date\">{{item.date_Of_Visit | date: 'dd/MM/yyyy'}} | <span>\n                  {{item.zone}} | {{item.bank_Name | titlecase}}</span>\n              </ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-item>\n        <div class=\"faq-list-data\" slot=\"content\">\n          <table>\n            <tr>\n              <td class=\"tbl-lbl\">Executive</td>\n              <td>{{item.executive | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Team Leader</td>\n              <td>{{item.team_Leader | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Date of visit</td>\n              <td>{{item.date_Of_Visit | date: 'dd/MM/yyyy'}}</td>\n            </tr>\n            <tr>\n              <td>Start Date</td>\n              <td>{{item.start_Time}}</td>\n            </tr>\n            <tr>\n              <td>End Date</td>\n              <td>{{item.end_Time}}</td>\n            </tr>\n            <tr>\n              <td>Duration</td>\n              <td>{{item.duration}} Hour</td>\n            </tr>\n            <tr>\n              <td>Type of Activity</td>\n              <td>{{item.type_Of_Activity}}</td>\n            </tr>\n            <ng-container *ngIf=\"item?.subTypeOfActivity.length > 0\">\n              <tr *ngFor=\"let subItem of item?.subTypeOfActivity\">\n                <td>\n                  <ul class=\"sub_activity\">\n                    <li>Sub Type of Activity</li>\n                    <li>Start Time</li>\n                    <li>End Time</li>\n                    <li>Duration</li>\n                    <li>Premium Collected Including GST</li>\n                  </ul>\n                </td>\n                <td>\n                  <ul class=\"sub_activity\">\n                    <li>{{subItem?.subTypeOfActivity}}</li>\n                    <li>{{subItem?.subStartTime}}</li>\n                    <li>{{subItem?.subEndTime}}</li>\n                    <li>{{subItem?.subDuration}}</li>\n                    <li>{{subItem?.premium_Collected ? (subItem?.premium_Collected |currency:\n                      'INR':'symbol':'1.0-0'):0}}</li>\n                  </ul>\n                </td>\n              </tr>\n            </ng-container>\n            <tr>\n              <td>Bank Name</td>\n              <td>{{item.bank_Name | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Branch Code</td>\n              <td>{{item.branch_Code}}</td>\n            </tr>\n            <tr>\n              <td>Bank Branch name</td>\n              <td>{{item.bank_Branch_Name | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Person Meet</td>\n              <td>{{item.to_Whom_Meet | titlecase}}</td>\n            </tr>\n            <tr>\n              <td>Contact Number</td>\n              <td>{{item.to_Whom_Meet_Number}}</td>\n            </tr>\n            <tr>\n              <td>Other Remark Comments</td>\n              <td>{{item.remark_Comments | titlecase}}</td>\n            </tr>\n          </table>\n        </div>\n      </ion-accordion>\n    </ion-accordion-group>\n  </ion-grid>\n\n  <!-- if dsr avtivity is empty  -->\n\n  <div *ngIf=\"filterData.length<=0\">\n    <img class=\"center empty-img\" src=\"./assets/New/empty.svg\">\n    <h3 class=\"recordfound\">No Record Found !</h3>\n  </div>\n\n\n  <!-- This code only for download excel , start here -->\n  <div id=\"excel-table\" style=\"display: none;\">\n    <tr>\n      <th>Executive</th>\n      <th>Team Leader</th>\n      <th>Date of visit</th>\n      <th>Start Time</th>\n      <th>End Time</th>\n      <th>Duration</th>\n      <th>Type of Activity</th>\n      <ul class=\"sub_activity\">\n        <li>Sub Type of Activity</li>\n        <li>Start Time</li>\n        <li>End Time</li>\n        <li>Duration</li>\n        <li>Premium Collected Inclusing GST</li>\n      </ul>\n      <th>Bank Name</th>\n      <th>Branch Code</th>\n      <th>Bank Branch name</th>\n      <th>Person Meet</th>\n      <th>Contact Number</th>\n      <th>Other Remark Comments</th>\n    </tr>\n    <table *ngFor=\"let item of filterData; let i=index\">\n      <tr>\n        <td>{{item.executive}}</td>\n        <td>{{item.team_Leader}}</td>\n        <td>{{item.date_Of_Visit}}</td>\n        <td>{{item.start_Time}}</td>\n        <td>{{item.end_Time}}</td>\n        <td>{{item.duration}}</td>\n        <td>{{item.type_Of_Activity}}</td>\n\n        <td *ngFor=\"let subItem of item.subTypeOfActivity\">\n          <ul class=\"sub_activity\">\n            <li>{{subItem.subTypeOfActivity}}</li>\n            <li>{{subItem.subStartTime}}</li>\n            <li>{{subItem.subEndTime}}</li>\n            <li>{{subItem.subDuration}}</li>\n            <li>{{item.premium_Collected}}</li>\n          </ul>\n        </td>\n        <td>{{item.bank_Name}}</td>\n        <td>{{item.branch_Code}}</td>\n        <td>{{item.bank_Branch_Name}}</td>\n        <td>{{item.to_Whom_Meet}}</td>\n        <td>{{item.to_Whom_Meet_Number}}</td>\n\n        <td>{{item.remark_Comments}}</td>\n      </tr>\n    </table>\n  </div>\n  <!-- This code only for download excel , end here -->\n</ion-content>";

/***/ }),

/***/ 7032:
/*!*********************************************************************************!*\
  !*** ./src/app/services/components/dropdown/dropdown.component.html?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button color=\"light\" (click)=\"cancel()\">Cancel</ion-button>\n    </ion-buttons>\n    <ion-title>Welcome</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"light\" (click)=\"confirm()\">Done</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n  <ion-searchbar style=\"padding: 0;\" placeholder=\"Search \"></ion-searchbar>\n</ion-header>\n<ion-content class=\"ion-padding\">\n  \n  <ion-item *ngFor=\"let d of data\">\n    <ion-checkbox id=\"{{d.id}}\" value=\"{{d.name}}\"  (ionChange)=\"onTermsChanged($event)\" [checked]=\"canDismiss\"></ion-checkbox>\n    &nbsp;<ion-label class=\"ion-text-wrap\" for=\"terms\">{{d.name}}</ion-label>\n  </ion-item>\n\n\n  \n\n</ion-content>";

/***/ }),

/***/ 7393:
/*!******************************************************************************!*\
  !*** ./src/app/services/custom-popup/custom-popup.component.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"popup-wrapper\" [@fadein]>\n  <div class=\"popup-content-wrapper\">\n    <ng-container *ngIf=\"popuptype == 'app-update'\">\n      <h2 class=\"app-update-title\">Application Update</h2>\n      <div class=\"app-update-wrapper\">\n        <div class=\"app-update-image-container\">\n          <img src=\"assets/undraw_update_re_swkp.svg\" alt=\"\" srcset=\"\">\n        </div>\n        <h3>You have new application version available</h3>\n        <button type=\"button\" class=\"app-update-button\" (click)=\"update()\">\n          <i class=\"fa fa-upload\" aria-hidden=\"true\"></i> Update Now\n        </button>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"popuptype == 'eapproval-success'\">\n      <h2 class=\"app-update-title\">Success</h2>\n      <div class=\"app-update-wrapper\">\n        <div class=\"success-image-container\">\n          <img\n            src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHMAAABsCAYAAABZw42oAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA/tSURBVHgB7Z1/TBRnGsefWVAQUNYfmKgRqDbnj1JdgTbXVE78Q2vOu4rY9lrgUu8uaps0AdpLr6e5FJKjf/R6YpM213q5O02BkrQKpPWguaZQ0Xo5V11+CHg5FfCKKWgF+Y2yc+/3xeGWZXeZmd2ZndX5JJuF3QV0vvM+7/N832feEUgnnn/++USLxfKiIFAG+9ZGJhIOPMbHnUfLy8vryA8E0oGcnKzcqKjogq1bn7KuWbOGEhISKCoqikyIOjs7qKOjkyoqjlF3d0+l0ynmM1HbSQWai5mdnV2ckBCfx6BFi+LIxDvHjx9noh5vZ6N0sxpBw0hDMCLj4hYVvPlmIcXGWsnEN4haDOulS622pqbmo6QQzcTEHCkIwgdFRUVWU0j5QNDW1rbEJUuWdDQ1NTmU/KyFNIIlO+lpaWmJZmhVTmZmJgmC+CIpRDMxGTtSUlLJRDkYndHRMem7d2coCmmaiclCrNXMWNUzZ84cGhuLilXyM+GkGWJiXNz9GWJHu7qoec+vaPR6F6khfO5cWpKVTcv3vUyBRMswe9/yn4LfqRYS3O3vp2sffsCfA4kppgpGvlUvpCvjA4EVU8Mw6xt/Q5UatApvRiFoI9PfUKUGrcKbUQiamKJIDwSIBkl//iulnqjhX2tJ0MR86NevU8SSpaQnOJj4u1ofVImIpUu5kLGp+tTbQZszo1etopQT1XQ/gJMDwg1eujT5Gr5/lAmJZ+QHTXt+qXl4N7PZALD64LtkK/9kMrHyJCSetUbxyBypOZjrdFKBxSLWRW57bSeZ0Pd1X/FQGv/Sy3yULn56B3/GSG3WYURKKB6ZznHazRZBraJTyBBPvJdAJtRVWkJX33mbf700O4cL2f1Zla5CAsUj0yKIR0US0PZRJ2x/pYNMOBB0tOtblmD9ho/UK394m/RGsZiRP37tEHs6RCbTuFlbyx/BQtdstqLiOJ08eZJu3LjBv4+PT6CEhHi2freLFi1aRCb+oZuYpSwM9fT0UF5ePm/oAmhmqqmpoQMH9vMF2aee2kYm6tFFzNbWVjp3zk4HD06NzhiZe/fuYyO1h956q4iGhoZo585MMjq85AiAFRkWE1jzQpc6E2Ju3Pgjr++jtWT//gNUX3+SiX6OjI6/7pVWTpQuIxPzYVtb2wyfiaM9e/bRoUPF9M47f6S5OlluajCqe6XLyIyOjmYhdHDGz6H3JSUlhSVKFXT9+nXq7e2l8fFxMpGHLmIi4enokFeSIhE6daqehoeH+aO7u5sGB2c+EUwM6M0i3CYkJNLly5cnX7t9+zYX1sQ3uoiJOVOqLeWQmppCLS0Xp7wGQc2Q65ugLYH5Av22n376KW3ZsmXK6/39t2nBggVkBCwWC8Ww0iI83DiH0JBLYBjJYWFhNDo6OuX1sbEx/jACTrZ0hJNLNFDLhGHXMxcuXMSzWXfcBQ4mENIUUwbwbL/77rtprw8PD5FRsFjCeLg1CiHXaeB0ioYItZgGjGZs6DJ7I5NVsyoCs2H+/OkJz9y58/h7noC/i5q2ra2V24hSfYtaNy0tjT2824qhQL0tKV0g4U32ZTp7tLOvjzzpaCzEe7qIidUSpdedQJTIyDke33MvUSAaVmDg60I8aWkNpr20QoPPlJZ+xN/Pyfk5hSK1ttWJTDzXBdNENmsXMIGFNEdzgS5i4kArvSJscHCIXwnlCZwcZ858wwXCA78bNiCW0GAJevpbeB8PeL9YVw2F1Rl3wmlWsafXmcC5tTbbIZ1G5g1avXqNop+5dq2Tli6dWJm4desWd4SuXLlMzc3NrL6LYaKtpeTkFL6EpuREwedffTWf1bBb+e8JJQQSE71sQ2GNFUZjdRETa5lYlJZLZ2cnr+O+/PIfXLyxsVEmXCo7IVZTdnaOX10JEH7jxjSqrv47bdqUzke/kVdoXBFJYHOk5213+sSIPs3FhDCCQJNzlxwwr8Gfxc9s27aNz4GBJC5uYkkOc+/AwADPjhcuXEhGx0LjhSKFZbi/zubNws0OR6/mYtbUVLP5aZein5nIOtNIS1znY4jZ399v+BH6pKPFwZKdzWxssLlTsDG7olcgZ2Ga4yJv4dBUTHQOoETAPGUkMPJjY2PZXPz95Gt9fbfYiF2My/fJH7T2bFnWWseeNnh6T1PTAM1aaAcxCqh30R1YX1/PQnf8lPdgRty96/+qTDA9W01OH+wBxJ6smO+CuXUMalW73T5Zg8IKRCKFEH7s2DHsHkYRERGTnxdFJwUCybP1d5QrxauY39jW5Y6zgpQN3bonHU2yrynJyMiwhoVZKjIzM61613KS+4PsubW1jW7e7KHlyxP4+mh+fv6URKqkpIQ+//xz2rVL2Xwuh2B5tl7FdJJzNytGrSxYZJzfsCYh+ULrjH0fGJFMyFomZKJeQsI0kKw7jECIB+MgJydH2r7MI2hPQb2JbBshF17r7NmzyV/we2JigpNI+QizlqMsYLCaRqyTI2RWVpaNRZUKrYWUfFdv1p1cA0GqN7u7e2j9ehsfSXPmRHl1nUIBr2JudDTKvqaEjcj0mJjoClbQW7UsKYqKinjD9EzWnVwwIi9cOM+/RuKC9dNAjdBg4FcCBBHZGb2JjciC/fv3B7y4d+fAAe0zY9SboWAgeEKRmM8++6yNnbXp7DzeIQgW2/Ll8dY1a1bTqVOnQnLDCYRryf+VgIEQjEw0EPgUE5kpWzfczebN9ew/l8HOWCtCHEZgamqqS4gTeAKixLILNqg5Me/m5uZNew82n5EateTi9V+MhCYmJuqCZHCvXbvWq8GNueuLL2q4jxoKQMiiot/zuRfOpqsThEQI7tB9JaYgiOnI9uQs5ELMw4c/5HWekXeyhIglJR/RxYsXWSa7kR577DEPnxJpdHSEZ7WhFmp9ienAnCIHCIjQi1LBV20XDNy7EOBILV682IuQ+L9EB83B8RevYpaUlNdlZ2f1stEma99YzJcQP9hiTsyF9skuBIiHJM21DkWJI5kFrqAkwYK10bru5DLDxCA42BmdLqd2nLh6C+0YpCsQr6Wlha9PQkSphcRXFwLsvYaGhiliRkdH8UaxYDo4/jKDmM6qjo52WWLirMfZrte8iYQLqzKSeY4kDRadnC4ETAlnzpyZ0vmHUblgQWjWlxI+xRTFu3WYa+QkQRCQ1Z26zZsQxN089wfp0odQdX+Az4mhrOwTBwtjvXKv4IKICHV6gL+lVkgkRO5mAbhz5w6FMjPO8mzRtgqJhBxwgOVmwMECJybCM8oud+DPhjIzismSOocSMW/cuMnnTSMimQUbNiSz+XL+tPdDOcSCGW2O8XGxkoXOYqK9JAfMm5hntW7IUgJOLpgFZ8+e5WYBsllX1wcgi42ImE2DgwOyfqcRr8+c8V+CG4yxerOdndWJcjJFHCiWAQddTNdFa3TAwwxAi8i6des8fn7ePGXliNTrY7XON4y5IOu0YmZIld1uz5XjvaLTvKbmoO7Xc8hZtIbl2NjYOMX9wYiEF6smxBrNKZIbI7i1J0dMFOLYTELtlV9KQTsn+nnkXG+CK8AQbt2tvFmzZpEajOYUyRKTnbWVLFz9jWSSnJzMw5seoRbCFRcfkmVU4Eq0vr6+Ka9huWtkZERxu4gRnSJZYh45cqQ3OzsbWa1NjiGAsKaXmEpaOSfcqenXfEJIqzX0bwspO0awueFruRszYbcQvcwDJSAxW7ZsullgxC1p1Ox7JFtM7Ml+/ry8TQoxVyLsKdn7R2swKnEbYE+3gUTINBI4bqxEai8rK1O007bsIik8PKIOI9PdSMce5D2fVfFnbDQv7faIg4ZuciN0H+DgFBcXc7Ng5cqV09537WoPxN9CUma3n+O2oRomjq9QRwqRLea9eROCprvOm7if19C/J+7ncb2slB45/Be+6yOyWozkYInpWqpcvdpOW7du8WjhYVQGqlcWKzknTpyghx9+mCWBG/imVEpPFBgbZ8/+i4V+ZyEpRJF9webNBnaAJsUcZCJKQgKMTtw14KFVr/OGL+z+rBfSonRHRyd/xkFMSkqixx9/nF54IYsiIyOn/Qxqy0AlPvi/IhJt3/4TZkDMIzVcuXKFC8lK10I1d4NXJKbF4kSJkistQHvaQFfaEBehApkmslotlsSki4KwKN3a2kIDA4NMvEdoxYqV9MYbv/UoHpCanPHvC5QXixF5+vRpeu65n6kO2ejXra39CgPm3bKyjwtIBYrEDA+PRHky2UoC4XCXnWsf/om/H/WDVXzelICIgVrfhHgTrSAtPHRCvJUrV3Dx9uzZ69E4ByjqIRoeEDjQyY60CrNjR4ZfQlZVVaKRzMGEzCOVKBJTqjdd583l+16ixT99mu4O9FM0E9MVqQVz4obY0bIdIRwg+KlIIBA2cUJg39lly5bQ2rVJ9Mwzz3ARPQHxYH5DOAio1t2RC04ubA2nNrRi+zjsr3D7dl87W9Twq+lGheXvrGJz0pQkCBvQS+ek62V1aCOBIIcPH+Y7QUulii9R8RmMMiQlWEBewkI5bDpPi8kSEA2jQhqBeoIosWLFQ6SW06dP4foZCLlZzTzpimIxPbVguq5QTJQvg3W45j4vL9860Wg8FUlUFMbYSYRlbtywRvHuLVwChEiY2hhtro9gGt3Yr0hteEXmijlfFIWd5eUft5OfKBZTasFkhrUVI+9e7emAQ8SMhcqBgRFHZWUlC8dZV5mt5zFVnCncujsyCJ1G7WHFVWkxMcrvj4nVG2SurEbIZ/OkgwKAqpVVNpI21NR8sZuJ5xgYGK6DeBRAjObIBBpEJuxDjxKECRmwW3GpEvNebC8gE8Ugc8V2Ov6UIN4wb4aqI1IJwjJXv0oQb5hi6kigShBvmGLqBC5IDlQJ4g1TTB1ACdLY2HCvBPEuJLbrqbc9euu07dEKUoEppsZMLUHKfJYgE9v10OR2PaQQU0wNcS1BSkvllCDYrgfI267HndC71jtEUFOCKNmuxxPmyNQAmOdaliDeMMXUgOrqak1LEG9oKKbQ+yDeKhElSFfXfzUtQbyhmZhsrmiHEf8gIbcE0QrNxGRLZV8bsXdWK6T+HTkliFZoJuasWRFH2MKt7KuuQ5n/9+/ILUG0QbO1JofDMbJuXdJoa2vbtieeeELz9o1ggU4Du/0srldBCfIGBRFNFw6bmpr/mZgYP7+hofGH69evN/TuXWpAi0xTUyNuqIMSROdNc6aj+SpwY2NTDRNUsNvt6egHQvtlqF+kg6kDjWrvv/8eOi3eHRoa/kVbW9sIBRndejGw5bfFIuQJgrCJvNw1J4RoZ9l6Fdpk0EZDJiYmJiYmJiYmwcGQncViRYF1JGIeWifS2aN9XLy7M2b760GxyEIJQy6BjUTOxe140+99mxguhNeKFcWhv4OExhhSTNEpTKlDRSIrzZ4VSyY+Meri9Ndu37cL219Rt0HAA4QhxRwdEwqcRLy5SRDJMc7WB8lkRv4HHC2I4g1GHjwAAAAASUVORK5CYII=\"\n            alt=\"\" srcset=\"\">\n        </div>\n        <h3>Your case is refered to underwriter successfully.</h3>\n        <h4>E-approval Number : <strong>{{eapprovalNo | uppercase}}</strong></h4>\n        <h4>Win Number : <strong>{{winNo | uppercase}}</strong></h4>\n        <button type=\"button\" class=\"app-update-button\" (click)=\"close()\">\n          Okey\n        </button>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"popuptype == 'eapproval-failure'\">\n      <h2 class=\"app-update-title\">Application Update</h2>\n      <div class=\"app-update-wrapper\">\n        <div class=\"app-update-image-container\">\n          <img src=\"assets/undraw_update_re_swkp.svg\" alt=\"\" srcset=\"\">\n        </div>\n        <h3>Your case is refered to underwriter successfully.</h3>\n        <h3>EApproval No :</h3>\n        <h3>Win No :</h3>\n        <button type=\"button\" class=\"app-update-button\">\n          <i class=\"fa fa-upload\" aria-hidden=\"true\"></i> Update Now\n        </button>\n      </div>\n    </ng-container>\n  </div>\n</div>\n";

/***/ }),

/***/ 7833:
/*!*************************************************************!*\
  !*** ./src/app/teamdemo/teamdemo.component.html?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

"use strict";
module.exports = " \n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <!-- <div>\n        <ion-back-button (click)=\"backButton()\" mode=\"md\"></ion-back-button>\n      </div> -->\n      <ion-icon  class=\"backButton\" (click)=\"backButton()\" name=\"arrow-back-outline\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons [hidden]=\"true\" slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"bold\">{{titleMsg}}</ion-title>\n    <!-- <ion-icon class=\"filter-icon\" (click)=\"filterOpen()\" slot=\"end\" name=\"funnel-outline\"></ion-icon> -->\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n\n \n\n  <ion-card *ngIf=\"openFilter\" class=\"mar-0\">\n    <ion-card-content>\n      <form>\n        <ion-row>\n          <ion-col size=\"6\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Start Date</ion-label>\n            <ion-input type=\"date\"></ion-input>\n          </ion-col>\n          <ion-col size=\"6\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">End Date</ion-label>\n            <ion-input type=\"date\"></ion-input>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"danger\" (click)=\"filterOpen()\" class=\"fltr-btn bold center\">Close</ion-button>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"warning\" class=\"fltr-btn bold center\">Clear</ion-button>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"success\" class=\"fltr-btn bold center\">Filter</ion-button>\n          </ion-col>\n        </ion-row>\n      </form>\n    </ion-card-content>\n  </ion-card>\n\n \n\n<!--<ion-grid class=\"pad-0\">\n  <ion-card *ngFor=\"let item of teamsData; let i=index\" (click)=\"goToTeamActivityDetail(item.userName)\">\n    <ion-item>\n      <ion-label><span>{{i+1}}.</span>&nbsp; {{item.executive}}</ion-label>\n      <ion-badge color=\"warning\" slot=\"end\">{{item.Counts}}</ion-badge>\n    </ion-item>\n  </ion-card>\n</ion-grid>-->\n\n\n<ion-grid class=\"pad-0\">\n  <ion-card *ngFor=\"let item of teamsData; let i=index\" (click)=\"getTeamsLeadersApi(item)\">\n    <ion-item>\n      <ion-label><span>{{i+1}}.</span>&nbsp; {{item.name | titlecase}}<br>\n      <span style=\"font-size: 11px; color:rgb(255, 255, 255);font-weight: normal;\">Total Premium : {{item.sum ?  (item.sum |currency: 'INR':'symbol':'1.0-0'):0}}</span></ion-label><br>\n      <ion-badge color=\"warning\" slot=\"end\">Till Date Dsr Counts : {{item.Count}}</ion-badge>\n    </ion-item>\n  </ion-card>\n</ion-grid>\n\n\n\n<ng-container *ngIf=\"emptyRecord\">\n  <div *ngIf=\"teamsData.length == 0\">\n    <img class=\"center empty-img\" src=\"./assets/New/empty.svg\">\n    <h3 class=\"recordfound\">No Record Found !</h3>\n    <!-- <ion-button class=\"empty-btn center\" (click)=\"AddDsrActivity()\" size=\"small\">Add Dsr Activity</ion-button> -->\n  </div>\n</ng-container>\n\n\n\n</ion-content>";

/***/ }),

/***/ 8083:
/*!*************************************************************************!*\
  !*** ./src/app/teams-activity/teams-activity.component.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <div>\n        <ion-back-button defaultHref=\"/\" mode=\"md\"></ion-back-button>\n      </div>\n    </ion-buttons>\n    <ion-buttons [hidden]=\"true\" slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"bold\">{{titleMsg}}</ion-title>\n    <!-- <ion-icon class=\"filter-icon\" (click)=\"filterOpen()\" slot=\"end\" name=\"funnel-outline\"></ion-icon> -->\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n\n  <ion-breadcrumbs [maxItems]=\"4\" (ionCollapsedClick)=\"presentPopover($event)\">\n    <ion-breadcrumb href=\"#home\">Home</ion-breadcrumb>\n    <ion-breadcrumb href=\"#electronics\">Electronics</ion-breadcrumb>\n    <ion-breadcrumb href=\"#photography\">Photography</ion-breadcrumb>\n    <ion-breadcrumb href=\"#cameras\">Cameras</ion-breadcrumb>\n    <ion-breadcrumb href=\"#film\">Film</ion-breadcrumb>\n    <ion-breadcrumb href=\"#35mm\">35 mm</ion-breadcrumb>\n  </ion-breadcrumbs>\n  \n  <ion-popover #popover [isOpen]=\"isOpen\" (didDismiss)=\"isOpen = false\">\n    <ng-template>\n      <ion-content>\n        <ion-list>\n          <ion-item\n            *ngFor=\"let breadcrumb of collapsedBreadcrumbs; last as isLast\"\n            [href]=\"breadcrumb.href\"\n            [lines]=\"isLast ? 'none' : null\"\n          >\n            <ion-label>{{ breadcrumb.textContent }}</ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-content>\n    </ng-template>\n  </ion-popover>\n\n  <ion-card *ngIf=\"openFilter\" class=\"mar-0\">\n    <ion-card-content>\n      <form>\n        <ion-row>\n          <ion-col size=\"6\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Start Date</ion-label>\n            <ion-input type=\"date\"></ion-input>\n          </ion-col>\n          <ion-col size=\"6\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">End Date</ion-label>\n            <ion-input type=\"date\"></ion-input>\n          </ion-col>\n        </ion-row>\n\n        <ion-row>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"danger\" (click)=\"filterOpen()\" class=\"fltr-btn bold center\">Close</ion-button>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"warning\" class=\"fltr-btn bold center\">Clear</ion-button>\n          </ion-col>\n          <ion-col size=\"4\" class=\"pad-0\">\n            <ion-button color=\"success\" class=\"fltr-btn bold center\">Filter</ion-button>\n          </ion-col>\n        </ion-row>\n      </form>\n    </ion-card-content>\n  </ion-card>\n\n \n\n<!--<ion-grid class=\"pad-0\">\n  <ion-card *ngFor=\"let item of teamsData; let i=index\" (click)=\"goToTeamActivityDetail(item.userName)\">\n    <ion-item>\n      <ion-label><span>{{i+1}}.</span>&nbsp; {{item.executive}}</ion-label>\n      <ion-badge color=\"warning\" slot=\"end\">{{item.Counts}}</ion-badge>\n    </ion-item>\n  </ion-card>\n</ion-grid>-->\n\n\n<ion-grid class=\"pad-0\">\n  <ion-card *ngFor=\"let item of teamsData; let i=index\" (click)=\"goToTeamActivityDetail(item)\">\n    <ion-item>\n      <ion-label><span>{{i+1}}.</span>&nbsp; {{item.name}} <br>\n      <span style=\"margin-left: 11%; font-size: 11px; color:rgb(143 143 143);font-weight: normal;\">Total Premium : {{item.sum ? (item.sum |currency: 'INR':'symbol':'1.0-0'):0}}</span></ion-label><br>\n      <ion-badge color=\"warning\" slot=\"end\">Total Counts : {{item.Count}}</ion-badge>\n    </ion-item>\n  </ion-card>\n</ion-grid> \n\n\n\n<ng-container *ngIf=\"emptyRecord\">\n  <div *ngIf=\"teamsData.length == 0\">\n    <img class=\"center empty-img\" src=\"./assets/New/empty.png\">\n    <!-- <ion-button class=\"empty-btn center\" (click)=\"AddDsrActivity()\" size=\"small\">Add Dsr Activity</ion-button> -->\n  </div>\n</ng-container>\n\n\n\n</ion-content>";

/***/ }),

/***/ 9016:
/*!***************************************************************************!*\
  !*** ./src/app/teams-dashboard/teams-dashboard.component.html?ngResource ***!
  \***************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <div>\n        <ion-back-button defaultHref=\"/\" mode=\"md\"></ion-back-button>\n      </div>\n    </ion-buttons>\n    <ion-buttons [hidden]=\"true\" slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"bold\">{{titleMsg}}</ion-title>\n    <ion-icon class=\"filter-icon\" hidden=\"true\" (click)=\"filterOpen()\" slot=\"end\" name=\"funnel-outline\"></ion-icon>\n  </ion-toolbar>\n  <ion-card class=\"mar-0\" *ngIf=\"openFilter\">\n    <ion-card-content>\n      <ion-icon (click)=\"filterOpen()\" style=\"float: right;font-size: 18px;\" color=\"danger\" name=\"close-circle-outline\">\n      </ion-icon>\n      <form [formGroup]=\"managerForm\">\n        <ion-row>\n          <ion-col size=\"12\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone <span class=\"error\"\n                *ngIf=\"(managerForm.controls.zone.touched || submitted) && managerForm.controls.zone.errors?.required\">\n                *</span></ion-label>\n            <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\" placeholder=\"Select Zone\"\n              [multiple]=\"true\">\n              <ion-select-option *ngFor=\"let z of zoneData\" value=\"{{z.zone}}\">{{z.zone}}</ion-select-option>\n            </ion-select>\n          </ion-col>\n        </ion-row>\n      </form>\n    </ion-card-content>\n    <ion-badge style=\"float: right;padding: 6px;margin:6px;\" (click)=\"clearManagerFilter()\" color=\"danger\">Clear Filter\n    </ion-badge>&nbsp;\n  </ion-card>\n</ion-header>\n<ion-content>\n\n  <!-- <ion-card class=\"mar-0\" *ngIf=\"openFilter\">\n    <ion-card-content>\n      <ion-icon (click)=\"filterOpen()\" style=\"float: right;font-size: 18px;\" color=\"danger\" name=\"close-circle-outline\">\n      </ion-icon>\n      <form [formGroup]=\"managerForm\">\n        <ion-row>\n          <ion-col size=\"12\" class=\"pad-0\">\n            <ion-label class=\"form-lbl bold clr-black\" position=\"floating\">Select Zone <span class=\"error\"\n                *ngIf=\"(managerForm.controls.zone.touched || submitted) && managerForm.controls.zone.errors?.required\">\n                *</span></ion-label>\n            <ion-select formControlName=\"zone\" (ionChange)=\"chngeZone($event)\" mode=\"ios\" placeholder=\"Select Zone\"\n              [multiple]=\"true\">\n              <ion-select-option value=\"East\">East</ion-select-option>\n              <ion-select-option value=\"West\">West</ion-select-option>\n              <ion-select-option value=\"North\">North</ion-select-option>\n              <ion-select-option value=\"South\">South</ion-select-option>\n              <ion-select-option value=\"Central\">Central</ion-select-option>\n            </ion-select>\n          </ion-col>\n        </ion-row>\n      </form>\n    </ion-card-content>\n    <ion-badge style=\"float: right;padding: 6px;margin:6px;\" (click)=\"clearManagerFilter()\" color=\"danger\">Clear Filter\n    </ion-badge>&nbsp;\n  </ion-card> -->\n\n  <ion-grid>\n    <!-- <ion-accordion-group>\n      <ion-accordion class=\"faq-list\" *ngFor=\"let item of teamsData;let i=index\" (click)=\"getCounts(item.EmpCode)\"\n        value=\"{{i+1}}\">\n        <ion-item slot=\"header\" >\n          <div>\n            <ion-row>\n              <ion-col size=\"12\">\n                <ion-label class=\"list-lbl bold\">{{i+1}}. {{item.EmployeeName}}</ion-label>\n                <ion-label class=\"list-lbl\" style=\" font-size:11px; \"><span>Dsr Count : {{dsrCount}}</span> |\n                  <span>Total premium : {{totalPremium}}</span>\n                </ion-label>\n              </ion-col>\n            </ion-row>\n          </div>\n        </ion-item>\n        <div class=\"faq-list-data\" slot=\"content\">\n          <table>\n            <tr>\n              <th>Activities</th>\n              <th>{{yesturdayDate | date }}</th>\n              <th>\n                Current Month till<br>\n                {{yesturdayDate | date }}\n              </th>\n            </tr>\n            <tr *ngFor=\"let item of typeOfActivityData\">\n              <td class=\"tbl-lbl\">{{item.type}}</td>\n              <td>{{item.count}}</td>\n              <td>{{item.mnthCount}}</td>\n            </tr>\n            <tr>\n              <th>Total </th>\n              <th>{{yesturdayCount}}</th>\n              <th>{{monthCount}}</th>\n            </tr>\n\n          </table>\n        </div>\n      </ion-accordion>\n    </ion-accordion-group> -->\n\n\n    <table>\n      <thead>\n        <tr>\n          <th class=\"th-label\">Activities</th>\n          <th class=\"th-label\">{{yesturdayDate | date }}</th>\n          <th class=\"th-label\"> Current Month till<br>\n            {{yesturdayDate | date }}\n          </th>\n        </tr>\n      </thead>\n      <tr *ngFor=\"let item of typeOfActivityData\">\n        <td class=\"tbl-lbl\">{{item.type | titlecase}}</td>\n        <td>{{item.count}}</td>\n        <td>{{item.mnthCount}}</td>\n      </tr>\n      <tr>\n        <th>Total</th>\n        <th>{{yesturdayCount}}</th>\n        <th>{{monthCount}}</th>\n\n      </tr>\n\n    </table>\n\n\n  </ion-grid>\n\n\n  <!-- if dsr avtivity is empty  -->\n\n  <div *ngIf=\"teamsData.length<=0\">\n    <img class=\"center empty-img\" src=\"./assets/New/empty.svg\">\n    <h3 class=\"recordfound\">No Record Found !</h3>\n  </div>\n\n\n\n</ion-content> \n  <ion-footer>\n    <ion-toolbar>\n\n      <ion-row>\n        <!-- <ion-col size=\"9\">\n          <ion-title style=\"font-size:13px\">Total Premium Collected Inclusing GST Sum :</ion-title>\n        </ion-col> -->\n        <ion-col size=\"12\">\n          <p class=\"center\" style=\"font-size:15px;color: white;margin: 0;\"><b>Total Premium {{totalPremium ? (totalPremium |currency: 'INR':'symbol':'1.0-0'):0}}</b></p>\n        </ion-col>\n      </ion-row>\n    </ion-toolbar>\n  </ion-footer>\n ";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map