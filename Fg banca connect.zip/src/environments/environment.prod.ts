export const environment = {
  production: true,
  baseUrl: 'https://online.futuregenerali.in/TeamTrack/api'
};
