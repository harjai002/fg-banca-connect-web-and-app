```
./build-cordova.sh && ./build-update.sh && adb shell am start -n de.kolbasa.apkupdater.demo/de.kolbasa.apkupdater.demo.MainActivity
```


https://stackoverflow.com/questions/68991385/android-11-issue-for-navgiate-to-settings-page

```
//    ERROR_API_NOT_AVAILABLE
//    The API is not available on this device.
//    Constant Value: -3 (0xfffffffd)
//
//    ERROR_DOWNLOAD_NOT_PRESENT
//    The install/update has not been (fully) downloaded yet.
//    Constant Value: -7 (0xfffffff9)
//
//    ERROR_INSTALL_IN_PROGRESS
//    The install is already in progress and there is no UI flow to resume.
//    Constant Value: -8 (0xfffffff8)
//
//    ERROR_INSTALL_NOT_ALLOWED
//    The download/install is not allowed, due to the current device state (e.g. low battery, low disk space, ...).
//    Constant Value: -6 (0xfffffffa)
//
//    ERROR_INSTALL_UNAVAILABLE
//    The install is unavailable to this user or device.
//    Constant Value: -5 (0xfffffffb)
//
//    ERROR_INTERNAL_ERROR
//    An internal error happened in the Play Store.
//    Constant Value: -100 (0xffffff9c)
//
//    ERROR_INVALID_REQUEST
//    The request that was sent by the app is malformed.
//    Constant Value: -4 (0xfffffffc)
//
//    ERROR_UNKNOWN
//    An unknown error occurred.
//    Constant Value: -2 (0xfffffffe)
//
//    NO_ERROR
//    No error occurred; all types of update flow are allowed.
//    Constant Value: 0 (0x00000000)
//
//    NO_ERROR_PARTIALLY_ALLOWED
//    No error occurred; only some types of update flow are allowed, while others are forbidden.
//    Constant Value: 1 (0x00000001)
```


Unter Android Studio die Debug-Version signen:
```
android {

    signingConfigs {
        debug {
            storeFile file('/Users/michael/Projekte/cordova-plugin-apkupdater/resources/keystore')
            keyAlias 'Kolbasa'
            storePassword '[T-tAPCMWO/m(P>1z\\LO'
            keyPassword '[T-tAPCMWO/m(P>1z\\LO'
        }
    }
    buildTypes {
        debug{
            signingConfig signingConfigs.debug
        }
    }
    
    
[...]
```

https://stackoverflow.com/questions/11246326/how-to-make-my-app-receive-broadcast-when-other-applications-are-installed-or-re


# TypeScript anpassen

`index.d.ts` und `index.js` in Ruhe lassen, den Rest anpassen. `index.ts` nicht vergessen.
Danach npm run build ausführen.