package de.kolbasa.apkupdater.tools;

public class FileProvider extends androidx.core.content.FileProvider {
    //
}
